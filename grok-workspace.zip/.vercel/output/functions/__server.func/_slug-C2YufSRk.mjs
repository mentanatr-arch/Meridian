import { Y as require_jsx_runtime, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./_ssr/button-CbyLMWg1.mjs";
import { a as Route$9 } from "./_ssr/router-Ba3nbWFA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-C2YufSRk.js
var import_jsx_runtime = require_jsx_runtime();
var PAGES = {
	terms: {
		title: "Terms of use",
		updated: "1 October 2026",
		sections: [
			{
				h: "The desk",
				p: "Meridian is software and digital paper for independent professionals. By using it you agree to these terms. If you cannot, do not open a studio here."
			},
			{
				h: "Accounts and data on this preview",
				p: "This running preview stores your invoices, time, and cart on the device you are using. Publishing with hosted accounts later is a different contract, issued at that time."
			},
			{
				h: "Plans",
				p: "Starter is free with stated ceilings. Pro and Studio renew monthly or annually until cancelled. You may cancel at period end. We may change prices with 30 days' notice to the email on the studio."
			},
			{
				h: "Acceptable use",
				p: "Do not use Meridian to invoice for unlawful work, to harass, or to impersonate another practice. We may suspend a studio that does."
			},
			{
				h: "Limitation",
				p: "The software is provided as-is. We are not your accountant or lawyer. Paper generated here is a starting point, not counsel."
			}
		]
	},
	privacy: {
		title: "Privacy",
		updated: "1 October 2026",
		sections: [
			{
				h: "What we collect in this preview",
				p: "Studio details, invoices, proposals, time, cart, and any email you type into a form stay in this browser unless you publish with a hosted backend."
			},
			{
				h: "What we ask of a live deployment",
				p: "When payments and mail are connected, we will collect the email and billing details required to charge, receipt, and support you. We will not sell lists."
			},
			{
				h: "Cookies",
				p: "A local preference store is used for the desk. We do not run third-party ad pixels on this preview."
			},
			{
				h: "Contact",
				p: "Privacy questions: hello@meridian.studio."
			}
		]
	},
	refunds: {
		title: "Refunds",
		updated: "1 October 2026",
		sections: [
			{
				h: "Software",
				p: "Monthly plans can be cancelled any time; the period already paid is not refunded. Annual plans may be refunded within 14 days of charge if the studio has not been used as a production desk (more than three paid invoices)."
			},
			{
				h: "Shop kits",
				p: "Digital kits are refundable within 7 days if files were not downloaded in bulk. After that they are yours."
			},
			{
				h: "This preview",
				p: "No cards are charged here. Refunds apply when a processor is connected on a published site."
			}
		]
	}
};
function Legal() {
	const { slug } = Route$9.useParams();
	const page = PAGES[slug];
	if (!page) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-6 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-serif text-3xl",
			children: "No such page"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				children: "Home"
			})
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-subtle",
				children: ["Updated ", page.updated]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-serif text-5xl tracking-tight",
				children: page.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 space-y-8",
				children: page.sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl tracking-tight",
					children: s.h
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 leading-relaxed text-muted",
					children: s.p
				})] }, s.h))
			})
		]
	});
}
//#endregion
export { Legal as component };
