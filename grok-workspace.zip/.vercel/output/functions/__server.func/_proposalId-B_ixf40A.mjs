import { i as __toESM } from "./_runtime.mjs";
import { c as uid } from "./_ssr/utils-DXWKSffG.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useNavigate, Y as require_jsx_runtime, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./_ssr/button-CbyLMWg1.mjs";
import { c as useStudio, n as Textarea, o as blankInvoice, t as Input } from "./_ssr/input-D498PH2S.mjs";
import { a as Printer, o as Plus, r as Trash2 } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { n as Route, u as useHydrated } from "./_ssr/router-Ba3nbWFA.mjs";
import { t as Label } from "./_ssr/label-D3Zuzywy.mjs";
import { n as ProposalPaper } from "./_ssr/paper-B6Jf_iVX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_proposalId-B_ixf40A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"draft",
	"sent",
	"accepted",
	"declined"
];
function ProposalEditor() {
	const { proposalId } = Route.useParams();
	const hydrated = useHydrated();
	const navigate = useNavigate();
	const proposals = useStudio((s) => s.proposals);
	const updateProposal = useStudio((s) => s.updateProposal);
	const removeProposal = useStudio((s) => s.removeProposal);
	const addInvoice = useStudio((s) => s.addInvoice);
	const nextInvoiceNumber = useStudio((s) => s.nextInvoiceNumber);
	const profile = useStudio((s) => s.profile);
	const proposal = (0, import_react.useMemo)(() => proposals.find((p) => p.id === proposalId), [proposals, proposalId]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-6xl px-4 py-16",
		children: "Loading…"
	});
	if (!proposal) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-6 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-serif text-3xl",
			children: "Proposal not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/tools/proposals",
				children: "Back"
			})
		})]
	});
	function patch(p) {
		updateProposal(proposalId, p);
	}
	function billTheYes() {
		const invoice = blankInvoice(profile, nextInvoiceNumber());
		invoice.client = proposal.client;
		invoice.from = proposal.from;
		invoice.items = proposal.items.map((i) => ({
			...i,
			id: uid()
		}));
		invoice.taxRate = proposal.taxRate;
		invoice.currency = proposal.currency;
		invoice.notes = `Against ${proposal.number} — ${proposal.title}`;
		if (!addInvoice(invoice).ok) {
			toast("Upgrade to bill from a proposal — invoice ceiling reached.");
			navigate({ to: "/pricing" });
			return;
		}
		patch({ status: "accepted" });
		navigate({
			to: "/tools/invoices/$invoiceId",
			params: { invoiceId: invoice.id }
		});
	}
	function patchItem(id, key, value) {
		patch({ items: proposal.items.map((item) => item.id === id ? {
			...item,
			[key]: value
		} : item) });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/tools/proposals",
						className: "text-sm text-muted hover:text-fg",
						children: "All proposals"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								onClick: () => window.print(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), " Print"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: billTheYes,
								children: "Bill the yes"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => {
									removeProposal(proposalId);
									navigate({ to: "/tools/proposals" });
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "mb-2 block",
					children: "Title"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: proposal.title,
					onChange: (e) => patch({ title: e.target.value })
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "mb-2 block",
						children: "Number"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: proposal.number,
						onChange: (e) => patch({ number: e.target.value })
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "mb-2 block",
						children: "Status"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: proposal.status,
						onChange: (e) => patch({ status: e.target.value }),
						className: "flex h-11 w-full rounded-md border border-border bg-bg-elevated px-3 text-sm",
						children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "mb-2 block",
					children: "Summary"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: proposal.summary,
					onChange: (e) => patch({ summary: e.target.value })
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "mb-2 block",
					children: "Client"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Name",
					value: proposal.client.name,
					onChange: (e) => patch({ client: {
						...proposal.client,
						name: e.target.value
					} })
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "mb-2 block",
					children: "Scope (in, then out)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					className: "min-h-40",
					value: proposal.scope,
					onChange: (e) => patch({ scope: e.target.value })
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "mb-2 block",
					children: "Timeline"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: proposal.timeline,
					onChange: (e) => patch({ timeline: e.target.value })
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "mb-2 block",
						children: "Investment"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 space-y-2",
						children: proposal.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[1fr_7rem] gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: item.description,
								onChange: (e) => patchItem(item.id, "description", e.target.value)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: item.rate,
								onChange: (e) => patchItem(item.id, "rate", Number(e.target.value))
							})]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						className: "mt-3",
						onClick: () => patch({ items: [...proposal.items, {
							id: uid(),
							description: "",
							quantity: 1,
							rate: 0
						}] }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Line"]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "mb-2 block",
					children: "Notes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: proposal.notes,
					onChange: (e) => patch({ notes: e.target.value })
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProposalPaper, { proposal })]
	});
}
//#endregion
export { ProposalEditor as component };
