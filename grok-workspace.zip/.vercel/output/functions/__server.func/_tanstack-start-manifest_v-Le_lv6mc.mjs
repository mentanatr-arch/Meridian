//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Le_lv6mc.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/faq",
			"/onboarding",
			"/partners",
			"/playbook",
			"/pricing",
			"/studio",
			"/checkout/success",
			"/journal/$slug",
			"/legal/$slug",
			"/shop/$slug",
			"/tools/rates",
			"/tools/time",
			"/checkout/",
			"/journal/",
			"/shop/",
			"/tools/",
			"/tools/invoices/$invoiceId",
			"/tools/proposals/$proposalId",
			"/tools/invoices/",
			"/tools/proposals/"
		],
		preloads: [
			"/assets/index-Uw-PTG2t.js",
			"/assets/jsx-runtime-Cx0BB4qO.js",
			"/assets/react-IDFlRUvQ.js",
			"/assets/preload-helper-Cf5sGJnH.js",
			"/assets/link-DZ7aYDaR.js",
			"/assets/useRouter-CT2MX79k.js",
			"/assets/button-CBspatzm.js",
			"/assets/utils-r2ZpRFpY.js",
			"/assets/store-CQ1ybTXs.js",
			"/assets/catalog-BMULjqIo.js",
			"/assets/input-CPChOPpt.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Uw-PTG2t.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-D3XfUhv3.js",
			"/assets/pen-line-CsWTkv-k.js",
			"/assets/badge-HmzmGn9n.js",
			"/assets/paper-CGS6elfQ.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DAeXv75F.js"]
	},
	"/faq": {
		filePath: "/workspace/src/routes/faq.tsx",
		children: void 0,
		preloads: ["/assets/faq-B2X4-73i.js"]
	},
	"/onboarding": {
		filePath: "/workspace/src/routes/onboarding.tsx",
		children: void 0,
		preloads: [
			"/assets/onboarding-bXdQNylH.js",
			"/assets/useNavigate-Ba7i6G5s.js",
			"/assets/label-O02CFeLj.js"
		]
	},
	"/partners": {
		filePath: "/workspace/src/routes/partners.tsx",
		children: void 0,
		preloads: ["/assets/partners-D7PXYDLv.js", "/assets/label-O02CFeLj.js"]
	},
	"/playbook": {
		filePath: "/workspace/src/routes/playbook.tsx",
		children: void 0,
		preloads: ["/assets/playbook-CA2kzzYr.js"]
	},
	"/pricing": {
		filePath: "/workspace/src/routes/pricing.tsx",
		children: void 0,
		preloads: [
			"/assets/pricing-BEIOQMoU.js",
			"/assets/check-C-i78GgP.js",
			"/assets/badge-HmzmGn9n.js"
		]
	},
	"/studio": {
		filePath: "/workspace/src/routes/studio.tsx",
		children: void 0,
		preloads: [
			"/assets/studio-CmwQfRIa.js",
			"/assets/badge-HmzmGn9n.js",
			"/assets/totals-2GWPHwmV.js"
		]
	},
	"/checkout/success": {
		filePath: "/workspace/src/routes/checkout/success.tsx",
		children: void 0,
		preloads: ["/assets/success-D6HwUdIL.js"]
	},
	"/journal/$slug": {
		filePath: "/workspace/src/routes/journal/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-eXG3T6qQ.js"]
	},
	"/legal/$slug": {
		filePath: "/workspace/src/routes/legal/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-BMh2cmK9.js"]
	},
	"/shop/$slug": {
		filePath: "/workspace/src/routes/shop/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-CLm_-GmT.js", "/assets/check-C-i78GgP.js"]
	},
	"/tools/rates": {
		filePath: "/workspace/src/routes/tools/rates.tsx",
		children: void 0,
		preloads: [
			"/assets/rates-Co9PfaSu.js",
			"/assets/label-O02CFeLj.js",
			"/assets/totals-2GWPHwmV.js"
		]
	},
	"/tools/time": {
		filePath: "/workspace/src/routes/tools/time.tsx",
		children: void 0,
		preloads: [
			"/assets/time-BOBg5azO.js",
			"/assets/label-O02CFeLj.js",
			"/assets/upgrade-dialog-Bhsy72Er.js"
		]
	},
	"/checkout/": {
		filePath: "/workspace/src/routes/checkout/index.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-DaUPsCdL.js",
			"/assets/useNavigate-Ba7i6G5s.js",
			"/assets/label-O02CFeLj.js"
		]
	},
	"/journal/": {
		filePath: "/workspace/src/routes/journal/index.tsx",
		children: void 0,
		preloads: ["/assets/journal-D1d6fXox.js"]
	},
	"/shop/": {
		filePath: "/workspace/src/routes/shop/index.tsx",
		children: void 0,
		preloads: ["/assets/shop-KC20hRjp.js"]
	},
	"/tools/": {
		filePath: "/workspace/src/routes/tools/index.tsx",
		children: void 0,
		preloads: ["/assets/tools-C-SIbdxl.js", "/assets/pen-line-CsWTkv-k.js"]
	},
	"/tools/invoices/$invoiceId": {
		filePath: "/workspace/src/routes/tools/invoices/$invoiceId.tsx",
		children: void 0,
		preloads: [
			"/assets/_invoiceId-D07ebiwA.js",
			"/assets/useNavigate-Ba7i6G5s.js",
			"/assets/trash-2-DLIzNH5o.js",
			"/assets/label-O02CFeLj.js",
			"/assets/paper-CGS6elfQ.js"
		]
	},
	"/tools/proposals/$proposalId": {
		filePath: "/workspace/src/routes/tools/proposals/$proposalId.tsx",
		children: void 0,
		preloads: [
			"/assets/_proposalId-Cwa8EiiQ.js",
			"/assets/useNavigate-Ba7i6G5s.js",
			"/assets/trash-2-DLIzNH5o.js",
			"/assets/label-O02CFeLj.js",
			"/assets/paper-CGS6elfQ.js"
		]
	},
	"/tools/invoices/": {
		filePath: "/workspace/src/routes/tools/invoices/index.tsx",
		children: void 0,
		preloads: [
			"/assets/invoices-DVjNl9b5.js",
			"/assets/useNavigate-Ba7i6G5s.js",
			"/assets/badge-HmzmGn9n.js",
			"/assets/totals-2GWPHwmV.js",
			"/assets/upgrade-dialog-Bhsy72Er.js"
		]
	},
	"/tools/proposals/": {
		filePath: "/workspace/src/routes/tools/proposals/index.tsx",
		children: void 0,
		preloads: [
			"/assets/proposals-DS17UmMT.js",
			"/assets/useNavigate-Ba7i6G5s.js",
			"/assets/badge-HmzmGn9n.js",
			"/assets/totals-2GWPHwmV.js",
			"/assets/upgrade-dialog-Bhsy72Er.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
