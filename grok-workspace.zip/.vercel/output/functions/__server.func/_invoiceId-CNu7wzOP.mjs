import { i as __toESM } from "./_runtime.mjs";
import { c as uid } from "./_ssr/utils-DXWKSffG.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useNavigate, Y as require_jsx_runtime, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./_ssr/button-CbyLMWg1.mjs";
import { c as useStudio, n as Textarea, t as Input } from "./_ssr/input-D498PH2S.mjs";
import { a as Printer, o as Plus, r as Trash2 } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { r as Route$2, u as useHydrated } from "./_ssr/router-Ba3nbWFA.mjs";
import { t as Label } from "./_ssr/label-D3Zuzywy.mjs";
import { t as InvoicePaper } from "./_ssr/paper-B6Jf_iVX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_invoiceId-CNu7wzOP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"draft",
	"sent",
	"paid",
	"overdue"
];
function InvoiceEditor() {
	const { invoiceId } = Route$2.useParams();
	const hydrated = useHydrated();
	const navigate = useNavigate();
	const invoices = useStudio((s) => s.invoices);
	const updateInvoice = useStudio((s) => s.updateInvoice);
	const removeInvoice = useStudio((s) => s.removeInvoice);
	const invoice = (0, import_react.useMemo)(() => invoices.find((i) => i.id === invoiceId), [invoices, invoiceId]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-6xl px-4 py-16",
		children: "Loading…"
	});
	if (!invoice) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-6 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-serif text-3xl",
			children: "That invoice is not on this desk"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/tools/invoices",
				children: "Back to invoices"
			})
		})]
	});
	const current = invoice;
	function patch(p) {
		updateInvoice(invoiceId, p);
	}
	function patchParty(side, key, value) {
		patch({ [side]: {
			...current[side],
			[key]: value
		} });
	}
	function patchItem(id, key, value) {
		patch({ items: current.items.map((item) => item.id === id ? {
			...item,
			[key]: value
		} : item) });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/tools/invoices",
						className: "text-sm text-muted hover:text-fg",
						children: "All invoices"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => window.print(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), "Print / PDF"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => {
								removeInvoice(invoiceId);
								toast("Invoice removed");
								navigate({ to: "/tools/invoices" });
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Number",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: current.number,
								onChange: (e) => patch({ number: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Status",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: current.status,
								onChange: (e) => patch({ status: e.target.value }),
								className: "flex h-11 w-full rounded-md border border-border bg-bg-elevated px-3 text-sm",
								children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: s,
									children: s
								}, s))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Issued",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: current.issuedOn,
								onChange: (e) => patch({ issuedOn: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Due",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: current.dueOn,
								onChange: (e) => patch({ dueOn: e.target.value })
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid gap-6 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-medium",
								children: "From"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Studio",
								value: current.from.name,
								onChange: (e) => patchParty("from", "name", e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Email",
								value: current.from.email,
								onChange: (e) => patchParty("from", "email", e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								placeholder: "Address",
								value: current.from.address,
								onChange: (e) => patchParty("from", "address", e.target.value)
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-medium",
								children: "Client"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Client",
								value: current.client.name,
								onChange: (e) => patchParty("client", "name", e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Email",
								value: current.client.email,
								onChange: (e) => patchParty("client", "email", e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								placeholder: "Address",
								value: current.client.address,
								onChange: (e) => patchParty("client", "address", e.target.value)
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Line items"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 space-y-3",
							children: current.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-2 sm:grid-cols-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "Description",
										value: item.description,
										onChange: (e) => patchItem(item.id, "description", e.target.value)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "decimal",
										value: item.quantity,
										onChange: (e) => patchItem(item.id, "quantity", Number(e.target.value)),
										"aria-label": "Quantity"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "decimal",
										value: item.rate,
										onChange: (e) => patchItem(item.id, "rate", Number(e.target.value)),
										"aria-label": "Rate"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "ghost",
										size: "icon",
										className: "size-11",
										onClick: () => patch({ items: current.items.filter((i) => i.id !== item.id) }),
										"aria-label": "Remove line",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
									})
								]
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							className: "mt-3",
							onClick: () => patch({ items: [...current.items, {
								id: uid(),
								description: "",
								quantity: 1,
								rate: 0
							}] }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add line"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tax %",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "decimal",
							value: current.taxRate,
							onChange: (e) => patch({ taxRate: Number(e.target.value) })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Currency",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: current.currency,
							onChange: (e) => patch({ currency: e.target.value.toUpperCase() })
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Notes",
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: current.notes,
						onChange: (e) => patch({ notes: e.target.value })
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoicePaper, { invoice: current }) })]
	});
}
function Field({ label, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			className: "mb-2 block",
			children: label
		}), children]
	});
}
//#endregion
export { InvoiceEditor as component };
