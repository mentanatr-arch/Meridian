import { i as __toESM } from "../_runtime.mjs";
import { a as money, n as cn } from "./utils-DXWKSffG.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { d as planPrice, i as PLANS, n as FAQS } from "./catalog-CwQVHlis.mjs";
import { f as Check } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-CfRB2lJt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pricing-CNxZcA5v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Pricing() {
	const [billing, setBilling] = (0, import_react.useState)("annual");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
				children: "Pricing"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-serif text-5xl tracking-tight",
				children: "Free until the paper is real"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-lg text-muted",
				children: "Starter is a working desk, not a demo. Pro is for the independent who outgrew three invoices. Studio is for a practice with a roster."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 inline-flex rounded-full bg-bg-subtle p-1",
				children: ["monthly", "annual"].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setBilling(b),
					className: cn("h-10 rounded-full px-4 text-sm font-medium capitalize", billing === b ? "bg-bg-elevated text-fg shadow-[var(--shadow-border)]" : "text-muted"),
					children: b === "annual" ? "Annual · two months free" : "Monthly"
				}, b))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-4 lg:grid-cols-3",
				children: PLANS.map((plan) => {
					const price = planPrice(plan.id, billing);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex flex-col rounded-2xl p-6 shadow-[var(--shadow-border)]", plan.highlight ? "bg-ink text-cream" : "bg-bg-elevated text-fg"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: plan.name
								}), plan.highlight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									className: "bg-cream text-ink",
									children: "Most independents"
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 font-serif text-5xl tracking-tight tabular-nums",
								children: price === 0 ? "Free" : money(price)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("mt-1 text-sm", plan.highlight ? "text-cream/60" : "text-muted"),
								children: price === 0 ? "Forever, with a ceiling" : billing === "annual" ? "per year" : "per month"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("mt-3 text-sm", plan.highlight ? "text-cream/70" : "text-muted"),
								children: plan.blurb
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-6 flex-1 space-y-2",
								children: plan.features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0" }), f]
								}, f))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: cn("mt-8", plan.highlight && "bg-cream text-ink hover:bg-cream/90"),
								variant: plan.highlight ? "secondary" : plan.id === "starter" ? "outline" : "default",
								children: plan.id === "starter" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/onboarding",
									children: plan.cta
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/checkout",
									search: {
										plan: plan.id,
										billing
									},
									children: plan.cta
								})
							})
						]
					}, plan.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-3xl tracking-tight",
					children: "Questions, priced honestly"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "mt-8 divide-y divide-border border-y border-border",
					children: FAQS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 py-5 md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.2fr)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-medium",
							children: f.q
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-sm leading-relaxed text-muted",
							children: f.a
						})]
					}, f.q))
				})]
			})
		]
	});
}
//#endregion
export { Pricing as component };
