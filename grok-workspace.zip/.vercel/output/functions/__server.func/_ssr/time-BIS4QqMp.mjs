import { i as __toESM } from "../_runtime.mjs";
import { c as uid, i as hoursMinutes, o as moneyExact } from "./utils-DXWKSffG.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { c as useStudio, i as PROJECT_LIMIT, o as blankInvoice, t as Input } from "./input-D498PH2S.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { u as useHydrated } from "./router-Ba3nbWFA.mjs";
import { t as Label } from "./label-D3Zuzywy.mjs";
import { t as UpgradeWall } from "./upgrade-dialog-BDHMrEi1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/time-BIS4QqMp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TimePage() {
	const hydrated = useHydrated();
	const entries = useStudio((s) => s.entries);
	useStudio((s) => s.plan);
	const profile = useStudio((s) => s.profile);
	const startTimer = useStudio((s) => s.startTimer);
	const stopTimer = useStudio((s) => s.stopTimer);
	const removeEntry = useStudio((s) => s.removeEntry);
	const addInvoice = useStudio((s) => s.addInvoice);
	const nextInvoiceNumber = useStudio((s) => s.nextInvoiceNumber);
	const [project, setProject] = (0, import_react.useState)("Harbor sprint");
	const [note, setNote] = (0, import_react.useState)("");
	const [now, setNow] = (0, import_react.useState)(Date.now());
	const [wall, setWall] = (0, import_react.useState)(false);
	const running = entries.find((e) => e.endedAt === null);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		const id = window.setInterval(() => setNow(Date.now()), 250);
		return () => window.clearInterval(id);
	}, [running]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-6xl px-4 py-16",
		children: "Loading…"
	});
	const elapsed = running ? (now - running.startedAt) / 1e3 : 0;
	function start() {
		if (!startTimer(project.trim() || "Untitled", note, profile.defaultRate).ok) {
			setWall(true);
			toast("Starter includes three projects.");
		}
	}
	function billSelected() {
		const closed = entries.filter((e) => e.endedAt && e.billable);
		if (closed.length === 0) {
			toast("No closed billable hours yet.");
			return;
		}
		const byProject = /* @__PURE__ */ new Map();
		for (const e of closed) {
			const hrs = (e.endedAt - e.startedAt) / 36e5;
			byProject.set(e.project, (byProject.get(e.project) ?? 0) + hrs);
		}
		const invoice = blankInvoice(profile, nextInvoiceNumber());
		invoice.items = [...byProject.entries()].map(([name, hrs]) => ({
			id: uid(),
			description: `${name} — tracked time`,
			quantity: Math.round(hrs * 10) / 10,
			rate: profile.defaultRate
		}));
		if (!addInvoice(invoice).ok) {
			setWall(true);
			return;
		}
		toast("Invoice drafted from time.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-12 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl tracking-tight",
				children: "Time"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-muted",
				children: [
					"One running clock. Starter holds ",
					PROJECT_LIMIT.starter,
					" projects."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 rounded-2xl bg-ink p-8 text-center text-cream",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-6xl tracking-tight tabular-nums sm:text-7xl",
						children: hoursMinutes(running ? elapsed : 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-cream/50",
						children: running ? running.project : "Idle"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 flex justify-center gap-3",
						children: running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "bg-cream text-ink hover:bg-cream/90",
							onClick: stopTimer,
							children: "Stop"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "bg-cream text-ink hover:bg-cream/90",
							onClick: start,
							children: "Start"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "mb-2 block",
					children: "Project"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: project,
					onChange: (e) => setProject(e.target.value)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "mb-2 block",
					children: "Note"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: note,
					onChange: (e) => setNote(e.target.value)
				})] })]
			}),
			wall ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpgradeWall, { body: "Starter includes three time projects. Pro tracks the whole roster." })
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: billSelected,
					children: "Draft invoice from hours"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "ghost",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/tools/invoices",
						children: "Invoices"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-10 divide-y divide-border rounded-2xl bg-bg-elevated shadow-[var(--shadow-border)]",
				children: entries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "p-6 text-sm text-muted",
					children: "No entries yet. Start the clock."
				}) : entries.map((e) => {
					const end = e.endedAt ?? now;
					const secs = Math.max(0, (end - e.startedAt) / 1e3);
					const amount = secs / 3600 * e.rate;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-4 px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: e.project
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								e.note || "—",
								" · ",
								hoursMinutes(secs),
								e.endedAt === null ? " · running" : ""
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm tabular-nums text-muted",
								children: moneyExact(amount, profile.currency)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-sm text-muted hover:text-danger",
								onClick: () => removeEntry(e.id),
								children: "Remove"
							})]
						})]
					}, e.id);
				})
			})
		]
	});
}
//#endregion
export { TimePage as component };
