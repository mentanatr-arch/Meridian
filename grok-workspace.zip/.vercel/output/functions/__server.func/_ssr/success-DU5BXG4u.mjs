import { o as moneyExact } from "./utils-DXWKSffG.mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { o as PRODUCTS } from "./catalog-CwQVHlis.mjs";
import { c as useStudio } from "./input-D498PH2S.mjs";
import { s as Route$12, u as useHydrated } from "./router-Ba3nbWFA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/success-DU5BXG4u.js
var import_jsx_runtime = require_jsx_runtime();
function Success() {
	const { order: orderId } = Route$12.useSearch();
	const hydrated = useHydrated();
	const orders = useStudio((s) => s.orders);
	const order = orders.find((o) => o.id === orderId) ?? orders[0];
	const attach = PRODUCTS[0];
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-xl px-4 py-16",
		children: "Loading…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-4 py-20 text-center sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
				children: "Paid · preview"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-serif text-5xl tracking-tight",
				children: "You are on the desk"
			}),
			order ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-muted",
				children: [
					"Order ",
					order.id,
					" · ",
					moneyExact(order.total, order.currency),
					" · ",
					order.email
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children: "Receipt is on this device."
			}),
			order?.plan ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [
					"Plan: ",
					order.plan.id,
					" (",
					order.plan.billing,
					")"
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap justify-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/studio",
						children: "Open studio"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/playbook",
						children: "Read the playbook"
					})
				})]
			}),
			attach ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-14 rounded-2xl bg-bg-elevated p-6 text-left shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Most independents add this next"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-serif text-2xl",
						children: attach.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: attach.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "mt-4",
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/shop/$slug",
							params: { slug: attach.slug },
							children: "View kit"
						})
					})
				]
			}) : null
		]
	});
}
//#endregion
export { Success as component };
