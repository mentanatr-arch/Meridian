import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as FAQS } from "./catalog-CwQVHlis.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faq-DNC0lYSb.js
var import_jsx_runtime = require_jsx_runtime();
function Faq() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-16 sm:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-serif text-5xl tracking-tight",
			children: "FAQ"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "mt-10 divide-y divide-border border-y border-border",
			children: FAQS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "font-serif text-2xl tracking-tight",
					children: f.q
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: f.a
				})]
			}, f.q))
		})]
	});
}
//#endregion
export { Faq as component };
