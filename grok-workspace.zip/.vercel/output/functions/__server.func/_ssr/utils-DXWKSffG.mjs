import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-DXWKSffG.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	return crypto.randomUUID();
}
function money(value, currency = "USD", digits = 0) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency,
		maximumFractionDigits: digits,
		minimumFractionDigits: digits
	}).format(Number.isFinite(value) ? value : 0);
}
function moneyExact(value, currency = "USD") {
	return money(value, currency, 2);
}
function formatDate(iso) {
	if (!iso) return "";
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return iso;
	return new Intl.DateTimeFormat("en-US", {
		month: "short",
		day: "numeric",
		year: "numeric"
	}).format(d);
}
function todayIso() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function addDaysIso(days, from = todayIso()) {
	const d = /* @__PURE__ */ new Date(from + "T12:00:00");
	d.setDate(d.getDate() + days);
	return d.toISOString().slice(0, 10);
}
function hoursMinutes(totalSeconds) {
	const s = Math.max(0, Math.floor(totalSeconds));
	return [
		Math.floor(s / 3600),
		Math.floor(s % 3600 / 60),
		s % 60
	].map((n) => String(n).padStart(2, "0")).join(":");
}
//#endregion
export { money as a, uid as c, hoursMinutes as i, cn as n, moneyExact as o, formatDate as r, todayIso as s, addDaysIso as t };
