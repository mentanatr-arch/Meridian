import { i as __toESM } from "../_runtime.mjs";
import { n as cn } from "./utils-DXWKSffG.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as useRouter, Y as require_jsx_runtime, _ as Outlet, b as createRootRoute, f as Scripts, g as createRouter, m as useRouterState, p as HeadContent, v as lazyRouteComponent, x as Link, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { s as SITE } from "./catalog-CwQVHlis.mjs";
import { c as useStudio, t as Input } from "./input-D498PH2S.mjs";
import { c as Menu, i as ShoppingBag, n as TriangleAlert, t as X } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Ba3nbWFA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setHydrated(true), []);
	return hydrated;
}
var NAV = [
	{
		to: "/tools",
		label: "Tools"
	},
	{
		to: "/pricing",
		label: "Pricing"
	},
	{
		to: "/shop",
		label: "Shop"
	},
	{
		to: "/journal",
		label: "Journal"
	},
	{
		to: "/playbook",
		label: "Playbook"
	}
];
function Mark({ className, inverted = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: cn("flex items-center gap-2", inverted ? "text-cream" : "text-fg", className),
		"aria-label": "Meridian home",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 32 32",
			className: "size-7",
			"aria-hidden": "true",
			fill: "none",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "32",
					height: "32",
					rx: "8",
					className: inverted ? "fill-cream" : "fill-primary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M8 22c8-2 8-12 16-14",
					className: inverted ? "stroke-ink" : "stroke-primary-fg",
					strokeWidth: "1.6",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "16",
					cy: "16",
					r: "2",
					className: inverted ? "fill-ink" : "fill-primary-fg"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-serif text-xl tracking-tight",
			children: "Meridian"
		})]
	});
}
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const hydrated = useHydrated();
	const cartCount = useStudio((s) => s.cart.reduce((n, c) => n + c.quantity, 0));
	const count = hydrated ? cartCount : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "no-print sticky top-0 z-40 border-b border-border/80 bg-bg/85 backdrop-blur-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-7 md:flex",
					"aria-label": "Primary",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: cn("text-sm font-medium text-muted transition-colors duration-150 hover:text-fg", pathname.startsWith(item.to) && "text-fg"),
						children: item.label
					}, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/checkout",
							className: "relative inline-flex size-11 items-center justify-center rounded-md text-fg hover:bg-bg-subtle",
							"aria-label": "Cart",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-5" }), count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute top-1.5 right-1.5 flex size-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-fg tabular-nums",
								children: count
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "hidden sm:inline-flex",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/studio",
								children: "Open studio"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center rounded-md md:hidden",
							"aria-label": open ? "Close menu" : "Open menu",
							onClick: () => setOpen((v) => !v),
							children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						})
					]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border bg-bg px-4 py-4 md:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex flex-col gap-1",
				"aria-label": "Mobile",
				children: [NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: item.to,
					onClick: () => setOpen(false),
					className: "flex h-11 items-center text-base font-medium text-fg",
					children: item.label
				}, item.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-2 w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/studio",
						onClick: () => setOpen(false),
						children: "Open studio"
					})
				})]
			})
		}) : null]
	});
}
function Newsletter({ variant = "paper", className }) {
	const subscribe = useStudio((s) => s.subscribe);
	const [email, setEmail] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: cn("w-full max-w-md", className),
		onSubmit: (e) => {
			e.preventDefault();
			if (!email.includes("@")) return;
			subscribe(email.trim());
			setDone(true);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-xs font-medium tracking-[0.14em] uppercase", variant === "ink" ? "text-cream/50" : "text-muted"),
				children: "The Monday rate note"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-1 text-sm", variant === "ink" ? "text-cream/70" : "text-muted"),
				children: "One useful number or clause. No tools roundup."
			}),
			done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-3 text-sm font-medium", variant === "ink" ? "text-cream" : "text-primary"),
				children: "You are on the list. See you Monday."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "email",
					required: true,
					value: email,
					onChange: (e) => setEmail(e.target.value),
					placeholder: "you@studio.com",
					className: variant === "ink" ? "border-cream/15 bg-ink text-cream placeholder:text-cream/40" : void 0,
					"aria-label": "Email address"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: variant === "ink" ? "secondary" : "default",
					className: variant === "ink" ? "bg-cream text-ink hover:bg-cream/90" : void 0,
					children: "Join"
				})]
			})
		]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "no-print border-t border-border bg-ink text-cream",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.3fr_1fr_1fr_1fr]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { inverted: true }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 max-w-sm text-sm leading-relaxed text-cream/70",
						children: [
							SITE.tagline,
							" ",
							SITE.description
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm text-cream/50",
						children: SITE.email
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterCol, {
					title: "Product",
					links: [
						{
							to: "/studio",
							label: "Studio"
						},
						{
							to: "/tools",
							label: "Tools"
						},
						{
							to: "/pricing",
							label: "Pricing"
						},
						{
							to: "/shop",
							label: "Shop"
						}
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterCol, {
					title: "Learn",
					links: [
						{
							to: "/journal",
							label: "Journal"
						},
						{
							to: "/playbook",
							label: "Playbook"
						},
						{
							to: "/faq",
							label: "FAQ"
						},
						{
							to: "/partners",
							label: "Partners"
						}
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.14em] text-cream/50 uppercase",
					children: "Company"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							className: "text-sm text-cream/80 transition-colors duration-150 hover:text-cream",
							children: "About"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/legal/$slug",
							params: { slug: "terms" },
							className: "text-sm text-cream/80 transition-colors duration-150 hover:text-cream",
							children: "Terms"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/legal/$slug",
							params: { slug: "privacy" },
							className: "text-sm text-cream/80 transition-colors duration-150 hover:text-cream",
							children: "Privacy"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/legal/$slug",
							params: { slug: "refunds" },
							className: "text-sm text-cream/80 transition-colors duration-150 hover:text-cream",
							children: "Refunds"
						}) })
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-cream/10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-8 px-4 py-10 sm:px-6 lg:flex-row lg:items-end lg:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Newsletter, { variant: "ink" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-cream/40",
					children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" Meridian Labs. Paper, rates, and time for independents."
					]
				})]
			})
		})]
	});
}
function FooterCol({ title, links }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-medium tracking-[0.14em] text-cream/50 uppercase",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-4 space-y-2",
		children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: link.to,
			className: "text-sm text-cream/80 transition-colors duration-150 hover:text-cream",
			children: link.label
		}) }, link.to))
	})] });
}
function Seed() {
	const seedIfNeeded = useStudio((s) => s.seedIfNeeded);
	(0, import_react.useEffect)(() => {
		seedIfNeeded();
	}, [seedIfNeeded]);
	return null;
}
function SiteShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#content",
				className: "sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-fg",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seed, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "content",
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
var styles_default = "/assets/styles-DZJhtYa7.css";
var APP_NAME = "Meridian";
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-6 py-24 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-serif text-4xl tracking-tight",
				children: "This page is not on the map"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children: "The meridian you asked for does not exist. Try the studio, the shop, or the journal."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/",
				className: "mt-8 inline-flex h-11 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-fg",
				children: "Back to Meridian"
			})
		]
	});
}
var Route$22 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Meridian is the operating system for independent professionals — invoices, rates, proposals, and time."
			},
			{
				name: "theme-color",
				content: "#F3EFE6"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,400;0,500;0,600;1,400&family=IBM+Plex+Mono:wght@400;500&family=Instrument+Serif:ital@0;1&display=swap"
			}
		]
	}),
	notFoundComponent: NotFound,
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "bottom-right",
				toastOptions: { className: "font-sans bg-bg-elevated text-fg border border-border shadow-[var(--shadow-border)]" }
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$21 = () => import("./routes-C8M252NP.mjs");
var Route$21 = createFileRoute("/")({
	component: lazyRouteComponent($$splitComponentImporter$21, "component"),
	head: () => ({ meta: [{ title: "Meridian — Get paid like a studio" }, {
		name: "description",
		content: SITE.description
	}] })
});
var $$splitComponentImporter$20 = () => import("./about-C_6xGwXh.mjs");
var Route$20 = createFileRoute("/about")({
	component: lazyRouteComponent($$splitComponentImporter$20, "component"),
	head: () => ({ meta: [{ title: "About — Meridian" }] })
});
var $$splitComponentImporter$19 = () => import("./faq-DNC0lYSb.mjs");
var Route$19 = createFileRoute("/faq")({
	component: lazyRouteComponent($$splitComponentImporter$19, "component"),
	head: () => ({ meta: [{ title: "FAQ — Meridian" }] })
});
var $$splitComponentImporter$18 = () => import("./onboarding-WH08I6G_.mjs");
var Route$18 = createFileRoute("/onboarding")({
	component: lazyRouteComponent($$splitComponentImporter$18, "component"),
	head: () => ({ meta: [{ title: "Open your studio — Meridian" }] })
});
var $$splitComponentImporter$17 = () => import("./partners-C3GeOrhH.mjs");
var Route$17 = createFileRoute("/partners")({
	component: lazyRouteComponent($$splitComponentImporter$17, "component"),
	head: () => ({ meta: [{ title: "Partners — Meridian" }, {
		name: "description",
		content: "Earn 30% on Meridian software and 15% on kits for 12 months. Terms in writing."
	}] })
});
var $$splitComponentImporter$16 = () => import("./playbook-BA6CPsv9.mjs");
var Route$16 = createFileRoute("/playbook")({
	component: lazyRouteComponent($$splitComponentImporter$16, "component"),
	head: () => ({ meta: [{ title: "Playbook — How to run Meridian" }, {
		name: "description",
		content: "The operating manual: money model, funnel, daily rhythm, and how to take Meridian live."
	}] })
});
var $$splitComponentImporter$15 = () => import("./pricing-CNxZcA5v.mjs");
var Route$15 = createFileRoute("/pricing")({
	component: lazyRouteComponent($$splitComponentImporter$15, "component"),
	head: () => ({ meta: [{ title: "Pricing — Meridian" }, {
		name: "description",
		content: "Starter is free. Pro is $19 a month. Studio is $49. Annual is ten months for twelve."
	}] })
});
var $$splitComponentImporter$14 = () => import("./studio-B-3Wk9P0.mjs");
var Route$14 = createFileRoute("/studio")({
	component: lazyRouteComponent($$splitComponentImporter$14, "component"),
	head: () => ({ meta: [{ title: "Studio — Meridian" }] })
});
var $$splitComponentImporter$13 = () => import("./checkout-rHCc8trU.mjs");
var Route$13 = createFileRoute("/checkout/")({
	validateSearch: (s) => ({
		plan: typeof s.plan === "string" ? s.plan : void 0,
		billing: typeof s.billing === "string" ? s.billing : void 0
	}),
	component: lazyRouteComponent($$splitComponentImporter$13, "component"),
	head: () => ({ meta: [{ title: "Checkout — Meridian" }] })
});
var $$splitComponentImporter$12 = () => import("./success-DU5BXG4u.mjs");
var Route$12 = createFileRoute("/checkout/success")({
	validateSearch: (s) => ({ order: typeof s.order === "string" ? s.order : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component"),
	head: () => ({ meta: [{ title: "Receipt — Meridian" }] })
});
var $$splitComponentImporter$11 = () => import("./journal-Ddl6Lx5B.mjs");
var Route$11 = createFileRoute("/journal/")({
	component: lazyRouteComponent($$splitComponentImporter$11, "component"),
	head: () => ({ meta: [{ title: "Journal — Meridian" }, {
		name: "description",
		content: "Essays on rates, invoices, scope, and time for independent professionals."
	}] })
});
var $$splitComponentImporter$10 = () => import("../_slug-BHu1pHhA.mjs");
var Route$10 = createFileRoute("/journal/$slug")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("../_slug-C2YufSRk.mjs");
var Route$9 = createFileRoute("/legal/$slug")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./shop-g7KZwmod.mjs");
var Route$8 = createFileRoute("/shop/")({
	component: lazyRouteComponent($$splitComponentImporter$8, "component"),
	head: () => ({ meta: [{ title: "Shop — Meridian" }, {
		name: "description",
		content: "Contracts, rate cards, proposals, and a studio brand kit — digital paper for independents."
	}] })
});
var $$splitComponentImporter$7 = () => import("../_slug-B8tonOLN.mjs");
var Route$7 = createFileRoute("/shop/$slug")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./tools-B4dt1S7l.mjs");
var Route$6 = createFileRoute("/tools/")({
	component: lazyRouteComponent($$splitComponentImporter$6, "component"),
	head: () => ({ meta: [{ title: "Tools — Meridian" }] })
});
var $$splitComponentImporter$5 = () => import("./rates-BKKXag2l.mjs");
var Route$5 = createFileRoute("/tools/rates")({
	component: lazyRouteComponent($$splitComponentImporter$5, "component"),
	head: () => ({ meta: [{ title: "Rate calculator — Meridian" }, {
		name: "description",
		content: "Price the year first. Meridian turns income, hours, overhead, tax, and profit into an hourly you can defend."
	}] })
});
var $$splitComponentImporter$4 = () => import("./time-BIS4QqMp.mjs");
var Route$4 = createFileRoute("/tools/time")({
	component: lazyRouteComponent($$splitComponentImporter$4, "component"),
	head: () => ({ meta: [{ title: "Time — Meridian" }] })
});
var $$splitComponentImporter$3 = () => import("./invoices-CEqeVNYN.mjs");
var Route$3 = createFileRoute("/tools/invoices/")({
	component: lazyRouteComponent($$splitComponentImporter$3, "component"),
	head: () => ({ meta: [{ title: "Invoices — Meridian" }] })
});
var $$splitComponentImporter$2 = () => import("../_invoiceId-CNu7wzOP.mjs");
var Route$2 = createFileRoute("/tools/invoices/$invoiceId")({
	component: lazyRouteComponent($$splitComponentImporter$2, "component"),
	head: () => ({ meta: [{ title: "Invoice — Meridian" }] })
});
var $$splitComponentImporter$1 = () => import("./proposals-Dbc32QaD.mjs");
var Route$1 = createFileRoute("/tools/proposals/")({
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	head: () => ({ meta: [{ title: "Proposals — Meridian" }] })
});
var $$splitComponentImporter = () => import("../_proposalId-B_ixf40A.mjs");
var Route = createFileRoute("/tools/proposals/$proposalId")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: () => ({ meta: [{ title: "Proposal — Meridian" }] })
});
var IndexRoute = Route$21.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$22
});
var AboutRoute = Route$20.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$22
});
var FaqRoute = Route$19.update({
	id: "/faq",
	path: "/faq",
	getParentRoute: () => Route$22
});
var OnboardingRoute = Route$18.update({
	id: "/onboarding",
	path: "/onboarding",
	getParentRoute: () => Route$22
});
var PartnersRoute = Route$17.update({
	id: "/partners",
	path: "/partners",
	getParentRoute: () => Route$22
});
var PlaybookRoute = Route$16.update({
	id: "/playbook",
	path: "/playbook",
	getParentRoute: () => Route$22
});
var PricingRoute = Route$15.update({
	id: "/pricing",
	path: "/pricing",
	getParentRoute: () => Route$22
});
var StudioRoute = Route$14.update({
	id: "/studio",
	path: "/studio",
	getParentRoute: () => Route$22
});
var CheckoutIndexRoute = Route$13.update({
	id: "/checkout/",
	path: "/checkout/",
	getParentRoute: () => Route$22
});
var CheckoutSuccessRoute = Route$12.update({
	id: "/checkout/success",
	path: "/checkout/success",
	getParentRoute: () => Route$22
});
var JournalIndexRoute = Route$11.update({
	id: "/journal/",
	path: "/journal/",
	getParentRoute: () => Route$22
});
var JournalSlugRoute = Route$10.update({
	id: "/journal/$slug",
	path: "/journal/$slug",
	getParentRoute: () => Route$22
});
var LegalSlugRoute = Route$9.update({
	id: "/legal/$slug",
	path: "/legal/$slug",
	getParentRoute: () => Route$22
});
var ShopIndexRoute = Route$8.update({
	id: "/shop/",
	path: "/shop/",
	getParentRoute: () => Route$22
});
var ShopSlugRoute = Route$7.update({
	id: "/shop/$slug",
	path: "/shop/$slug",
	getParentRoute: () => Route$22
});
var ToolsIndexRoute = Route$6.update({
	id: "/tools/",
	path: "/tools/",
	getParentRoute: () => Route$22
});
var ToolsRatesRoute = Route$5.update({
	id: "/tools/rates",
	path: "/tools/rates",
	getParentRoute: () => Route$22
});
var ToolsTimeRoute = Route$4.update({
	id: "/tools/time",
	path: "/tools/time",
	getParentRoute: () => Route$22
});
var ToolsInvoicesIndexRoute = Route$3.update({
	id: "/tools/invoices/",
	path: "/tools/invoices/",
	getParentRoute: () => Route$22
});
var ToolsInvoicesInvoiceIdRoute = Route$2.update({
	id: "/tools/invoices/$invoiceId",
	path: "/tools/invoices/$invoiceId",
	getParentRoute: () => Route$22
});
var ToolsProposalsIndexRoute = Route$1.update({
	id: "/tools/proposals/",
	path: "/tools/proposals/",
	getParentRoute: () => Route$22
});
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	FaqRoute,
	OnboardingRoute,
	PartnersRoute,
	PlaybookRoute,
	PricingRoute,
	StudioRoute,
	CheckoutSuccessRoute,
	JournalSlugRoute,
	LegalSlugRoute,
	ShopSlugRoute,
	ToolsRatesRoute,
	ToolsTimeRoute,
	CheckoutIndexRoute,
	JournalIndexRoute,
	ShopIndexRoute,
	ToolsIndexRoute,
	ToolsInvoicesInvoiceIdRoute,
	ToolsProposalsProposalIdRoute: Route.update({
		id: "/tools/proposals/$proposalId",
		path: "/tools/proposals/$proposalId",
		getParentRoute: () => Route$22
	}),
	ToolsInvoicesIndexRoute,
	ToolsProposalsIndexRoute
};
var routeTree = Route$22._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Route$9 as a, Route$13 as c, Route$7 as i, Newsletter as l, Route as n, Route$10 as o, Route$2 as r, Route$12 as s, router_exports as t, useHydrated as u };
