import { a as money } from "./utils-DXWKSffG.mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { c as useStudio, t as Input } from "./input-D498PH2S.mjs";
import { l as Newsletter, u as useHydrated } from "./router-Ba3nbWFA.mjs";
import { t as Label } from "./label-D3Zuzywy.mjs";
import { t as computeRate } from "./totals-BiPAWs6l.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rates-BKKXag2l.js
var import_jsx_runtime = require_jsx_runtime();
function Field({ label, suffix, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
		className: "mb-2 block",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			inputMode: "decimal",
			value: Number.isFinite(value) ? value : 0,
			onChange: (e) => onChange(Number(e.target.value))
		}), suffix ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-sm text-subtle",
			children: suffix
		}) : null]
	})] });
}
function Rates() {
	const hydrated = useHydrated();
	const rate = useStudio((s) => s.rate);
	const setRate = useStudio((s) => s.setRate);
	const model = computeRate(rate);
	const chart = [
		{
			name: "Life",
			value: rate.desired
		},
		{
			name: "Overhead",
			value: model.withOverhead - rate.desired
		},
		{
			name: "Profit",
			value: model.withProfit - model.withOverhead
		},
		{
			name: "Tax reserve",
			value: model.gross - model.withProfit
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-12 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
				children: "Price from the year"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-serif text-5xl tracking-tight",
				children: "Price the year"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-lg text-muted",
				children: "Independents go broke on hourly vibes. This calculator funds a life, then divides by the hours you can actually sell."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Desired yearly income",
							value: rate.desired,
							onChange: (n) => setRate({ desired: n })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Weeks you will work",
								value: rate.weeks,
								onChange: (n) => setRate({ weeks: n })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Hours on the clock / week",
								value: rate.hoursPerWeek,
								onChange: (n) => setRate({ hoursPerWeek: n })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Utilization — hours you can sell",
							suffix: "%",
							value: rate.utilization,
							onChange: (n) => setRate({ utilization: n })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Overhead",
							suffix: "%",
							value: rate.overhead,
							onChange: (n) => setRate({ overhead: n })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Tax reserve",
							suffix: "%",
							value: rate.tax,
							onChange: (n) => setRate({ tax: n })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Profit buffer",
							suffix: "%",
							value: rate.profit,
							onChange: (n) => setRate({ profit: n })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-subtle",
							children: ["Saved on this device. ", hydrated ? "Your numbers persist." : ""]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-ink p-8 text-cream",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-cream/60",
								children: "Your defendable hourly"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-serif text-6xl tracking-tight tabular-nums",
								children: money(model.hourly, rate.currency)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-8 grid grid-cols-2 gap-4 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-cream/50",
										children: "Day (8h)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-serif text-2xl tabular-nums",
										children: money(model.dayRate8, rate.currency)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-cream/50",
										children: "Week"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-serif text-2xl tabular-nums",
										children: money(model.weekly, rate.currency)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-cream/50",
										children: "Billable hours / year"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-serif text-2xl tabular-nums",
										children: Math.round(model.billableHours)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-cream/50",
										children: "Gross to collect"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-serif text-2xl tabular-nums",
										children: money(model.gross, rate.currency)
									})] })
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 h-56 rounded-2xl bg-bg-elevated p-4 shadow-[var(--shadow-border)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: chart,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "name",
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										},
										tickFormatter: (v) => `${Math.round(Number(v) / 1e3)}k`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										formatter: (v) => money(Number(v), rate.currency),
										contentStyle: {
											background: "var(--color-bg-elevated)",
											border: "1px solid var(--color-border)",
											borderRadius: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "value",
										fill: "var(--color-primary)",
										radius: [
											6,
											6,
											0,
											0
										]
									})
								]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/tools/invoices",
								children: "Put it on an invoice"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/journal/$slug",
								params: { slug: "rate-that-holds" },
								children: "Read the arithmetic"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Newsletter, {})
					})
				] })]
			})
		]
	});
}
//#endregion
export { Rates as component };
