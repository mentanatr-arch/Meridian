import { a as money } from "./utils-DXWKSffG.mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { c as TESTIMONIALS, i as PLANS, o as PRODUCTS, r as LOGOS, t as ARTICLES } from "./catalog-CwQVHlis.mjs";
import { d as Clock, l as Gauge, p as ArrowRight, s as PenLine, u as FileText } from "../_libs/lucide-react.mjs";
import { t as InvoicePaper } from "./paper-B6Jf_iVX.mjs";
import { t as Badge } from "./badge-CfRB2lJt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C8M252NP.js
var import_jsx_runtime = require_jsx_runtime();
var DEMO_INVOICE = {
	id: "demo",
	number: "INV-1042",
	status: "sent",
	issuedOn: "2026-09-22",
	dueOn: "2026-10-06",
	from: {
		name: "North Studio",
		email: "studio@north.example",
		address: "14 Mercer, Floor 3"
	},
	client: {
		name: "Harbor & Co.",
		email: "accounts@harbor.co",
		address: "88 Atlantic, Brooklyn"
	},
	items: [{
		id: "1",
		description: "Identity system — wordmark, type, paper",
		quantity: 1,
		rate: 8400
	}, {
		id: "2",
		description: "Launch collateral — three applications",
		quantity: 1,
		rate: 2600
	}],
	taxRate: 0,
	notes: "Due within 14 days. Transfer details on file.",
	currency: "USD"
};
var TOOLS = [
	{
		to: "/tools/rates",
		icon: Gauge,
		title: "Rate calculator",
		text: "Price the year, then the hour. Overhead, tax, and profit in one sitting."
	},
	{
		to: "/tools/invoices",
		icon: FileText,
		title: "Invoice studio",
		text: "Paper that looks like a practice. Print or save as PDF the same day the work lands."
	},
	{
		to: "/tools/proposals",
		icon: PenLine,
		title: "Proposals",
		text: "Scope, fence, timeline, investment. A yes that becomes an invoice without retyping."
	},
	{
		to: "/tools/time",
		icon: Clock,
		title: "Time",
		text: "A quiet timer. Hours roll into the bill so you stop reconstructing the week."
	}
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-b border-border bg-bg-subtle",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mx-auto max-w-6xl px-4 py-2.5 text-center text-sm text-fg sm:px-6",
				children: [
					"Studio annual — two months on us through October.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/pricing",
						className: "font-medium underline-offset-4 hover:underline",
						children: "See pricing"
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rise-in text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
					children: "For independent professionals"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "rise-in mt-4 font-serif text-5xl leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl",
					children: "Get paid like a studio."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rise-in mt-6 max-w-lg text-lg leading-relaxed text-muted",
					children: "Invoices, rates, proposals, and time — one desk for people who bill for thinking. Free to start. Beautiful enough to send."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/onboarding",
							children: ["Start free", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tools/rates",
							children: "Price your year"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-sm text-subtle",
					children: "No card. Three invoices. A rate you can defend."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -inset-4 -z-10 rounded-[2rem] bg-bg-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "origin-top scale-[0.92] sm:scale-100",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoicePaper, { invoice: DEMO_INVOICE })
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-border bg-bg-elevated",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-6xl grid-cols-2 gap-8 px-4 py-10 sm:grid-cols-4 sm:px-6",
				children: [
					["$48.2M", "Invoiced on paper like this"],
					["14,800", "Independents on the desk"],
					["7 days", "Median time to paid"],
					["4.9", "From 2,140 studio reviews"]
				].map(([n, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-serif text-3xl tracking-tight tabular-nums",
					children: n
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: l
				})] }, l))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-20 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs tracking-[0.16em] text-subtle uppercase",
				children: "Quiet rooms, serious practices"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex flex-wrap items-center justify-center gap-x-10 gap-y-3",
				children: LOGOS.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-serif text-lg text-muted",
					children: name
				}, name))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-6xl px-4 pb-8 sm:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 sm:grid-cols-2",
				children: TOOLS.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: tool.to,
					className: "group rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 hover:shadow-[var(--shadow-border-hover)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(tool.icon, { className: "size-5 text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-serif text-2xl tracking-tight",
							children: tool.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: tool.text
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary",
							children: ["Open", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 transition-transform duration-150 group-hover:translate-x-0.5" })]
						})
					]
				}, tool.to))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
					children: "How it works"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-4xl tracking-tight",
					children: "Price the year. Send the paper. Get paid."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 space-y-6",
					children: [
						["Run the rate", "A life, a calendar, overhead, tax, profit. The hour falls out of the year — not the other way around."],
						["Put it on paper", "Invoices and proposals share line items. The fence is on page two, not buried in paragraph nineteen."],
						["Keep the clock honest", "Time becomes the invoice. Starter is free until the work is real; Pro is $19 when you outgrow three bills."]
					].map(([t, d], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-serif text-2xl text-primary tabular-nums",
							children: ["0", i + 1]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: t
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm leading-relaxed text-muted",
							children: d
						})] })]
					}, t))
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/desk.jpg",
				alt: "A quiet desk with cream paper, a fountain pen, and morning light",
				className: "h-[420px] w-full rounded-2xl object-cover"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-ink text-cream",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 py-20 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-4xl tracking-tight",
					children: "In their words"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-6 lg:grid-cols-3",
					children: TESTIMONIALS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "rounded-2xl border border-cream/10 bg-ink p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
							className: "text-base leading-relaxed text-cream/90",
							children: t.quote
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
							className: "mt-6 text-sm text-cream/55",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-cream",
								children: t.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 block",
								children: t.role
							})]
						})]
					}, t.name))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-20 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-4xl tracking-tight",
					children: "Simple plans"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Start free. Grow when the paper does."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/pricing",
					className: "hidden text-sm font-medium text-primary sm:inline-flex",
					children: "Full comparison"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-4 md:grid-cols-3",
				children: PLANS.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: plan.name
							}), plan.highlight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Most independents" }) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 font-serif text-4xl tracking-tight tabular-nums",
							children: [plan.monthly === 0 ? "Free" : money(plan.monthly), plan.monthly > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-base text-muted",
								children: " / mo"
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: plan.blurb
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "mt-6",
							variant: plan.highlight ? "default" : "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/pricing",
								children: plan.cta
							})
						})
					]
				}, plan.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 pb-20 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-4xl tracking-tight",
					children: "The desk shop"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/shop",
					className: "text-sm font-medium text-primary",
					children: "All kits"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
				children: PRODUCTS.slice(0, 3).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/shop/$slug",
					params: { slug: p.slug },
					className: "group",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: p.cover,
							alt: "",
							className: "aspect-3/4 w-full rounded-xl object-cover transition-transform duration-250 group-hover:scale-[1.01]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: p.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm tabular-nums text-muted",
								children: money(p.price)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: p.blurb
						})
					]
				}, p.slug))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border bg-bg-elevated",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 py-20 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-4xl tracking-tight",
					children: "From the journal"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-8 lg:grid-cols-3",
					children: ARTICLES.slice(0, 3).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/journal/$slug",
						params: { slug: a.slug },
						className: "group",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: a.cover,
								alt: "",
								className: "h-48 w-full rounded-xl object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 text-xs tracking-[0.14em] text-subtle uppercase",
								children: [
									a.tags[0],
									" · ",
									a.minutes,
									" min"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-serif text-2xl tracking-tight group-hover:text-primary",
								children: a.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: a.dek
							})
						]
					}, a.slug))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-3xl px-4 py-24 text-center sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-4xl tracking-tight sm:text-5xl",
					children: "Open the desk. Send the first invoice today."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted",
					children: "Starter is free. The paper is yours. Upgrade when three invoices are no longer enough."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/onboarding",
							children: "Start free"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/playbook",
							children: "Read the playbook"
						})
					})]
				})
			]
		})
	] });
}
//#endregion
export { Home as component };
