//#region node_modules/.nitro/vite/services/ssr/assets/totals-BiPAWs6l.js
function lineAmount(item) {
	return (Number(item.quantity) || 0) * (Number(item.rate) || 0);
}
function subtotalOf(items) {
	return items.reduce((sum, item) => sum + lineAmount(item), 0);
}
function taxOf(items, taxRate) {
	return subtotalOf(items) * ((Number(taxRate) || 0) / 100);
}
function totalOf(items, taxRate) {
	return subtotalOf(items) + taxOf(items, taxRate);
}
function computeRate(model) {
	const weeks = Math.max(1, model.weeks || 0);
	const hoursPerWeek = Math.max(1, model.hoursPerWeek || 0);
	const utilization = Math.min(100, Math.max(1, model.utilization || 0)) / 100;
	const billableHours = weeks * hoursPerWeek * utilization;
	const overhead = Math.max(0, model.overhead || 0) / 100;
	const tax = Math.min(80, Math.max(0, model.tax || 0)) / 100;
	const profit = Math.max(0, model.profit || 0) / 100;
	const withOverhead = Math.max(0, model.desired || 0) * (1 + overhead);
	const withProfit = withOverhead * (1 + profit);
	const gross = tax >= .99 ? withProfit : withProfit / (1 - tax);
	const hourly = billableHours > 0 ? gross / billableHours : 0;
	return {
		billableHours,
		gross,
		withOverhead,
		withProfit,
		hourly,
		daily: hourly * Math.min(hoursPerWeek, 8),
		weekly: hourly * (hoursPerWeek * utilization),
		dayRate8: hourly * 8
	};
}
//#endregion
export { totalOf as a, taxOf as i, lineAmount as n, subtotalOf as r, computeRate as t };
