import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { a as PLAYBOOK } from "./catalog-CwQVHlis.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/playbook-BA6CPsv9.js
var import_jsx_runtime = require_jsx_runtime();
function Playbook() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
				children: "Operator manual"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-serif text-5xl tracking-tight",
				children: "How to run Meridian"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-lg leading-relaxed text-muted",
				children: "Use it as your freelance OS. Or treat the whole site as the company — software, shop, journal, partners. This is the order of operations."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "mt-10 rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.14em] text-subtle uppercase",
					children: "Contents"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-3 columns-1 gap-6 sm:columns-2",
					children: PLAYBOOK.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "break-inside-avoid py-1 text-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `#${s.id}`,
							className: "text-fg hover:text-primary",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-muted",
									children: String(i + 1).padStart(2, "0")
								}),
								" ",
								s.title
							]
						})
					}, s.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-16 space-y-16",
				children: PLAYBOOK.map((section, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: section.id,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-serif text-primary tabular-nums",
							children: String(i + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-serif text-3xl tracking-tight",
							children: section.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 space-y-4",
							children: section.paragraphs.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "leading-relaxed text-fg",
								children: p
							}, p.slice(0, 48)))
						})
					]
				}, section.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-16 rounded-2xl bg-ink p-8 text-cream",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-3xl tracking-tight",
						children: "First move: send a real invoice"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-cream/70",
						children: "Everything else is commentary until money has moved on this paper."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "bg-cream text-ink hover:bg-cream/90",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/onboarding",
								children: "Open the studio"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							className: "border-cream/20 text-cream hover:bg-cream/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/tools/rates",
								children: "Run the rate"
							})
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Playbook as component };
