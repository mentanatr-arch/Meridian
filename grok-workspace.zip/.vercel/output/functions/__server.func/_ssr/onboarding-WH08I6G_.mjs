import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useNavigate, Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { c as useStudio, n as Textarea, t as Input } from "./input-D498PH2S.mjs";
import { t as Label } from "./label-D3Zuzywy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/onboarding-WH08I6G_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Onboarding() {
	const navigate = useNavigate();
	const profile = useStudio((s) => s.profile);
	const setProfile = useStudio((s) => s.setProfile);
	const setRate = useStudio((s) => s.setRate);
	const [step, setStep] = (0, import_react.useState)(0);
	const [form, setForm] = (0, import_react.useState)({
		name: profile.name === "Your studio" ? "" : profile.name,
		owner: profile.owner,
		email: profile.email,
		address: profile.address,
		currency: profile.currency,
		desired: "140000",
		defaultRate: String(profile.defaultRate)
	});
	function patch(key, value) {
		setForm((f) => ({
			...f,
			[key]: value
		}));
	}
	function finish() {
		setProfile({
			name: form.name || "Your studio",
			owner: form.owner,
			email: form.email,
			address: form.address,
			currency: form.currency,
			defaultRate: Number(form.defaultRate) || 150,
			onboarded: true
		});
		setRate({
			desired: Number(form.desired) || 14e4,
			currency: form.currency
		});
		navigate({ to: "/studio" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
				children: [
					"Step ",
					step + 1,
					" of 3"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-3 font-serif text-4xl tracking-tight",
				children: [
					step === 0 && "Name the practice",
					step === 1 && "Where should money land",
					step === 2 && "What should the year fund"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "This writes your letterhead. You can change it later in Studio."
			}),
			step === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "studio",
						children: "Studio name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "studio",
						value: form.name,
						onChange: (e) => patch("name", e.target.value),
						placeholder: "North Studio"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "owner",
						children: "Your name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "owner",
						value: form.owner,
						onChange: (e) => patch("owner", e.target.value),
						placeholder: "Ada North"
					})]
				})]
			}) : null,
			step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "email",
							children: "Invoice email"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "email",
							type: "email",
							value: form.email,
							onChange: (e) => patch("email", e.target.value),
							placeholder: "studio@north.example"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "address",
							children: "Address on the paper"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "address",
							value: form.address,
							onChange: (e) => patch("address", e.target.value),
							placeholder: "14 Mercer\nFloor 3"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "currency",
							children: "Currency"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "currency",
							value: form.currency,
							onChange: (e) => patch("currency", e.target.value),
							className: "flex h-11 w-full rounded-md border border-border bg-bg-elevated px-3 text-sm",
							children: [
								"USD",
								"EUR",
								"GBP",
								"CAD",
								"AUD"
							].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
						})]
					})
				]
			}) : null,
			step === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "desired",
							children: "Desired yearly income"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "desired",
							inputMode: "numeric",
							value: form.desired,
							onChange: (e) => patch("desired", e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "The life, not the hustle number. The calculator will do the rest."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "rate",
						children: "Starting hourly (you can ignore this)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "rate",
						inputMode: "numeric",
						value: form.defaultRate,
						onChange: (e) => patch("defaultRate", e.target.value)
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex gap-3",
				children: [step > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: () => setStep((s) => s - 1),
					children: "Back"
				}) : null, step < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => setStep((s) => s + 1),
					children: "Continue"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: finish,
					children: "Open the studio"
				})]
			})
		]
	});
}
//#endregion
export { Onboarding as component };
