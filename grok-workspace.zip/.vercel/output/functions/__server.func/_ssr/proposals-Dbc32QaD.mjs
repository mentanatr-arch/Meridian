import { i as __toESM } from "../_runtime.mjs";
import { o as moneyExact, r as formatDate } from "./utils-DXWKSffG.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useNavigate, Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { a as PROPOSAL_LIMIT, c as useStudio, s as blankProposal } from "./input-D498PH2S.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { u as useHydrated } from "./router-Ba3nbWFA.mjs";
import { a as totalOf } from "./totals-BiPAWs6l.mjs";
import { t as Badge } from "./badge-CfRB2lJt.mjs";
import { t as UpgradeWall } from "./upgrade-dialog-BDHMrEi1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/proposals-Dbc32QaD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Proposals() {
	const hydrated = useHydrated();
	const navigate = useNavigate();
	const proposals = useStudio((s) => s.proposals);
	const profile = useStudio((s) => s.profile);
	const plan = useStudio((s) => s.plan);
	const addProposal = useStudio((s) => s.addProposal);
	const nextProposalNumber = useStudio((s) => s.nextProposalNumber);
	const [wall, setWall] = (0, import_react.useState)(false);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-6xl px-4 py-16",
		children: "Loading…"
	});
	function create() {
		const proposal = blankProposal(profile, nextProposalNumber());
		if (!addProposal(proposal).ok) {
			setWall(true);
			toast("Starter includes one proposal.");
			return;
		}
		navigate({
			to: "/tools/proposals/$proposalId",
			params: { proposalId: proposal.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-12 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-4xl tracking-tight",
					children: "Proposals"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted",
					children: [
						proposals.length,
						Number.isFinite(PROPOSAL_LIMIT[plan]) ? ` / ${PROPOSAL_LIMIT[plan]}` : "",
						" — a yes should become an invoice."
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: create,
					children: "New proposal"
				})]
			}),
			wall ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpgradeWall, { body: "Starter includes one proposal. Pro is unlimited paper, and a yes becomes an invoice without retyping." })
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 divide-y divide-border overflow-hidden rounded-2xl bg-bg-elevated shadow-[var(--shadow-border)]",
				children: proposals.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-10 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-2xl",
						children: "No proposals yet"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Write the fence first. The number second."
					})]
				}) : proposals.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/tools/proposals/$proposalId",
					params: { proposalId: p.id },
					className: "flex flex-col gap-2 px-6 py-4 hover:bg-bg-subtle/60 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							p.number,
							" · ",
							p.title
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							p.client.name || "No client",
							" · ",
							formatDate(p.issuedOn)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: p.status === "accepted" ? "paid" : "draft",
							children: p.status
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: moneyExact(totalOf(p.items, p.taxRate), p.currency)
						})]
					})]
				}, p.id))
			})
		]
	});
}
//#endregion
export { Proposals as component };
