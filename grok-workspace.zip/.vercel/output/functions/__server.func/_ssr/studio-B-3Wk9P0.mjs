import { i as __toESM } from "../_runtime.mjs";
import { a as money, o as moneyExact, r as formatDate } from "./utils-DXWKSffG.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { c as useStudio } from "./input-D498PH2S.mjs";
import { u as useHydrated } from "./router-Ba3nbWFA.mjs";
import { a as totalOf, t as computeRate } from "./totals-BiPAWs6l.mjs";
import { t as Badge } from "./badge-CfRB2lJt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio-B-3Wk9P0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Studio() {
	const hydrated = useHydrated();
	const seedIfNeeded = useStudio((s) => s.seedIfNeeded);
	const profile = useStudio((s) => s.profile);
	const plan = useStudio((s) => s.plan);
	const invoices = useStudio((s) => s.invoices);
	const proposals = useStudio((s) => s.proposals);
	const entries = useStudio((s) => s.entries);
	const rate = useStudio((s) => s.rate);
	(0, import_react.useEffect)(() => {
		seedIfNeeded();
	}, [seedIfNeeded]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6",
		children: "Loading studio…"
	});
	const outstanding = invoices.filter((i) => i.status === "sent" || i.status === "overdue").reduce((s, i) => s + totalOf(i.items, i.taxRate), 0);
	const paid = invoices.filter((i) => i.status === "paid").reduce((s, i) => s + totalOf(i.items, i.taxRate), 0);
	const weekAgo = Date.now() - 6048e5;
	const hours = entries.reduce((s, e) => {
		const end = e.endedAt ?? Date.now();
		if (end < weekAgo) return s;
		return s + Math.max(0, (end - Math.max(e.startedAt, weekAgo)) / 1e3);
	}, 0) / 3600;
	const model = computeRate(rate);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-12 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
						children: profile.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-4xl tracking-tight",
						children: "Studio"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted",
						children: [
							profile.owner ? `Welcome back, ${profile.owner}.` : "Your desk.",
							" Plan:",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "capitalize",
								children: plan
							})
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [!profile.onboarded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/onboarding",
							children: "Set letterhead"
						})
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tools/invoices",
							children: "New invoice"
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Outstanding",
						value: moneyExact(outstanding, profile.currency)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Collected (on paper)",
						value: moneyExact(paid, profile.currency)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Hours this week",
						value: `${hours.toFixed(1)}h`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Saved rate model"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 font-serif text-4xl tabular-nums",
							children: [money(model.hourly, rate.currency), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg text-muted",
								children: " / hr"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								money(model.dayRate8, rate.currency),
								" day · ",
								Math.round(model.billableHours),
								" ",
								"billable hours / year"
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tools/rates",
							children: "Adjust the year"
						})
					})]
				})
			}),
			plan === "starter" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-3 rounded-2xl border border-border bg-bg-subtle px-6 py-5 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						"Starter: ",
						invoices.length,
						"/3 invoices · ",
						proposals.length,
						"/1 proposal. Pro is unlimited paper."
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					size: "sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/pricing",
						children: "Upgrade"
					})
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl tracking-tight",
						children: "Recent invoices"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/tools/invoices",
						className: "text-sm font-medium text-primary",
						children: "All invoices"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 divide-y divide-border rounded-2xl bg-bg-elevated shadow-[var(--shadow-border)]",
					children: invoices.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-6 text-sm text-muted",
						children: "No invoices yet."
					}) : invoices.slice(0, 5).map((inv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/tools/invoices/$invoiceId",
						params: { invoiceId: inv.id },
						className: "flex items-center justify-between gap-4 px-6 py-4 hover:bg-bg-subtle/50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-medium",
							children: [
								inv.number,
								" · ",
								inv.client.name || "No client"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: formatDate(inv.issuedOn)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: inv.status,
								children: inv.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "tabular-nums",
								children: moneyExact(totalOf(inv.items, inv.taxRate), inv.currency)
							})]
						})]
					}, inv.id))
				})]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-serif text-3xl tracking-tight tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { Studio as component };
