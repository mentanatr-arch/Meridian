import { i as __toESM } from "../_runtime.mjs";
import { o as moneyExact, r as formatDate } from "./utils-DXWKSffG.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useNavigate, Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { c as useStudio, o as blankInvoice, r as INVOICE_LIMIT } from "./input-D498PH2S.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { u as useHydrated } from "./router-Ba3nbWFA.mjs";
import { a as totalOf } from "./totals-BiPAWs6l.mjs";
import { t as Badge } from "./badge-CfRB2lJt.mjs";
import { t as UpgradeWall } from "./upgrade-dialog-BDHMrEi1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/invoices-CEqeVNYN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Invoices() {
	const hydrated = useHydrated();
	const navigate = useNavigate();
	const seedIfNeeded = useStudio((s) => s.seedIfNeeded);
	const invoices = useStudio((s) => s.invoices);
	const profile = useStudio((s) => s.profile);
	const plan = useStudio((s) => s.plan);
	const addInvoice = useStudio((s) => s.addInvoice);
	const nextInvoiceNumber = useStudio((s) => s.nextInvoiceNumber);
	const [wall, setWall] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		seedIfNeeded();
	}, [seedIfNeeded]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-6xl px-4 py-16",
		children: "Loading…"
	});
	function create() {
		const invoice = blankInvoice(profile, nextInvoiceNumber());
		if (!addInvoice(invoice).ok) {
			setWall(true);
			toast("Starter includes three invoices.");
			return;
		}
		navigate({
			to: "/tools/invoices/$invoiceId",
			params: { invoiceId: invoice.id }
		});
	}
	const limit = INVOICE_LIMIT[plan];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-12 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-4xl tracking-tight",
					children: "Invoices"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted",
					children: [
						invoices.length,
						Number.isFinite(limit) ? ` / ${limit}` : "",
						" on this desk"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: create,
					children: "New invoice"
				})]
			}),
			wall ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpgradeWall, {})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 divide-y divide-border overflow-hidden rounded-2xl bg-bg-elevated shadow-[var(--shadow-border)]",
				children: invoices.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-10 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-2xl",
						children: "No paper yet"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Create the first invoice. Starter includes three."
					})]
				}) : invoices.map((inv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/tools/invoices/$invoiceId",
					params: { invoiceId: inv.id },
					className: "flex flex-col gap-2 px-6 py-4 hover:bg-bg-subtle/60 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							inv.number,
							" · ",
							inv.client.name || "Untitled client"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							formatDate(inv.issuedOn),
							" · due ",
							formatDate(inv.dueOn)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: inv.status,
							children: inv.status
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: moneyExact(totalOf(inv.items, inv.taxRate), inv.currency)
						})]
					})]
				}, inv.id))
			})
		]
	});
}
//#endregion
export { Invoices as component };
