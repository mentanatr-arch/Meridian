import { n as cn, o as moneyExact, r as formatDate } from "./utils-DXWKSffG.mjs";
import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as totalOf, i as taxOf, n as lineAmount, r as subtotalOf } from "./totals-BiPAWs6l.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/paper-B6Jf_iVX.js
var import_jsx_runtime = require_jsx_runtime();
function PartyBlock({ label, name, email, address }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium tracking-[0.16em] text-muted uppercase",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-serif text-lg leading-snug",
			children: name || "—"
		}),
		email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: email
		}) : null,
		address ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 whitespace-pre-line text-sm text-muted",
			children: address
		}) : null
	] });
}
function InvoicePaper({ invoice, className }) {
	const sub = subtotalOf(invoice.items);
	const tax = taxOf(invoice.items, invoice.taxRate);
	const total = totalOf(invoice.items, invoice.taxRate);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("print-paper rounded-xl bg-bg-elevated p-8 text-fg shadow-[var(--shadow-border)] sm:p-12", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-6 border-b border-border pb-8 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
					children: "Meridian"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-serif text-4xl tracking-tight",
					children: "Invoice"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm sm:text-right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium tabular-nums",
							children: invoice.number
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-muted",
							children: ["Issued ", formatDate(invoice.issuedOn)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted",
							children: ["Due ", formatDate(invoice.dueOn)]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-8 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartyBlock, {
					label: "From",
					...invoice.from
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartyBlock, {
					label: "Bill to",
					...invoice.client
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "mt-10 w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-border text-left text-[11px] tracking-[0.14em] text-muted uppercase",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 font-medium",
							children: "Description"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-right font-medium",
							children: "Qty"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-right font-medium",
							children: "Rate"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-right font-medium",
							children: "Amount"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: invoice.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-border/70",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3 pr-4",
							children: item.description || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3 text-right tabular-nums",
							children: item.quantity
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3 text-right tabular-nums",
							children: moneyExact(item.rate, invoice.currency)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3 text-right tabular-nums",
							children: moneyExact(lineAmount(item), invoice.currency)
						})
					]
				}, item.id)) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "w-full max-w-xs space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Subtotal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: moneyExact(sub, invoice.currency)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", { children: [
								"Tax ",
								invoice.taxRate,
								"%"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: moneyExact(tax, invoice.currency)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between border-t border-border pt-2 font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-serif text-2xl tabular-nums",
								children: moneyExact(total, invoice.currency)
							})]
						})
					]
				})
			}),
			invoice.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 whitespace-pre-line text-sm leading-relaxed text-muted",
				children: invoice.notes
			}) : null
		]
	});
}
function ProposalPaper({ proposal, className }) {
	const total = totalOf(proposal.items, proposal.taxRate);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("print-paper rounded-xl bg-bg-elevated p-8 text-fg shadow-[var(--shadow-border)] sm:p-12", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
				children: proposal.number
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 font-serif text-4xl tracking-tight",
				children: proposal.title || "Proposal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [
					formatDate(proposal.issuedOn),
					" · Valid through",
					" ",
					formatDate(proposal.validUntil)
				]
			}),
			proposal.summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 max-w-2xl text-lg leading-relaxed text-fg",
				children: proposal.summary
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-8 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartyBlock, {
					label: "From",
					...proposal.from
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartyBlock, {
					label: "Prepared for",
					...proposal.client
				})]
			}),
			proposal.scope ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-[11px] font-medium tracking-[0.16em] text-muted uppercase",
					children: "Scope"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 whitespace-pre-line text-sm leading-relaxed",
					children: proposal.scope
				})]
			}) : null,
			proposal.timeline ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-[11px] font-medium tracking-[0.16em] text-muted uppercase",
					children: "Timeline"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 whitespace-pre-line text-sm leading-relaxed",
					children: proposal.timeline
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-[11px] font-medium tracking-[0.16em] text-muted uppercase",
						children: "Investment"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-2",
						children: proposal.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-4 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.description || "—" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: moneyExact(lineAmount(item), proposal.currency)
							})]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-serif text-3xl tabular-nums",
						children: moneyExact(total, proposal.currency)
					})
				]
			}),
			proposal.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 whitespace-pre-line text-sm leading-relaxed text-muted",
				children: proposal.notes
			}) : null
		]
	});
}
//#endregion
export { ProposalPaper as n, InvoicePaper as t };
