import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as SITE } from "./catalog-CwQVHlis.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-C_6xGwXh.js
var import_jsx_runtime = require_jsx_runtime();
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
				children: "About"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-serif text-5xl tracking-tight",
				children: "A desk for people who invoice for thinking"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-lg leading-relaxed text-muted",
				children: "Meridian started as the internal paper of a small studio that was tired of looking cheaper than the work. The invoices were the product. The software came after."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/images/studio.jpg",
			alt: "Empty studio with oak table and north light",
			className: "h-[420px] w-full rounded-2xl object-cover"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-4 pb-20 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "leading-relaxed",
				children: "We build for independents and rooms of two to eight — designers, writers, strategists, engineers — who already know how to do the work and keep getting paid late, or too little, or both. We do not build for enterprises, or for people who need a social feed in their invoicing tool."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 leading-relaxed",
				children: "The name is a line of longitude: a true north you can take a rate from. The look is cream, ink, and one forest green because paper should feel like a studio, not a dashboard."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-5 leading-relaxed text-muted",
				children: [SITE.email, " · Independent practice, not a venture story."]
			})
		]
	})] });
}
//#endregion
export { About as component };
