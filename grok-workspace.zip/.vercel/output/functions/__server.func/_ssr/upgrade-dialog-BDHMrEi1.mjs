import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/upgrade-dialog-BDHMrEi1.js
var import_jsx_runtime = require_jsx_runtime();
function UpgradeWall({ title = "Starter has a ceiling, on purpose", body = "Three invoices and one proposal are enough to feel the paper. Pro is unlimited — $19 a month, or $190 a year." }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-ink p-8 text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-3xl tracking-tight",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-xl text-sm leading-relaxed text-cream/70",
				children: body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "bg-cream text-ink hover:bg-cream/90",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/pricing",
						children: "See plans"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					className: "border-cream/20 text-cream hover:bg-cream/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/playbook",
						children: "Why the ceiling exists"
					})
				})]
			})
		]
	});
}
//#endregion
export { UpgradeWall as t };
