import "../_runtime.mjs";
import { c as uid, n as cn, s as todayIso, t as addDaysIso } from "./utils-DXWKSffG.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as planPrice, o as PRODUCTS } from "./catalog-CwQVHlis.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-DS2ns9BF.js
var defaultParty = {
	name: "",
	email: "",
	address: ""
};
var defaultProfile = {
	name: "Your studio",
	owner: "",
	email: "",
	address: "",
	website: "",
	currency: "USD",
	defaultRate: 150,
	onboarded: false
};
var defaultRate = {
	desired: 14e4,
	weeks: 46,
	hoursPerWeek: 32,
	utilization: 60,
	overhead: 22,
	tax: 28,
	profit: 15,
	currency: "USD"
};
function sampleInvoice(profile) {
	return {
		id: "sample-inv-1",
		number: "INV-1042",
		status: "paid",
		issuedOn: addDaysIso(-18),
		dueOn: addDaysIso(-4),
		from: {
			name: profile.name || "North Studio",
			email: profile.email || "studio@example.com",
			address: profile.address || "14 Mercer, Floor 3"
		},
		client: {
			name: "Harbor & Co.",
			email: "accounts@harbor.co",
			address: "88 Atlantic, Brooklyn"
		},
		items: [{
			id: uid(),
			description: "Identity system — wordmark, type, paper",
			quantity: 1,
			rate: 8400
		}, {
			id: uid(),
			description: "Launch collateral — three applications",
			quantity: 1,
			rate: 2600
		}],
		taxRate: 0,
		notes: "Paid via transfer · thank you for the quiet brief.",
		currency: profile.currency || "USD"
	};
}
var INVOICE_LIMIT = {
	starter: 3,
	pro: Infinity,
	studio: Infinity
};
var PROPOSAL_LIMIT = {
	starter: 1,
	pro: Infinity,
	studio: Infinity
};
var PROJECT_LIMIT = {
	starter: 3,
	pro: Infinity,
	studio: Infinity
};
var useStudio = create()(persist((set, get) => ({
	profile: defaultProfile,
	plan: "starter",
	billing: "monthly",
	invoices: [],
	proposals: [],
	entries: [],
	rate: defaultRate,
	cart: [],
	orders: [],
	emails: [],
	seeded: false,
	setProfile: (patch) => set((s) => ({ profile: {
		...s.profile,
		...patch
	} })),
	setPlan: (plan, billing) => set((s) => ({
		plan,
		billing: billing ?? s.billing
	})),
	setRate: (patch) => set((s) => ({ rate: {
		...s.rate,
		...patch
	} })),
	addInvoice: (invoice) => {
		const { invoices, plan } = get();
		if (invoices.length >= INVOICE_LIMIT[plan]) return {
			ok: false,
			reason: "limit"
		};
		set({ invoices: [invoice, ...invoices] });
		return { ok: true };
	},
	updateInvoice: (id, patch) => set((s) => ({ invoices: s.invoices.map((inv) => inv.id === id ? {
		...inv,
		...patch
	} : inv) })),
	removeInvoice: (id) => set((s) => ({ invoices: s.invoices.filter((inv) => inv.id !== id) })),
	addProposal: (proposal) => {
		const { proposals, plan } = get();
		if (proposals.length >= PROPOSAL_LIMIT[plan]) return {
			ok: false,
			reason: "limit"
		};
		set({ proposals: [proposal, ...proposals] });
		return { ok: true };
	},
	updateProposal: (id, patch) => set((s) => ({ proposals: s.proposals.map((p) => p.id === id ? {
		...p,
		...patch
	} : p) })),
	removeProposal: (id) => set((s) => ({ proposals: s.proposals.filter((p) => p.id !== id) })),
	startTimer: (project, note, rate) => {
		const { entries, plan } = get();
		const running = entries.find((e) => e.endedAt === null);
		if (running) set({ entries: entries.map((e) => e.id === running.id ? {
			...e,
			endedAt: Date.now()
		} : e) });
		const projects = new Set(get().entries.map((e) => e.project).filter(Boolean));
		projects.add(project);
		if (projects.size > PROJECT_LIMIT[plan]) return {
			ok: false,
			reason: "limit"
		};
		set({ entries: [{
			id: uid(),
			project,
			note,
			startedAt: Date.now(),
			endedAt: null,
			billable: true,
			rate
		}, ...get().entries] });
		return { ok: true };
	},
	stopTimer: () => set((s) => ({ entries: s.entries.map((e) => e.endedAt === null ? {
		...e,
		endedAt: Date.now()
	} : e) })),
	removeEntry: (id) => set((s) => ({ entries: s.entries.filter((e) => e.id !== id) })),
	addToCart: (slug) => set((s) => {
		if (s.cart.find((c) => c.slug === slug)) return { cart: s.cart.map((c) => c.slug === slug ? {
			...c,
			quantity: c.quantity + 1
		} : c) };
		return { cart: [...s.cart, {
			slug,
			quantity: 1
		}] };
	}),
	removeFromCart: (slug) => set((s) => ({ cart: s.cart.filter((c) => c.slug !== slug) })),
	setCartQty: (slug, quantity) => set((s) => ({ cart: quantity <= 0 ? s.cart.filter((c) => c.slug !== slug) : s.cart.map((c) => c.slug === slug ? {
		...c,
		quantity
	} : c) })),
	clearCart: () => set({ cart: [] }),
	placeOrder: ({ name, email, withPlan }) => {
		const { cart, orders, profile } = get();
		const items = cart.map((c) => {
			const product = PRODUCTS.find((p) => p.slug === c.slug);
			if (!product) return null;
			return {
				slug: product.slug,
				title: product.title,
				price: product.price,
				quantity: c.quantity
			};
		}).filter(Boolean);
		const goods = items.reduce((s, i) => s + i.price * i.quantity, 0);
		const planTotal = withPlan ? planPrice(withPlan.id, withPlan.billing) : 0;
		const order = {
			id: uid().slice(0, 8).toUpperCase(),
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			email,
			name,
			items,
			plan: withPlan ? {
				id: withPlan.id,
				billing: withPlan.billing,
				price: planTotal
			} : void 0,
			total: goods + planTotal,
			currency: profile.currency || "USD"
		};
		set({
			orders: [order, ...orders],
			cart: [],
			emails: get().emails.includes(email) ? get().emails : [email, ...get().emails]
		});
		if (withPlan) get().setPlan(withPlan.id, withPlan.billing);
		if (name) get().setProfile({
			owner: name,
			email,
			onboarded: true
		});
		return order;
	},
	subscribe: (email) => set((s) => ({ emails: s.emails.includes(email) ? s.emails : [email, ...s.emails] })),
	seedIfNeeded: () => {
		if (get().seeded) return;
		const profile = get().profile;
		set({
			seeded: true,
			invoices: get().invoices.length ? get().invoices : [sampleInvoice(profile)]
		});
	},
	nextInvoiceNumber: () => {
		return `INV-${get().invoices.length + 1042}`;
	},
	nextProposalNumber: () => {
		return `PR-${get().proposals.length + 220}`;
	}
}), { name: "meridian-studio" }));
function blankInvoice(profile, number) {
	return {
		id: uid(),
		number,
		status: "draft",
		issuedOn: todayIso(),
		dueOn: addDaysIso(14),
		from: {
			name: profile.name,
			email: profile.email,
			address: profile.address
		},
		client: { ...defaultParty },
		items: [{
			id: uid(),
			description: "",
			quantity: 1,
			rate: profile.defaultRate
		}],
		taxRate: 0,
		notes: "Due within 14 days. Thank you.",
		currency: profile.currency
	};
}
function blankProposal(profile, number) {
	return {
		id: uid(),
		number,
		status: "draft",
		issuedOn: todayIso(),
		validUntil: addDaysIso(21),
		from: {
			name: profile.name,
			email: profile.email,
			address: profile.address
		},
		client: { ...defaultParty },
		title: "Proposal",
		summary: "",
		scope: "Included:\n\nNot included:\n",
		timeline: "",
		items: [{
			id: uid(),
			description: "Sprint",
			quantity: 1,
			rate: profile.defaultRate * 40
		}],
		taxRate: 0,
		notes: "Valid for 21 days. Two rounds of revision are included.",
		currency: profile.currency
	};
}
require_react();
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		"data-slot": "input",
		className: cn("flex h-11 w-full rounded-md border border-border bg-bg-elevated px-3 text-base text-fg shadow-[var(--shadow-border)] transition-[box-shadow,border-color] duration-150 placeholder:text-subtle focus-visible:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/30 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		"data-slot": "textarea",
		className: cn("flex min-h-28 w-full rounded-md border border-border bg-bg-elevated px-3 py-2 text-base text-fg shadow-[var(--shadow-border)] transition-[box-shadow,border-color] duration-150 placeholder:text-subtle focus-visible:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/30 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		...props
	});
}
//#endregion
export { PROPOSAL_LIMIT as a, useStudio as c, PROJECT_LIMIT as i, Textarea as n, blankInvoice as o, INVOICE_LIMIT as r, blankProposal as s, Input as t };
