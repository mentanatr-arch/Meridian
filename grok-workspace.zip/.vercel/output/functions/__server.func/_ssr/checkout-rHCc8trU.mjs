import { i as __toESM } from "../_runtime.mjs";
import { a as money, o as moneyExact } from "./utils-DXWKSffG.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useNavigate, Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CbyLMWg1.mjs";
import { d as planPrice, i as PLANS, u as getProduct } from "./catalog-CwQVHlis.mjs";
import { c as useStudio, t as Input } from "./input-D498PH2S.mjs";
import { c as Route$13, u as useHydrated } from "./router-Ba3nbWFA.mjs";
import { t as Label } from "./label-D3Zuzywy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-rHCc8trU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Checkout() {
	const search = Route$13.useSearch();
	const navigate = useNavigate();
	const hydrated = useHydrated();
	const cart = useStudio((s) => s.cart);
	const setCartQty = useStudio((s) => s.setCartQty);
	const removeFromCart = useStudio((s) => s.removeFromCart);
	const placeOrder = useStudio((s) => s.placeOrder);
	const profile = useStudio((s) => s.profile);
	const planId = ["pro", "studio"].includes(search.plan || "") ? search.plan : void 0;
	const billing = search.billing === "monthly" ? "monthly" : "annual";
	const plan = PLANS.find((p) => p.id === planId);
	const [name, setName] = (0, import_react.useState)(profile.owner);
	const [email, setEmail] = (0, import_react.useState)(profile.email);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const lines = (0, import_react.useMemo)(() => cart.map((c) => {
		const p = getProduct(c.slug);
		if (!p) return null;
		return {
			...c,
			product: p
		};
	}).filter(Boolean), [cart]);
	const goods = lines.reduce((s, l) => s + l.product.price * l.quantity, 0);
	const planTotal = plan ? planPrice(plan.id, billing) : 0;
	const total = goods + planTotal;
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-4xl px-4 py-16",
		children: "Loading…"
	});
	const empty = lines.length === 0 && !plan;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-5xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl tracking-tight",
				children: "Checkout"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Preview mode — no card is charged. The same screens take real money when a processor is connected."
			}),
			empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 rounded-2xl bg-bg-elevated p-8 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-serif text-2xl",
					children: "Nothing on the desk yet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/shop",
							children: "Shop kits"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/pricing",
							children: "See plans"
						})
					})]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 space-y-4",
				onSubmit: (e) => {
					e.preventDefault();
					setBusy(true);
					const order = placeOrder({
						name,
						email,
						withPlan: plan ? {
							id: plan.id,
							billing
						} : void 0
					});
					navigate({
						to: "/checkout/success",
						search: { order: order.id }
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "name",
						children: "Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "name",
						required: true,
						className: "mt-2",
						value: name,
						onChange: (e) => setName(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "email",
						children: "Email for the receipt"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "email",
						type: "email",
						required: true,
						className: "mt-2",
						value: email,
						onChange: (e) => setEmail(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "card",
							children: "Card"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "card",
							className: "mt-2",
							placeholder: "4242 4242 4242 4242",
							defaultValue: "4242 4242 4242 4242"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "MM/YY",
								defaultValue: "12/28",
								"aria-label": "Expiry"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "CVC",
								defaultValue: "123",
								"aria-label": "CVC"
							})]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "lg",
						className: "w-full",
						disabled: busy,
						children: busy ? "Placing…" : `Pay ${moneyExact(total)}`
					})
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Order"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-4",
					children: [plan ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							plan.name,
							" · ",
							billing
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(planTotal)
						})]
					}) : null, lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: l.product.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: money(l.product.price * l.quantity)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "size-8 rounded-md border border-border",
									onClick: () => setCartQty(l.slug, l.quantity - 1),
									children: "−"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: l.quantity
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "size-8 rounded-md border border-border",
									onClick: () => setCartQty(l.slug, l.quantity + 1),
									children: "+"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "ml-auto text-xs text-muted hover:text-danger",
									onClick: () => removeFromCart(l.slug),
									children: "Remove"
								})
							]
						})]
					}, l.slug))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex justify-between border-t border-border pt-4 font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-serif text-2xl tabular-nums",
						children: moneyExact(total)
					})]
				})
			]
		})]
	});
}
//#endregion
export { Checkout as component };
