import { r as formatDate } from "./utils-DXWKSffG.mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ARTICLES } from "./catalog-CwQVHlis.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/journal-Ddl6Lx5B.js
var import_jsx_runtime = require_jsx_runtime();
function Journal() {
	const [hero, ...rest] = ARTICLES;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-5xl tracking-tight",
				children: "Journal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xl text-lg text-muted",
				children: "Written for the 11pm searcher who cannot sleep on a rate. One job per essay."
			}),
			hero ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/journal/$slug",
				params: { slug: hero.slug },
				className: "mt-12 grid gap-8 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: hero.cover,
					alt: "",
					className: "h-80 w-full rounded-2xl object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs tracking-[0.14em] text-subtle uppercase",
							children: [
								hero.tags[0],
								" · ",
								hero.minutes,
								" min · ",
								formatDate(hero.date)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-serif text-4xl tracking-tight",
							children: hero.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-muted",
							children: hero.dek
						})
					]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-16 grid gap-10 sm:grid-cols-2",
				children: rest.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/journal/$slug",
					params: { slug: a.slug },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: a.cover,
							alt: "",
							className: "h-52 w-full rounded-xl object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs tracking-[0.14em] text-subtle uppercase",
							children: [
								a.tags[0],
								" · ",
								a.minutes,
								" min"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-serif text-2xl tracking-tight",
							children: a.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: a.dek
						})
					]
				}, a.slug))
			})
		]
	});
}
//#endregion
export { Journal as component };
