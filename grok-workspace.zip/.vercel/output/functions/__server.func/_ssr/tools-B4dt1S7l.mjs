import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as Clock, l as Gauge, s as PenLine, u as FileText } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools-B4dt1S7l.js
var import_jsx_runtime = require_jsx_runtime();
var ITEMS = [
	{
		to: "/tools/invoices",
		icon: FileText,
		title: "Invoices",
		text: "Draft, send, mark paid, print. The paper clients pay fastest."
	},
	{
		to: "/tools/rates",
		icon: Gauge,
		title: "Rate calculator",
		text: "Turn a life into an hourly, day, and sprint number you can defend."
	},
	{
		to: "/tools/proposals",
		icon: PenLine,
		title: "Proposals",
		text: "Scope, fence, timeline, investment — then bill the yes."
	},
	{
		to: "/tools/time",
		icon: Clock,
		title: "Time tracker",
		text: "A quiet clock. Hours become line items instead of folklore."
	}
];
function Tools() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-5xl tracking-tight",
				children: "Tools"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xl text-lg text-muted",
				children: "Four instruments. Use them in order the first time: rate, proposal, time, invoice."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-4 sm:grid-cols-2",
				children: ITEMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					className: "rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5 text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-serif text-2xl tracking-tight",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: item.text
						})
					]
				}, item.to))
			})
		]
	});
}
//#endregion
export { Tools as component };
