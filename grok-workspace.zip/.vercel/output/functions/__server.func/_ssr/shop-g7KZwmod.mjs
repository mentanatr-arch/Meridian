import { a as money } from "./utils-DXWKSffG.mjs";
import { Y as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as PRODUCTS } from "./catalog-CwQVHlis.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop-g7KZwmod.js
var import_jsx_runtime = require_jsx_runtime();
function Shop() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-5xl tracking-tight",
				children: "The desk shop"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xl text-lg text-muted",
				children: "Kits you can paste into the tools you already use. Margin for us. Faster yeses for you."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
				children: PRODUCTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/shop/$slug",
					params: { slug: p.slug },
					className: "group",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: p.cover,
							alt: "",
							className: "aspect-3/4 w-full rounded-xl object-cover transition-transform duration-250 ease-out group-hover:scale-[1.01]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs tracking-[0.14em] text-subtle uppercase",
							children: p.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-medium",
								children: p.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm tabular-nums text-muted",
								children: money(p.price)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: p.blurb
						})
					]
				}, p.slug))
			})
		]
	});
}
//#endregion
export { Shop as component };
