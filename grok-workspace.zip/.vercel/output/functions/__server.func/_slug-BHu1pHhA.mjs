import { r as formatDate } from "./_ssr/utils-DXWKSffG.mjs";
import { Y as require_jsx_runtime, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./_ssr/button-CbyLMWg1.mjs";
import { l as getArticle, t as ARTICLES } from "./_ssr/catalog-CwQVHlis.mjs";
import { l as Newsletter, o as Route$10 } from "./_ssr/router-Ba3nbWFA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-BHu1pHhA.js
var import_jsx_runtime = require_jsx_runtime();
function ArticlePage() {
	const { slug } = Route$10.useParams();
	const article = getArticle(slug);
	if (!article) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-6 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-serif text-3xl",
			children: "Essay not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/journal",
				children: "Journal"
			})
		})]
	});
	const related = ARTICLES.filter((a) => a.slug !== article.slug).slice(0, 2);
	const cta = article.slug.includes("rate") || article.slug.includes("eighty") ? {
		to: "/tools/rates",
		label: "Open the rate calculator"
	} : article.slug.includes("invoice") ? {
		to: "/tools/invoices",
		label: "Open invoices"
	} : article.slug.includes("scope") ? {
		to: "/tools/proposals",
		label: "Open proposals"
	} : {
		to: "/tools/time",
		label: "Open the timer"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs tracking-[0.14em] text-subtle uppercase",
				children: [
					article.tags.join(" · "),
					" · ",
					formatDate(article.date),
					" · ",
					article.minutes,
					" min"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-serif text-4xl tracking-tight sm:text-5xl",
				children: article.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-lg text-muted",
				children: article.dek
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: article.cover,
				alt: "",
				className: "mt-10 h-72 w-full rounded-2xl object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 space-y-5",
				children: article.body.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-base leading-relaxed text-fg",
					children: p
				}, p.slice(0, 40)))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 rounded-2xl bg-ink p-8 text-cream",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-serif text-2xl",
					children: "Do the work, not the reread."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-4 bg-cream text-ink hover:bg-cream/90",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: cta.to,
						children: cta.label
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Newsletter, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-16 grid gap-8 sm:grid-cols-2",
				children: related.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/journal/$slug",
					params: { slug: a.slug },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.14em] text-subtle uppercase",
						children: a.tags[0]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-serif text-2xl tracking-tight",
						children: a.title
					})]
				}, a.slug))
			})
		]
	});
}
//#endregion
export { ArticlePage as component };
