import { create } from "zustand";
import { persist } from "zustand/middleware";
import { PRODUCTS, planPrice } from "./catalog";
import type {
  Billing,
  CartItem,
  Invoice,
  Order,
  PlanId,
  Proposal,
  RateModel,
  StudioProfile,
  TimeEntry,
} from "./types";
import { addDaysIso, todayIso, uid } from "./utils";

const defaultParty = {
  name: "",
  email: "",
  address: "",
};

const defaultProfile: StudioProfile = {
  name: "Your studio",
  owner: "",
  email: "",
  address: "",
  website: "",
  currency: "USD",
  defaultRate: 150,
  onboarded: false,
};

const defaultRate: RateModel = {
  desired: 140000,
  weeks: 46,
  hoursPerWeek: 32,
  utilization: 60,
  overhead: 22,
  tax: 28,
  profit: 15,
  currency: "USD",
};

function sampleInvoice(profile: StudioProfile): Invoice {
  return {
    id: "sample-inv-1",
    number: "INV-1042",
    status: "paid",
    issuedOn: addDaysIso(-18),
    dueOn: addDaysIso(-4),
    from: {
      name: profile.name || "North Studio",
      email: profile.email || "studio@example.com",
      address: profile.address || "14 Mercer, Floor 3",
    },
    client: {
      name: "Harbor & Co.",
      email: "accounts@harbor.co",
      address: "88 Atlantic, Brooklyn",
    },
    items: [
      {
        id: uid(),
        description: "Identity system — wordmark, type, paper",
        quantity: 1,
        rate: 8400,
      },
      {
        id: uid(),
        description: "Launch collateral — three applications",
        quantity: 1,
        rate: 2600,
      },
    ],
    taxRate: 0,
    notes: "Paid via transfer · thank you for the quiet brief.",
    currency: profile.currency || "USD",
  };
}

type State = {
  profile: StudioProfile;
  plan: PlanId;
  billing: Billing;
  invoices: Invoice[];
  proposals: Proposal[];
  entries: TimeEntry[];
  rate: RateModel;
  cart: CartItem[];
  orders: Order[];
  emails: string[];
  seeded: boolean;
  setProfile: (patch: Partial<StudioProfile>) => void;
  setPlan: (plan: PlanId, billing?: Billing) => void;
  setRate: (patch: Partial<RateModel>) => void;
  addInvoice: (invoice: Invoice) => { ok: true } | { ok: false; reason: "limit" };
  updateInvoice: (id: string, patch: Partial<Invoice>) => void;
  removeInvoice: (id: string) => void;
  addProposal: (proposal: Proposal) => { ok: true } | { ok: false; reason: "limit" };
  updateProposal: (id: string, patch: Partial<Proposal>) => void;
  removeProposal: (id: string) => void;
  startTimer: (project: string, note: string, rate: number) => { ok: true } | { ok: false; reason: "limit" };
  stopTimer: () => void;
  removeEntry: (id: string) => void;
  addToCart: (slug: string) => void;
  removeFromCart: (slug: string) => void;
  setCartQty: (slug: string, quantity: number) => void;
  clearCart: () => void;
  placeOrder: (input: { name: string; email: string; withPlan?: { id: PlanId; billing: Billing } }) => Order;
  subscribe: (email: string) => void;
  seedIfNeeded: () => void;
  nextInvoiceNumber: () => string;
  nextProposalNumber: () => string;
};

const INVOICE_LIMIT: Record<PlanId, number> = { starter: 3, pro: Infinity, studio: Infinity };
const PROPOSAL_LIMIT: Record<PlanId, number> = { starter: 1, pro: Infinity, studio: Infinity };
const PROJECT_LIMIT: Record<PlanId, number> = { starter: 3, pro: Infinity, studio: Infinity };

export const useStudio = create<State>()(
  persist(
    (set, get) => ({
      profile: defaultProfile,
      plan: "starter",
      billing: "monthly",
      invoices: [],
      proposals: [],
      entries: [],
      rate: defaultRate,
      cart: [],
      orders: [],
      emails: [],
      seeded: false,
      setProfile: (patch) =>
        set((s) => ({ profile: { ...s.profile, ...patch } })),
      setPlan: (plan, billing) =>
        set((s) => ({ plan, billing: billing ?? s.billing })),
      setRate: (patch) => set((s) => ({ rate: { ...s.rate, ...patch } })),
      addInvoice: (invoice) => {
        const { invoices, plan } = get();
        if (invoices.length >= INVOICE_LIMIT[plan]) return { ok: false, reason: "limit" };
        set({ invoices: [invoice, ...invoices] });
        return { ok: true };
      },
      updateInvoice: (id, patch) =>
        set((s) => ({
          invoices: s.invoices.map((inv) => (inv.id === id ? { ...inv, ...patch } : inv)),
        })),
      removeInvoice: (id) =>
        set((s) => ({ invoices: s.invoices.filter((inv) => inv.id !== id) })),
      addProposal: (proposal) => {
        const { proposals, plan } = get();
        if (proposals.length >= PROPOSAL_LIMIT[plan]) return { ok: false, reason: "limit" };
        set({ proposals: [proposal, ...proposals] });
        return { ok: true };
      },
      updateProposal: (id, patch) =>
        set((s) => ({
          proposals: s.proposals.map((p) => (p.id === id ? { ...p, ...patch } : p)),
        })),
      removeProposal: (id) =>
        set((s) => ({ proposals: s.proposals.filter((p) => p.id !== id) })),
      startTimer: (project, note, rate) => {
        const { entries, plan } = get();
        const running = entries.find((e) => e.endedAt === null);
        if (running) {
          set({
            entries: entries.map((e) =>
              e.id === running.id ? { ...e, endedAt: Date.now() } : e,
            ),
          });
        }
        const projects = new Set(
          get().entries.map((e) => e.project).filter(Boolean),
        );
        projects.add(project);
        if (projects.size > PROJECT_LIMIT[plan]) return { ok: false, reason: "limit" };
        const entry: TimeEntry = {
          id: uid(),
          project,
          note,
          startedAt: Date.now(),
          endedAt: null,
          billable: true,
          rate,
        };
        set({ entries: [entry, ...get().entries] });
        return { ok: true };
      },
      stopTimer: () =>
        set((s) => ({
          entries: s.entries.map((e) =>
            e.endedAt === null ? { ...e, endedAt: Date.now() } : e,
          ),
        })),
      removeEntry: (id) =>
        set((s) => ({ entries: s.entries.filter((e) => e.id !== id) })),
      addToCart: (slug) =>
        set((s) => {
          const existing = s.cart.find((c) => c.slug === slug);
          if (existing) {
            return {
              cart: s.cart.map((c) =>
                c.slug === slug ? { ...c, quantity: c.quantity + 1 } : c,
              ),
            };
          }
          return { cart: [...s.cart, { slug, quantity: 1 }] };
        }),
      removeFromCart: (slug) =>
        set((s) => ({ cart: s.cart.filter((c) => c.slug !== slug) })),
      setCartQty: (slug, quantity) =>
        set((s) => ({
          cart:
            quantity <= 0
              ? s.cart.filter((c) => c.slug !== slug)
              : s.cart.map((c) => (c.slug === slug ? { ...c, quantity } : c)),
        })),
      clearCart: () => set({ cart: [] }),
      placeOrder: ({ name, email, withPlan }) => {
        const { cart, orders, profile } = get();
        const items = cart
          .map((c) => {
            const product = PRODUCTS.find((p) => p.slug === c.slug);
            if (!product) return null;
            return {
              slug: product.slug,
              title: product.title,
              price: product.price,
              quantity: c.quantity,
            };
          })
          .filter(Boolean) as Order["items"];
        const goods = items.reduce((s, i) => s + i.price * i.quantity, 0);
        const planTotal = withPlan ? planPrice(withPlan.id, withPlan.billing) : 0;
        const order: Order = {
          id: uid().slice(0, 8).toUpperCase(),
          createdAt: new Date().toISOString(),
          email,
          name,
          items,
          plan: withPlan
            ? { id: withPlan.id, billing: withPlan.billing, price: planTotal }
            : undefined,
          total: goods + planTotal,
          currency: profile.currency || "USD",
        };
        set({
          orders: [order, ...orders],
          cart: [],
          emails: get().emails.includes(email) ? get().emails : [email, ...get().emails],
        });
        if (withPlan) get().setPlan(withPlan.id, withPlan.billing);
        if (name) get().setProfile({ owner: name, email, onboarded: true });
        return order;
      },
      subscribe: (email) =>
        set((s) => ({
          emails: s.emails.includes(email) ? s.emails : [email, ...s.emails],
        })),
      seedIfNeeded: () => {
        if (get().seeded) return;
        const profile = get().profile;
        set({
          seeded: true,
          invoices: get().invoices.length ? get().invoices : [sampleInvoice(profile)],
        });
      },
      nextInvoiceNumber: () => {
        const n = get().invoices.length + 1042;
        return `INV-${n}`;
      },
      nextProposalNumber: () => {
        const n = get().proposals.length + 220;
        return `PR-${n}`;
      },
    }),
    { name: "meridian-studio" },
  ),
);

export function blankInvoice(profile: StudioProfile, number: string): Invoice {
  return {
    id: uid(),
    number,
    status: "draft",
    issuedOn: todayIso(),
    dueOn: addDaysIso(14),
    from: {
      name: profile.name,
      email: profile.email,
      address: profile.address,
    },
    client: { ...defaultParty },
    items: [
      {
        id: uid(),
        description: "",
        quantity: 1,
        rate: profile.defaultRate,
      },
    ],
    taxRate: 0,
    notes: "Due within 14 days. Thank you.",
    currency: profile.currency,
  };
}

export function blankProposal(profile: StudioProfile, number: string): Proposal {
  return {
    id: uid(),
    number,
    status: "draft",
    issuedOn: todayIso(),
    validUntil: addDaysIso(21),
    from: {
      name: profile.name,
      email: profile.email,
      address: profile.address,
    },
    client: { ...defaultParty },
    title: "Proposal",
    summary: "",
    scope: "Included:\n\nNot included:\n",
    timeline: "",
    items: [
      {
        id: uid(),
        description: "Sprint",
        quantity: 1,
        rate: profile.defaultRate * 40,
      },
    ],
    taxRate: 0,
    notes: "Valid for 21 days. Two rounds of revision are included.",
    currency: profile.currency,
  };
}

export { INVOICE_LIMIT, PROPOSAL_LIMIT, PROJECT_LIMIT };
