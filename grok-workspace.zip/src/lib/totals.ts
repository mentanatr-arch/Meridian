import type { LineItem } from "./types";

export function lineAmount(item: LineItem) {
  return (Number(item.quantity) || 0) * (Number(item.rate) || 0);
}

export function subtotalOf(items: LineItem[]) {
  return items.reduce((sum, item) => sum + lineAmount(item), 0);
}

export function taxOf(items: LineItem[], taxRate: number) {
  return subtotalOf(items) * ((Number(taxRate) || 0) / 100);
}

export function totalOf(items: LineItem[], taxRate: number) {
  return subtotalOf(items) + taxOf(items, taxRate);
}

export function computeRate(model: {
  desired: number;
  weeks: number;
  hoursPerWeek: number;
  utilization: number;
  overhead: number;
  tax: number;
  profit: number;
}) {
  const weeks = Math.max(1, model.weeks || 0);
  const hoursPerWeek = Math.max(1, model.hoursPerWeek || 0);
  const utilization = Math.min(100, Math.max(1, model.utilization || 0)) / 100;
  const billableHours = weeks * hoursPerWeek * utilization;
  const overhead = Math.max(0, model.overhead || 0) / 100;
  const tax = Math.min(80, Math.max(0, model.tax || 0)) / 100;
  const profit = Math.max(0, model.profit || 0) / 100;
  const desired = Math.max(0, model.desired || 0);

  const withOverhead = desired * (1 + overhead);
  const withProfit = withOverhead * (1 + profit);
  const gross = tax >= 0.99 ? withProfit : withProfit / (1 - tax);
  const hourly = billableHours > 0 ? gross / billableHours : 0;
  const daily = hourly * Math.min(hoursPerWeek, 8);
  const weekly = hourly * (hoursPerWeek * utilization);

  return {
    billableHours,
    gross,
    withOverhead,
    withProfit,
    hourly,
    daily,
    weekly,
    dayRate8: hourly * 8,
  };
}
