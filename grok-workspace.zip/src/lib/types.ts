export type PlanId = "starter" | "pro" | "studio";
export type Billing = "monthly" | "annual";
export type InvoiceStatus = "draft" | "sent" | "paid" | "overdue";
export type ProposalStatus = "draft" | "sent" | "accepted" | "declined";

export type Party = {
  name: string;
  email: string;
  address: string;
};

export type LineItem = {
  id: string;
  description: string;
  quantity: number;
  rate: number;
};

export type Invoice = {
  id: string;
  number: string;
  status: InvoiceStatus;
  issuedOn: string;
  dueOn: string;
  from: Party;
  client: Party;
  items: LineItem[];
  taxRate: number;
  notes: string;
  currency: string;
};

export type Proposal = {
  id: string;
  number: string;
  status: ProposalStatus;
  issuedOn: string;
  validUntil: string;
  from: Party;
  client: Party;
  title: string;
  summary: string;
  scope: string;
  timeline: string;
  items: LineItem[];
  taxRate: number;
  notes: string;
  currency: string;
};

export type TimeEntry = {
  id: string;
  project: string;
  note: string;
  startedAt: number;
  endedAt: number | null;
  billable: boolean;
  rate: number;
};

export type RateModel = {
  desired: number;
  weeks: number;
  hoursPerWeek: number;
  utilization: number;
  overhead: number;
  tax: number;
  profit: number;
  currency: string;
};

export type CartItem = {
  slug: string;
  quantity: number;
};

export type Order = {
  id: string;
  createdAt: string;
  email: string;
  name: string;
  items: { slug: string; title: string; price: number; quantity: number }[];
  plan?: { id: PlanId; billing: Billing; price: number };
  total: number;
  currency: string;
};

export type StudioProfile = {
  name: string;
  owner: string;
  email: string;
  address: string;
  website: string;
  currency: string;
  defaultRate: number;
  onboarded: boolean;
};
