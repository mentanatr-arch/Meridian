import type { Billing, PlanId } from "./types";

export const SITE = {
  name: "Meridian",
  tagline: "Get paid like a studio.",
  description:
    "Invoices, rates, proposals, and time — the operating system for independent professionals.",
  email: "hello@meridian.studio",
};

export const PLANS: {
  id: PlanId;
  name: string;
  monthly: number;
  annual: number;
  blurb: string;
  features: string[];
  cta: string;
  highlight?: boolean;
}[] = [
  {
    id: "starter",
    name: "Starter",
    monthly: 0,
    annual: 0,
    blurb: "For the first three invoices and a honest rate.",
    features: [
      "3 invoices",
      "1 proposal",
      "Rate calculator",
      "3 time projects",
      "Print-ready paper",
    ],
    cta: "Start free",
  },
  {
    id: "pro",
    name: "Pro",
    monthly: 19,
    annual: 190,
    blurb: "Unlimited paper for a working independent.",
    features: [
      "Unlimited invoices",
      "Unlimited proposals",
      "Time tracker + bill from hours",
      "Saved rate models",
      "Priority print layouts",
      "Remove Meridian mark",
    ],
    cta: "Go Pro",
    highlight: true,
  },
  {
    id: "studio",
    name: "Studio",
    monthly: 49,
    annual: 490,
    blurb: "For a practice with a roster and a reputation.",
    features: [
      "Everything in Pro",
      "Multi-brand letterheads",
      "Shop credit each year",
      "Partner dashboard",
      "White-glove onboarding",
      "Concierge rate review",
    ],
    cta: "Open Studio",
  },
];

export function planPrice(id: PlanId, billing: Billing) {
  const plan = PLANS.find((p) => p.id === id);
  if (!plan) return 0;
  return billing === "annual" ? plan.annual : plan.monthly;
}

export const PRODUCTS = [
  {
    slug: "independent-contract-kit",
    title: "Independent Contract Kit",
    price: 49,
    category: "Paper",
    cover: "/images/cover-arc.jpg",
    blurb: "The four agreements that keep scope, money, and IP in the right rooms.",
    includes: [
      "Master services agreement",
      "Statement of work rider",
      "Kill-fee and pause clause",
      "IP assignment that still lets you show the work",
      "Late-fee schedule in plain language",
    ],
    body: "Most independents send a friendly email and hope. This kit is the paper we actually use: short, specific, and designed to be signed without a lawyer on retainer. Written for designers, writers, strategists, and developers billing $8k–$80k projects.",
  },
  {
    slug: "rate-card-system",
    title: "Rate Card System",
    price: 29,
    category: "Pricing",
    cover: "/images/cover-grid.jpg",
    blurb: "A living rate card — retainers, sprints, and the 'not that' prices.",
    includes: [
      "One-page rate card (print + Notion)",
      "Retainer math worksheet",
      "Three-tier packaging template",
      "Discovery call script",
      "Raise letter for existing clients",
    ],
    body: "If you still quote from memory, you are leaving a third of the fee on the table. The Rate Card System turns utilization, overhead, and the work you actually want into numbers you can send without flinching.",
  },
  {
    slug: "proposal-atelier",
    title: "Proposal Atelier",
    price: 79,
    category: "Sales",
    cover: "/images/cover-circle.jpg",
    blurb: "Twelve proposal structures that close without a 40-page PDF.",
    includes: [
      "12 proposal outlines by job type",
      "Investment page layouts",
      "Scope fence language",
      "Case-study insert",
      "Follow-up sequence (5 notes)",
    ],
    body: "A proposal is not a brochure. It is a decision document. Atelier gives you the architecture: problem, approach, proof, fence, price — in that order — so the client is nodding before they reach the number.",
  },
  {
    slug: "studio-brand-kit",
    title: "Studio Brand Kit",
    price: 129,
    category: "Identity",
    cover: "/images/cover-rules.jpg",
    blurb: "Letterhead, invoice skin, and a quiet identity system for a practice.",
    includes: [
      "Wordmark construction",
      "Invoice and proposal skins",
      "Color, type, and paper specs",
      "Email signature set",
      "Social avatars and a cover",
    ],
    body: "Clients pay more when the paper looks like a studio, not a side hustle. This kit is the identity we built Meridian around — cream, ink, one green — ready to restyle with your name.",
  },
  {
    slug: "client-onboarding-os",
    title: "Client Onboarding OS",
    price: 59,
    category: "Operations",
    cover: "/images/cover-arc.jpg",
    blurb: "From yes to kickoff in five days, without the scatter.",
    includes: [
      "Kickoff agenda",
      "Intake questionnaire",
      "Access checklist",
      "First-week cadence",
      "Feedback ritual",
    ],
    body: "The work starts slipping the moment the contract is signed. This operating system holds the first two weeks: who is in the room, what 'done' means, and when you will actually talk.",
  },
  {
    slug: "year-of-invoices",
    title: "A Year of Invoices",
    price: 19,
    category: "Paper",
    cover: "/images/cover-grid.jpg",
    blurb: "Printable monthly invoice covers and a ledger you can hang.",
    includes: [
      "12 cover sheets",
      "Annual ledger poster",
      "Paid / sent / overdue stamps",
      "Envelope layout",
    ],
    body: "For the independents who still like paper on a wall. A quiet year of covers — month, number, a place for the total — designed to sit next to the work.",
  },
] as const;

export type ProductSlug = (typeof PRODUCTS)[number]["slug"];

export function getProduct(slug: string) {
  return PRODUCTS.find((p) => p.slug === slug);
}

export const ARTICLES = [
  {
    slug: "rate-that-holds",
    title: "A rate that holds when the room gets quiet",
    dek: "Most independents price the hour. Studios price the year, then work backwards. Here is the arithmetic, without the TED-talk.",
    date: "2026-08-12",
    minutes: 9,
    cover: "/images/paper.jpg",
    tags: ["Pricing", "Playbook"],
    body: [
      "A rate is not a personality. It is a machine with four inputs: the life you want to fund, the hours you can actually sell, the cost of keeping the practice open, and the tax authority who will not be impressed by your utilization spreadsheet.",
      "Start with a number you can say out loud. Not 'I want to be comfortable.' A number: rent, food, health, retirement, the two months you will not bill, the laptop that dies in March. Add them. That is the floor, not the ceiling.",
      "Then be honest about billable hours. Forty times fifty-two is a corporate fiction. Independents who last sell closer to 900–1,200 hours a year once you subtract sales, admin, and the week a client disappears. If you divide a $120,000 life by 2,000 hours you will undercharge, overwork, and call it grit.",
      "Overhead is not optional. Software, insurance, an accountant, a real chair, the course you actually finish. Put 18–28% on top of the floor. Then tax: if you are paying both halves of employment tax, another 25–35% needs to sit in a separate account the day the money lands.",
      "The last input is profit. Not a bonus. The money that lets you say no, take August, or hire help. Ten to twenty percent. Without it you have a job with worse benefits.",
      "Meridian's rate calculator does this in one sitting. The point is not the hourly number — it is that you can defend it. When a client asks why, you are not negotiating a vibe. You are pointing at a year.",
    ],
  },
  {
    slug: "invoices-that-get-paid",
    title: "The invoice that gets paid in seven days",
    dek: "Net-30 is a habit you taught your clients. Change the paper, change the calendar.",
    date: "2026-07-02",
    minutes: 7,
    cover: "/images/desk.jpg",
    tags: ["Invoicing", "Collections"],
    body: [
      "People pay invoices they understand, on terms they agreed to, from a sender they recognize. Everything else is theatre.",
      "Put the total at the top, not the bottom. The bottom is where tired accounts-payable staff stop reading. Repeat the number in the subject line of the email: 'Invoice 1042 — $6,400 — due 12 Oct'. No mystery, no PDF named FINAL-v3.",
      "Due dates should be dates, not poetry. 'Net 14' is a riddle. 'Due 12 October' is a calendar event. In Meridian, due dates are real days, and the paper says them in English.",
      "The fastest invoices we see have three other traits. A line-item a civilian can parse. A payment method that does not require a phone call. A sentence about what happens on day 15 — not as a threat, as a process. Late fees work when they were in the proposal. They fail as a surprise.",
      "Send the same day the milestone is accepted, not 'when you get to it on Friday.' Money in motion decays. The seven-day invoice is not luck. It is proximity to the yes.",
    ],
  },
  {
    slug: "scope-fence",
    title: "A scope fence that actually holds",
    dek: "Nice people get extra rounds. Here is the clause, the conversation, and the moment you use both.",
    date: "2026-05-21",
    minutes: 8,
    cover: "/images/studio.jpg",
    tags: ["Proposals", "Clients"],
    body: [
      "Scope creep is not a personality defect in your client. It is an empty fence. If the proposal does not say what is out, everything is in.",
      "Write the out-list first. 'Not included: photography, copywriting, two extra landing pages, a brand film, unlimited revision.' Then write the in-list so it feels generous. Humans notice absence more than presence; if you only list what you will do, they will invent the rest.",
      "Revisions are a number. 'Unlimited until it feels right' is how studios go bankrupt on taste. Two rounds in the fee. A third at a stated rate. After that, a new statement of work. You can still be kind. Kindness is a tone, not an open tab.",
      "The conversation is shorter than you think. 'I can do that. It sits outside this proposal. I will send a one-page addendum this afternoon.' No apology. No essay about your boundaries. Paper, then work.",
      "Meridian's proposal builder puts Scope, Timeline, and Investment on separate planes so a client can initial the fence without hunting for it in paragraph nineteen.",
    ],
  },
  {
    slug: "four-day-math",
    title: "The four-day week, without a pay cut you cannot afford",
    dek: "Working less only works if the rate already assumed you would.",
    date: "2026-03-18",
    minutes: 6,
    cover: "/images/paper.jpg",
    tags: ["Time", "Pricing"],
    body: [
      "A four-day week is not a lifestyle brand. It is a utilization choice. If your rate was built on five billable days, four days is a 20% pay cut wearing linen.",
      "Rebuild the year. Keep the income target. Drop the days. The hourly number will look rude. That is the point. Either the market will pay it — because you are good, fast, and scarce — or it will not, and you will know before you burn a Thursday on hope.",
      "The independents who make this work do three things. They sell retainers, not hours. They stop doing the work a junior should do. They protect the fifth day as sales and craft, not 'a little Slack.'",
      "Track a month in Meridian before you announce anything. If billable time is already 22 hours in a 40-hour costume, you do not need a four-day week. You need a rate and a fence.",
    ],
  },
  {
    slug: "eighty-to-one-eighty",
    title: "From $80 an hour to $180 without more clients",
    dek: "The jump is not hustle. It is packaging, proof, and who you let in the calendar.",
    date: "2026-01-09",
    minutes: 10,
    cover: "/images/desk.jpg",
    tags: ["Growth", "Pricing"],
    body: [
      "Eighty dollars an hour feels professional until you do the year. At 1,000 billable hours that is $80,000 gross, before the tax bill, the software, and the month a client ghosts. One-eighty is the same hours with a different story about what those hours are for.",
      "The story is not 'I am more expensive now.' It is 'I do not sell hours. I sell a result with a fence, in a container you can buy.' Discovery, a named sprint, a retainer with office hours. The hour is backstage math. The client buys a door.",
      "Proof does the rest. Three case notes with a number — revenue, time saved, conversion — beat a twelve-page capabilities deck. Put one of them in every proposal. Repeat the number on the invoice so accounts payable remembers why this was not a commodity.",
      "Then fire the bottom of the roster. Not dramatically. As retainers end, do not replace the $80 work. The calendar will feel empty for six weeks. That emptiness is the product. It is what lets you take the call that can pay $180.",
      "Use the rate calculator with a $180,000 target and 900 hours. Look at the number. If it scares you, good. Send it to the next brief that is actually worth the chair.",
    ],
  },
] as const;

export function getArticle(slug: string) {
  return ARTICLES.find((a) => a.slug === slug);
}

export const FAQS = [
  {
    q: "Is this a real charge?",
    a: "This preview runs a complete checkout so you can practice the funnel. No card is charged. When you publish, connect a processor and the same screens take real money.",
  },
  {
    q: "Where is my data stored?",
    a: "On this device, in the browser. Invoices, time, and the cart stay with you. Publishing with accounts later lets a studio share a roster across computers.",
  },
  {
    q: "Can I print invoices and proposals?",
    a: "Yes. Every paper view is print-ready. Use your browser's print dialog and choose 'Save as PDF' if you need a file.",
  },
  {
    q: "What is the difference between Pro and Studio?",
    a: "Pro is unlimited paper and time for one independent. Studio adds multi-brand letterheads, shop credit, and a concierge rate review for practices that look like firms.",
  },
  {
    q: "Do the shop templates work in Word and Notion?",
    a: "Yes. Each kit is written to paste into the tools you already use. The Contract Kit and Rate Card System are the ones teams open first.",
  },
  {
    q: "Can I cancel?",
    a: "Monthly plans cancel at the period's end. Annual plans include a 14-day refund window. Digital kits are refundable within 7 days if files were not downloaded in bulk.",
  },
  {
    q: "Who is Meridian for?",
    a: "Designers, writers, strategists, developers, and small studios who invoice for thinking — not shops with 400 SKUs, and not enterprises with SAP.",
  },
  {
    q: "Is there an affiliate program?",
    a: "Yes. Partners earn 30% on software and 15% on kits for 12 months. The terms live on the Partners page.",
  },
];

export const TESTIMONIALS = [
  {
    quote:
      "I raised my rate 40% the week I could see the year on one screen. The invoices look like a studio. Clients stopped negotiating the hour.",
    name: "M. Chen",
    role: "Brand designer, Portland",
  },
  {
    quote:
      "We closed a $62k sprint with a six-page proposal. The fence was on page two. They initialed it. That has never happened with a Google Doc.",
    name: "A. Okonkwo",
    role: "Strategy studio, Lagos / London",
  },
  {
    quote:
      "Time tracking used to be a guilt app. Now it is how the invoice writes itself. Paid in nine days, twice in a row.",
    name: "S. Alvarez",
    role: "Independent engineer, Austin",
  },
];

export const LOGOS = [
  "Atelier North",
  "Field & Form",
  "Harbor & Co.",
  "Kite Press",
  "Second Room",
  "Lowland",
];

export const PLAYBOOK = [
  {
    id: "what",
    title: "What you just opened",
    paragraphs: [
      "Meridian is a complete business: a product people pay for, a shop that sells while you sleep, a journal that brings search traffic, and a funnel that turns a rate question into a subscription. You can use it as your own freelance OS today. You can also treat it as the company — the thing you publish, price, and run.",
      "Nothing here is a wireframe. Invoices calculate. Time tracks. Checkout records an order on this device. The playbook is the operating manual for both jobs: practitioner and owner.",
    ],
  },
  {
    id: "money",
    title: "How the money works",
    paragraphs: [
      "Four engines, on purpose. Software subscriptions are the core — Starter is free so the rate calculator and first invoices can spread. Pro at $19 a month (or $190 a year) is the independent's plan. Studio at $49 is the practice plan. Annual billing is the cash-flow gift; it is priced as roughly ten months.",
      "The shop is margin. Digital kits cost nothing to ship and should sit at 70%+ contribution. They also warm a visitor who is not ready to subscribe. A $29 rate card is a handshake. A $19/month plan is a marriage.",
      "The journal is distribution you do not rent from an ad network. Each essay targets a job-to-be-done: rate, invoice speed, scope, time. Rank, then convert the sidebar.",
      "Partners are the fourth engine. Thirty percent of software, fifteen percent of kits, for twelve months. You want operators with lists of freelancers, not coupon blogs.",
    ],
  },
  {
    id: "funnel",
    title: "The funnel, in order",
    paragraphs: [
      "1. A stranger arrives from search or a share, usually on a journal essay or the rate calculator. 2. They run their numbers and see a rate they can defend. 3. They create an invoice because the paper is beautiful and free. 4. They hit the Starter ceiling (three invoices, one proposal). 5. Checkout. 6. A week later, the shop email — Contract Kit — because they just sent a real invoice without a contract.",
      "Do not invert this. Do not ask for a card before the rate feels true. The calculator is the product. The subscription is the relief of not going back to a spreadsheet.",
    ],
  },
  {
    id: "daily",
    title: "Daily and weekly rhythm",
    paragraphs: [
      "Daily, as a practitioner: track time on the job that is open. Send invoices the day a milestone is accepted. Glance at Studio for outstanding cash.",
      "Weekly, as an owner: publish or update one useful page. Reply to every partner and support note the same day. Review conversion from calculator → invoice → checkout. Kill any page that does not earn its place.",
      "Monthly: raise or stand behind the featured shop kit. Read the three invoices that took longest to pay and change the paper. Revisit the rate model if life costs moved.",
    ],
  },
  {
    id: "use",
    title: "Using the product",
    paragraphs: [
      "Studio is home. It reads invoices, time, and the rate you saved. Open Invoices to draft, mark sent, mark paid, duplicate, or print. The print dialog is your PDF.",
      "Rates is the lead magnet and the spine of every proposal. Set the life you want to fund, the weeks you will work, the hours you can sell, overhead, tax, and profit. Save the model. Put the hourly and day rates on the next proposal's investment page.",
      "Proposals borrow the same line items as invoices so a yes becomes a bill without retyping. Time entries can be rolled into an invoice from the tracker.",
      "Onboarding, once, writes your letterhead. Do it before the first real invoice so the paper already has your name.",
    ],
  },
  {
    id: "price",
    title: "Pricing psychology that pays",
    paragraphs: [
      "Anchor Studio next to Pro so Pro looks like the adult chair. Keep Starter actually useful — a crippled free plan trains people to leave. Three invoices is enough to feel the product and hit a real wall.",
      "Annual should be irresistible but not desperate. Ten months for twelve is the house standard. Show the monthly equivalent under the annual number.",
      "Shop prices sit under $150 so they are impulse with a company card. The Brand Kit at $129 is the flagship. The $19 Year of Invoices is the souvenir that still gets posted.",
    ],
  },
  {
    id: "content",
    title: "Content that ranks and sells",
    paragraphs: [
      "Write for the searcher at 11pm who cannot sleep because a client asked 'what is your rate.' Specific beats clever. Numbers in titles. No listicles of tools. One job per essay.",
      "Every essay should end on a tool, not a newsletter beg. Rate essay → calculator. Invoice essay → new invoice. Scope essay → proposal. The subscribe block can sit after the tool, once they have a reason to hear from you again.",
      "A working calendar: one long essay a month, one short note a week, one shop or partner mention that does not cheapen the voice. That is enough.",
    ],
  },
  {
    id: "convert",
    title: "Converting visitors",
    paragraphs: [
      "One primary action per view. On the homepage it is Start free, not a buffet. On pricing it is Pro. On a product it is Add to desk.",
      "Repeat the proof. $48M invoiced, the seven-day line, three named testimonials. Proof belongs next to the button, not in a graveyard at the footer.",
      "Use the ceiling. When a Starter user creates a fourth invoice, do not toast an error — open the upgrade with their work in the background. They should feel continuity, not a slap.",
    ],
  },
  {
    id: "live",
    title: "Taking this live",
    paragraphs: [
      "Publish the site. Connect a payments processor to the checkout you already have — the screens stay, the charge becomes real. Point the success page at a real receipt email.",
      "Stand up a transactional mailbox for invoices and a marketing mailbox for the journal. Same voice, different door.",
      "Put a domain on it that sounds like a studio, not a tool. Meridian is already a name you can say on a call. Keep the cream, the ink, and the one green. Do not 'make it pop.'",
      "Legal pages are included. Have a human in your country read Terms, Privacy, and Refunds before you take the first real dollar. They are written in English on purpose.",
    ],
  },
  {
    id: "email",
    title: "The list",
    paragraphs: [
      "Capture the email after the calculator, not before. Offer the saved rate model as the reason. Weekly, send one useful thing: a clause, a number, a page that changed. Monthly, one offer. If you cannot be useful, skip the week. Silence is cheaper than churn.",
    ],
  },
  {
    id: "partners",
    title: "Partners",
    paragraphs: [
      "Recruit newsletter writers who already advise freelancers, accountants who serve independents, and design communities. Give them a 30-day exclusive on a kit if they need a reason to go first. Pay on time. Publish the terms on /partners so you are not negotiating from a DM.",
    ],
  },
  {
    id: "ninety",
    title: "The first 90 days",
    paragraphs: [
      "Days 1–7: onboard yourself as the first user. Send a real invoice through Meridian. Fix anything that made you hesitate. Publish.",
      "Days 8–30: ship two journal essays, one shop kit featured, ten personal notes to people who already trust you. No ads yet.",
      "Days 31–60: turn on partners. Add annual as a banner if monthly is converting. Interview three paying users and change copy with their nouns, not yours.",
      "Days 61–90: raise the ceiling story — case note with a number — on the homepage. Cut any tool nobody used. Do not add a feature. Add a sentence that sells the ones you have.",
    ],
  },
  {
    id: "metrics",
    title: "Numbers that matter",
    paragraphs: [
      "Visit → calculator start. Calculator → saved rate. Saved rate → first invoice. Invoice → Pro checkout. Shop attach rate on the success page. Time-to-paid on invoices. Refunds. Partner-sourced revenue. If a metric does not change a decision this month, stop drawing it.",
    ],
  },
  {
    id: "mistakes",
    title: "Mistakes that kill this category",
    paragraphs: [
      "Hiding the price. Shipping a free plan that cannot make a real invoice. Writing like a productivity guru. Adding a social feed. Discounting Pro every other week. Sending invoices that still look like QuickBooks in 2009. Begging for a card before the rate is true. You have the other version in front of you. Run that.",
    ],
  },
];
