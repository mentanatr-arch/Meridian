import type { Invoice, Proposal } from "@/lib/types";
import { formatDate, moneyExact } from "@/lib/utils";
import { lineAmount, subtotalOf, taxOf, totalOf } from "@/lib/totals";
import { cn } from "@/lib/utils";

function PartyBlock({
  label,
  name,
  email,
  address,
}: {
  label: string;
  name: string;
  email: string;
  address: string;
}) {
  return (
    <div>
      <p className="text-[11px] font-medium tracking-[0.16em] text-muted uppercase">
        {label}
      </p>
      <p className="mt-2 font-serif text-lg leading-snug">{name || "—"}</p>
      {email ? <p className="mt-1 text-sm text-muted">{email}</p> : null}
      {address ? (
        <p className="mt-1 whitespace-pre-line text-sm text-muted">{address}</p>
      ) : null}
    </div>
  );
}

export function InvoicePaper({
  invoice,
  className,
}: {
  invoice: Invoice;
  className?: string;
}) {
  const sub = subtotalOf(invoice.items);
  const tax = taxOf(invoice.items, invoice.taxRate);
  const total = totalOf(invoice.items, invoice.taxRate);

  return (
    <article
      className={cn(
        "print-paper rounded-xl bg-bg-elevated p-8 text-fg shadow-[var(--shadow-border)] sm:p-12",
        className,
      )}
    >
      <header className="flex flex-col gap-6 border-b border-border pb-8 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
            Meridian
          </p>
          <h2 className="mt-2 font-serif text-4xl tracking-tight">Invoice</h2>
        </div>
        <div className="text-sm sm:text-right">
          <p className="font-medium tabular-nums">{invoice.number}</p>
          <p className="mt-1 text-muted">Issued {formatDate(invoice.issuedOn)}</p>
          <p className="text-muted">Due {formatDate(invoice.dueOn)}</p>
        </div>
      </header>
      <div className="mt-8 grid gap-8 sm:grid-cols-2">
        <PartyBlock label="From" {...invoice.from} />
        <PartyBlock label="Bill to" {...invoice.client} />
      </div>
      <table className="mt-10 w-full text-sm">
        <thead>
          <tr className="border-b border-border text-left text-[11px] tracking-[0.14em] text-muted uppercase">
            <th className="pb-3 font-medium">Description</th>
            <th className="pb-3 text-right font-medium">Qty</th>
            <th className="pb-3 text-right font-medium">Rate</th>
            <th className="pb-3 text-right font-medium">Amount</th>
          </tr>
        </thead>
        <tbody>
          {invoice.items.map((item) => (
            <tr key={item.id} className="border-b border-border/70">
              <td className="py-3 pr-4">{item.description || "—"}</td>
              <td className="py-3 text-right tabular-nums">{item.quantity}</td>
              <td className="py-3 text-right tabular-nums">
                {moneyExact(item.rate, invoice.currency)}
              </td>
              <td className="py-3 text-right tabular-nums">
                {moneyExact(lineAmount(item), invoice.currency)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-6 flex justify-end">
        <dl className="w-full max-w-xs space-y-2 text-sm">
          <div className="flex justify-between text-muted">
            <dt>Subtotal</dt>
            <dd className="tabular-nums">{moneyExact(sub, invoice.currency)}</dd>
          </div>
          <div className="flex justify-between text-muted">
            <dt>Tax {invoice.taxRate}%</dt>
            <dd className="tabular-nums">{moneyExact(tax, invoice.currency)}</dd>
          </div>
          <div className="flex justify-between border-t border-border pt-2 font-medium">
            <dt>Total</dt>
            <dd className="font-serif text-2xl tabular-nums">
              {moneyExact(total, invoice.currency)}
            </dd>
          </div>
        </dl>
      </div>
      {invoice.notes ? (
        <p className="mt-10 whitespace-pre-line text-sm leading-relaxed text-muted">
          {invoice.notes}
        </p>
      ) : null}
    </article>
  );
}

export function ProposalPaper({
  proposal,
  className,
}: {
  proposal: Proposal;
  className?: string;
}) {
  const total = totalOf(proposal.items, proposal.taxRate);

  return (
    <article
      className={cn(
        "print-paper rounded-xl bg-bg-elevated p-8 text-fg shadow-[var(--shadow-border)] sm:p-12",
        className,
      )}
    >
      <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
        {proposal.number}
      </p>
      <h2 className="mt-3 font-serif text-4xl tracking-tight">
        {proposal.title || "Proposal"}
      </h2>
      <p className="mt-2 text-sm text-muted">
        {formatDate(proposal.issuedOn)} · Valid through{" "}
        {formatDate(proposal.validUntil)}
      </p>
      {proposal.summary ? (
        <p className="mt-6 max-w-2xl text-lg leading-relaxed text-fg">
          {proposal.summary}
        </p>
      ) : null}
      <div className="mt-10 grid gap-8 sm:grid-cols-2">
        <PartyBlock label="From" {...proposal.from} />
        <PartyBlock label="Prepared for" {...proposal.client} />
      </div>
      {proposal.scope ? (
        <section className="mt-10">
          <h3 className="text-[11px] font-medium tracking-[0.16em] text-muted uppercase">
            Scope
          </h3>
          <p className="mt-3 whitespace-pre-line text-sm leading-relaxed">
            {proposal.scope}
          </p>
        </section>
      ) : null}
      {proposal.timeline ? (
        <section className="mt-8">
          <h3 className="text-[11px] font-medium tracking-[0.16em] text-muted uppercase">
            Timeline
          </h3>
          <p className="mt-3 whitespace-pre-line text-sm leading-relaxed">
            {proposal.timeline}
          </p>
        </section>
      ) : null}
      <section className="mt-8">
        <h3 className="text-[11px] font-medium tracking-[0.16em] text-muted uppercase">
          Investment
        </h3>
        <ul className="mt-4 space-y-2">
          {proposal.items.map((item) => (
            <li key={item.id} className="flex justify-between gap-4 text-sm">
              <span>{item.description || "—"}</span>
              <span className="tabular-nums">
                {moneyExact(lineAmount(item), proposal.currency)}
              </span>
            </li>
          ))}
        </ul>
        <p className="mt-4 font-serif text-3xl tabular-nums">
          {moneyExact(total, proposal.currency)}
        </p>
      </section>
      {proposal.notes ? (
        <p className="mt-10 whitespace-pre-line text-sm leading-relaxed text-muted">
          {proposal.notes}
        </p>
      ) : null}
    </article>
  );
}
