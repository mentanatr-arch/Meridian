import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function UpgradeWall({
  title = "Starter has a ceiling, on purpose",
  body = "Three invoices and one proposal are enough to feel the paper. Pro is unlimited — $19 a month, or $190 a year.",
}: {
  title?: string;
  body?: string;
}) {
  return (
    <div className="rounded-2xl bg-ink p-8 text-cream">
      <h2 className="font-serif text-3xl tracking-tight">{title}</h2>
      <p className="mt-3 max-w-xl text-sm leading-relaxed text-cream/70">{body}</p>
      <div className="mt-6 flex flex-wrap gap-3">
        <Button asChild className="bg-cream text-ink hover:bg-cream/90">
          <Link to="/pricing">See plans</Link>
        </Button>
        <Button asChild variant="outline" className="border-cream/20 text-cream hover:bg-cream/10">
          <Link to="/playbook">Why the ceiling exists</Link>
        </Button>
      </div>
    </div>
  );
}
