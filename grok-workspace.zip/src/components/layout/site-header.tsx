import { useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useStudio } from "@/lib/store";
import { useHydrated } from "@/lib/use-hydrated";

const NAV = [
  { to: "/tools", label: "Tools" },
  { to: "/pricing", label: "Pricing" },
  { to: "/shop", label: "Shop" },
  { to: "/journal", label: "Journal" },
  { to: "/playbook", label: "Playbook" },
] as const;

export function Mark({
  className,
  inverted = false,
}: {
  className?: string;
  inverted?: boolean;
}) {
  return (
    <Link
      to="/"
      className={cn("flex items-center gap-2", inverted ? "text-cream" : "text-fg", className)}
      aria-label="Meridian home"
    >
      <svg
        viewBox="0 0 32 32"
        className="size-7"
        aria-hidden="true"
        fill="none"
      >
        <rect
          width="32"
          height="32"
          rx="8"
          className={inverted ? "fill-cream" : "fill-primary"}
        />
        <path
          d="M8 22c8-2 8-12 16-14"
          className={inverted ? "stroke-ink" : "stroke-primary-fg"}
          strokeWidth="1.6"
          strokeLinecap="round"
        />
        <circle
          cx="16"
          cy="16"
          r="2"
          className={inverted ? "fill-ink" : "fill-primary-fg"}
        />
      </svg>
      <span className="font-serif text-xl tracking-tight">Meridian</span>
    </Link>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hydrated = useHydrated();
  const cartCount = useStudio((s) => s.cart.reduce((n, c) => n + c.quantity, 0));
  const count = hydrated ? cartCount : 0;

  return (
    <header className="no-print sticky top-0 z-40 border-b border-border/80 bg-bg/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        <Mark />
        <nav className="hidden items-center gap-7 md:flex" aria-label="Primary">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "text-sm font-medium text-muted transition-colors duration-150 hover:text-fg",
                pathname.startsWith(item.to) && "text-fg",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Link
            to="/checkout"
            className="relative inline-flex size-11 items-center justify-center rounded-md text-fg hover:bg-bg-subtle"
            aria-label="Cart"
          >
            <ShoppingBag className="size-5" />
            {count > 0 ? (
              <span className="absolute top-1.5 right-1.5 flex size-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-fg tabular-nums">
                {count}
              </span>
            ) : null}
          </Link>
          <Button asChild className="hidden sm:inline-flex">
            <Link to="/studio">Open studio</Link>
          </Button>
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-md md:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>
      {open ? (
        <div className="border-t border-border bg-bg px-4 py-4 md:hidden">
          <nav className="flex flex-col gap-1" aria-label="Mobile">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="flex h-11 items-center text-base font-medium text-fg"
              >
                {item.label}
              </Link>
            ))}
            <Button asChild className="mt-2 w-full">
              <Link to="/studio" onClick={() => setOpen(false)}>
                Open studio
              </Link>
            </Button>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
