import { Link } from "@tanstack/react-router";
import { Newsletter } from "@/components/layout/newsletter";
import { Mark } from "@/components/layout/site-header";
import { SITE } from "@/lib/catalog";

export function SiteFooter() {
  return (
    <footer className="no-print border-t border-border bg-ink text-cream">
      <div className="mx-auto grid max-w-6xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.3fr_1fr_1fr_1fr]">
        <div>
          <Mark inverted />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-cream/70">
            {SITE.tagline} {SITE.description}
          </p>
          <p className="mt-6 text-sm text-cream/50">{SITE.email}</p>
        </div>
        <FooterCol
          title="Product"
          links={[
            { to: "/studio", label: "Studio" },
            { to: "/tools", label: "Tools" },
            { to: "/pricing", label: "Pricing" },
            { to: "/shop", label: "Shop" },
          ]}
        />
        <FooterCol
          title="Learn"
          links={[
            { to: "/journal", label: "Journal" },
            { to: "/playbook", label: "Playbook" },
            { to: "/faq", label: "FAQ" },
            { to: "/partners", label: "Partners" },
          ]}
        />
        <div>
          <p className="text-xs font-medium tracking-[0.14em] text-cream/50 uppercase">
            Company
          </p>
          <ul className="mt-4 space-y-2">
            <li>
              <Link
                to="/about"
                className="text-sm text-cream/80 transition-colors duration-150 hover:text-cream"
              >
                About
              </Link>
            </li>
            <li>
              <Link
                to="/legal/$slug"
                params={{ slug: "terms" }}
                className="text-sm text-cream/80 transition-colors duration-150 hover:text-cream"
              >
                Terms
              </Link>
            </li>
            <li>
              <Link
                to="/legal/$slug"
                params={{ slug: "privacy" }}
                className="text-sm text-cream/80 transition-colors duration-150 hover:text-cream"
              >
                Privacy
              </Link>
            </li>
            <li>
              <Link
                to="/legal/$slug"
                params={{ slug: "refunds" }}
                className="text-sm text-cream/80 transition-colors duration-150 hover:text-cream"
              >
                Refunds
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-cream/10">
        <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-10 sm:px-6 lg:flex-row lg:items-end lg:justify-between">
          <Newsletter variant="ink" />
          <p className="text-xs text-cream/40">
            © {new Date().getFullYear()} Meridian Labs. Paper, rates, and time
            for independents.
          </p>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({
  title,
  links,
}: {
  title: string;
  links: { to: "/studio" | "/tools" | "/pricing" | "/shop" | "/journal" | "/playbook" | "/faq" | "/partners"; label: string }[];
}) {
  return (
    <div>
      <p className="text-xs font-medium tracking-[0.14em] text-cream/50 uppercase">
        {title}
      </p>
      <ul className="mt-4 space-y-2">
        {links.map((link) => (
          <li key={link.to}>
            <Link
              to={link.to}
              className="text-sm text-cream/80 transition-colors duration-150 hover:text-cream"
            >
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
