import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useStudio } from "@/lib/store";
import { cn } from "@/lib/utils";

export function Newsletter({
  variant = "paper",
  className,
}: {
  variant?: "paper" | "ink";
  className?: string;
}) {
  const subscribe = useStudio((s) => s.subscribe);
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  return (
    <form
      className={cn("w-full max-w-md", className)}
      onSubmit={(e) => {
        e.preventDefault();
        if (!email.includes("@")) return;
        subscribe(email.trim());
        setDone(true);
      }}
    >
      <p
        className={cn(
          "text-xs font-medium tracking-[0.14em] uppercase",
          variant === "ink" ? "text-cream/50" : "text-muted",
        )}
      >
        The Monday rate note
      </p>
      <p
        className={cn(
          "mt-1 text-sm",
          variant === "ink" ? "text-cream/70" : "text-muted",
        )}
      >
        One useful number or clause. No tools roundup.
      </p>
      {done ? (
        <p
          className={cn(
            "mt-3 text-sm font-medium",
            variant === "ink" ? "text-cream" : "text-primary",
          )}
        >
          You are on the list. See you Monday.
        </p>
      ) : (
        <div className="mt-3 flex gap-2">
          <Input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@studio.com"
            className={
              variant === "ink"
                ? "border-cream/15 bg-ink text-cream placeholder:text-cream/40"
                : undefined
            }
            aria-label="Email address"
          />
          <Button
            type="submit"
            variant={variant === "ink" ? "secondary" : "default"}
            className={
              variant === "ink" ? "bg-cream text-ink hover:bg-cream/90" : undefined
            }
          >
            Join
          </Button>
        </div>
      )}
    </form>
  );
}
