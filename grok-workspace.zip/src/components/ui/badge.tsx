import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide",
  {
    variants: {
      variant: {
        default: "bg-primary/10 text-primary",
        muted: "bg-bg-subtle text-muted",
        outline: "border border-border text-muted",
        ink: "bg-ink text-cream",
        paid: "bg-primary/10 text-primary",
        sent: "bg-bg-subtle text-fg",
        draft: "border border-border text-muted",
        overdue: "bg-danger/10 text-danger",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

function Badge({
  className,
  variant,
  ...props
}: React.ComponentProps<"span"> & VariantProps<typeof badgeVariants>) {
  return (
    <span className={cn(badgeVariants({ variant }), className)} {...props} />
  );
}

export { Badge, badgeVariants };
