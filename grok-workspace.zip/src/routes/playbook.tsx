import { createFileRoute, Link } from "@tanstack/react-router";
import { PLAYBOOK } from "@/lib/catalog";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/playbook")({
  component: Playbook,
  head: () => ({
    meta: [
      { title: "Playbook — How to run Meridian" },
      {
        name: "description",
        content:
          "The operating manual: money model, funnel, daily rhythm, and how to take Meridian live.",
      },
    ],
  }),
});

function Playbook() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
      <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
        Operator manual
      </p>
      <h1 className="mt-3 font-serif text-5xl tracking-tight">
        How to run Meridian
      </h1>
      <p className="mt-4 text-lg leading-relaxed text-muted">
        Use it as your freelance OS. Or treat the whole site as the company —
        software, shop, journal, partners. This is the order of operations.
      </p>
      <nav className="mt-10 rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]">
        <p className="text-xs tracking-[0.14em] text-subtle uppercase">Contents</p>
        <ol className="mt-3 columns-1 gap-6 sm:columns-2">
          {PLAYBOOK.map((s, i) => (
            <li key={s.id} className="break-inside-avoid py-1 text-sm">
              <a href={`#${s.id}`} className="text-fg hover:text-primary">
                <span className="tabular-nums text-muted">
                  {String(i + 1).padStart(2, "0")}
                </span>{" "}
                {s.title}
              </a>
            </li>
          ))}
        </ol>
      </nav>
      <div className="mt-16 space-y-16">
        {PLAYBOOK.map((section, i) => (
          <section key={section.id} id={section.id}>
            <p className="font-serif text-primary tabular-nums">
              {String(i + 1).padStart(2, "0")}
            </p>
            <h2 className="mt-2 font-serif text-3xl tracking-tight">
              {section.title}
            </h2>
            <div className="mt-4 space-y-4">
              {section.paragraphs.map((p) => (
                <p key={p.slice(0, 48)} className="leading-relaxed text-fg">
                  {p}
                </p>
              ))}
            </div>
          </section>
        ))}
      </div>
      <div className="mt-16 rounded-2xl bg-ink p-8 text-cream">
        <h2 className="font-serif text-3xl tracking-tight">
          First move: send a real invoice
        </h2>
        <p className="mt-3 text-sm text-cream/70">
          Everything else is commentary until money has moved on this paper.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button asChild className="bg-cream text-ink hover:bg-cream/90">
            <Link to="/onboarding">Open the studio</Link>
          </Button>
          <Button asChild variant="outline" className="border-cream/20 text-cream hover:bg-cream/10">
            <Link to="/tools/rates">Run the rate</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
