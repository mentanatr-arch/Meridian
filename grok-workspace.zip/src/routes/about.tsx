import { createFileRoute } from "@tanstack/react-router";
import { SITE } from "@/lib/catalog";

export const Route = createFileRoute("/about")({
  component: About,
  head: () => ({ meta: [{ title: "About — Meridian" }] }),
});

function About() {
  return (
    <div>
      <section className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2">
        <div>
          <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
            About
          </p>
          <h1 className="mt-3 font-serif text-5xl tracking-tight">
            A desk for people who invoice for thinking
          </h1>
          <p className="mt-5 text-lg leading-relaxed text-muted">
            Meridian started as the internal paper of a small studio that was
            tired of looking cheaper than the work. The invoices were the
            product. The software came after.
          </p>
        </div>
        <img
          src="/images/studio.jpg"
          alt="Empty studio with oak table and north light"
          className="h-[420px] w-full rounded-2xl object-cover"
        />
      </section>
      <section className="mx-auto max-w-3xl px-4 pb-20 sm:px-6">
        <p className="leading-relaxed">
          We build for independents and rooms of two to eight — designers,
          writers, strategists, engineers — who already know how to do the
          work and keep getting paid late, or too little, or both. We do not
          build for enterprises, or for people who need a social feed in their
          invoicing tool.
        </p>
        <p className="mt-5 leading-relaxed">
          The name is a line of longitude: a true north you can take a rate
          from. The look is cream, ink, and one forest green because paper
          should feel like a studio, not a dashboard.
        </p>
        <p className="mt-5 leading-relaxed text-muted">
          {SITE.email} · Independent practice, not a venture story.
        </p>
      </section>
    </div>
  );
}
