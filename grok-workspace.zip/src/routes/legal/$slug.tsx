import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/legal/$slug")({
  component: Legal,
});

const PAGES: Record<
  string,
  { title: string; updated: string; sections: { h: string; p: string }[] }
> = {
  terms: {
    title: "Terms of use",
    updated: "1 October 2026",
    sections: [
      {
        h: "The desk",
        p: "Meridian is software and digital paper for independent professionals. By using it you agree to these terms. If you cannot, do not open a studio here.",
      },
      {
        h: "Accounts and data on this preview",
        p: "This running preview stores your invoices, time, and cart on the device you are using. Publishing with hosted accounts later is a different contract, issued at that time.",
      },
      {
        h: "Plans",
        p: "Starter is free with stated ceilings. Pro and Studio renew monthly or annually until cancelled. You may cancel at period end. We may change prices with 30 days' notice to the email on the studio.",
      },
      {
        h: "Acceptable use",
        p: "Do not use Meridian to invoice for unlawful work, to harass, or to impersonate another practice. We may suspend a studio that does.",
      },
      {
        h: "Limitation",
        p: "The software is provided as-is. We are not your accountant or lawyer. Paper generated here is a starting point, not counsel.",
      },
    ],
  },
  privacy: {
    title: "Privacy",
    updated: "1 October 2026",
    sections: [
      {
        h: "What we collect in this preview",
        p: "Studio details, invoices, proposals, time, cart, and any email you type into a form stay in this browser unless you publish with a hosted backend.",
      },
      {
        h: "What we ask of a live deployment",
        p: "When payments and mail are connected, we will collect the email and billing details required to charge, receipt, and support you. We will not sell lists.",
      },
      {
        h: "Cookies",
        p: "A local preference store is used for the desk. We do not run third-party ad pixels on this preview.",
      },
      {
        h: "Contact",
        p: "Privacy questions: hello@meridian.studio.",
      },
    ],
  },
  refunds: {
    title: "Refunds",
    updated: "1 October 2026",
    sections: [
      {
        h: "Software",
        p: "Monthly plans can be cancelled any time; the period already paid is not refunded. Annual plans may be refunded within 14 days of charge if the studio has not been used as a production desk (more than three paid invoices).",
      },
      {
        h: "Shop kits",
        p: "Digital kits are refundable within 7 days if files were not downloaded in bulk. After that they are yours.",
      },
      {
        h: "This preview",
        p: "No cards are charged here. Refunds apply when a processor is connected on a published site.",
      },
    ],
  },
};

function Legal() {
  const { slug } = Route.useParams();
  const page = PAGES[slug];
  if (!page) {
    return (
      <div className="mx-auto max-w-xl px-6 py-24 text-center">
        <h1 className="font-serif text-3xl">No such page</h1>
        <Button asChild className="mt-6">
          <Link to="/">Home</Link>
        </Button>
      </div>
    );
  }
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
      <p className="text-xs text-subtle">Updated {page.updated}</p>
      <h1 className="mt-2 font-serif text-5xl tracking-tight">{page.title}</h1>
      <div className="mt-10 space-y-8">
        {page.sections.map((s) => (
          <section key={s.h}>
            <h2 className="font-serif text-2xl tracking-tight">{s.h}</h2>
            <p className="mt-2 leading-relaxed text-muted">{s.p}</p>
          </section>
        ))}
      </div>
    </div>
  );
}
