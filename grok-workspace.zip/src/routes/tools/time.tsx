import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UpgradeWall } from "@/components/upgrade-dialog";
import { blankInvoice, PROJECT_LIMIT, useStudio } from "@/lib/store";
import { uid, hoursMinutes, moneyExact } from "@/lib/utils";
import { useHydrated } from "@/lib/use-hydrated";

export const Route = createFileRoute("/tools/time")({
  component: TimePage,
  head: () => ({ meta: [{ title: "Time — Meridian" }] }),
});

function TimePage() {
  const hydrated = useHydrated();
  const entries = useStudio((s) => s.entries);
  const plan = useStudio((s) => s.plan);
  const profile = useStudio((s) => s.profile);
  const startTimer = useStudio((s) => s.startTimer);
  const stopTimer = useStudio((s) => s.stopTimer);
  const removeEntry = useStudio((s) => s.removeEntry);
  const addInvoice = useStudio((s) => s.addInvoice);
  const nextInvoiceNumber = useStudio((s) => s.nextInvoiceNumber);
  const [project, setProject] = useState("Harbor sprint");
  const [note, setNote] = useState("");
  const [now, setNow] = useState(Date.now());
  const [wall, setWall] = useState(false);

  const running = entries.find((e) => e.endedAt === null);

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, [running]);

  if (!hydrated) return <div className="mx-auto max-w-6xl px-4 py-16">Loading…</div>;

  const elapsed = running
    ? (now - running.startedAt) / 1000
    : 0;

  function start() {
    const result = startTimer(project.trim() || "Untitled", note, profile.defaultRate);
    if (!result.ok) {
      setWall(true);
      toast("Starter includes three projects.");
    }
  }

  function billSelected() {
    const closed = entries.filter((e) => e.endedAt && e.billable);
    if (closed.length === 0) {
      toast("No closed billable hours yet.");
      return;
    }
    const byProject = new Map<string, number>();
    for (const e of closed) {
      const hrs = ((e.endedAt as number) - e.startedAt) / 3600000;
      byProject.set(e.project, (byProject.get(e.project) ?? 0) + hrs);
    }
    const invoice = blankInvoice(profile, nextInvoiceNumber());
    invoice.items = [...byProject.entries()].map(([name, hrs]) => ({
      id: uid(),
      description: `${name} — tracked time`,
      quantity: Math.round(hrs * 10) / 10,
      rate: profile.defaultRate,
    }));
    const result = addInvoice(invoice);
    if (!result.ok) {
      setWall(true);
      return;
    }
    toast("Invoice drafted from time.");
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-serif text-4xl tracking-tight">Time</h1>
      <p className="mt-2 text-muted">
        One running clock. Starter holds {PROJECT_LIMIT.starter} projects.
      </p>

      <div className="mt-10 rounded-2xl bg-ink p-8 text-center text-cream">
        <p className="font-mono text-6xl tracking-tight tabular-nums sm:text-7xl">
          {hoursMinutes(running ? elapsed : 0)}
        </p>
        <p className="mt-2 text-sm text-cream/50">
          {running ? running.project : "Idle"}
        </p>
        <div className="mt-6 flex justify-center gap-3">
          {running ? (
            <Button className="bg-cream text-ink hover:bg-cream/90" onClick={stopTimer}>
              Stop
            </Button>
          ) : (
            <Button className="bg-cream text-ink hover:bg-cream/90" onClick={start}>
              Start
            </Button>
          )}
        </div>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <div>
          <Label className="mb-2 block">Project</Label>
          <Input value={project} onChange={(e) => setProject(e.target.value)} />
        </div>
        <div>
          <Label className="mb-2 block">Note</Label>
          <Input value={note} onChange={(e) => setNote(e.target.value)} />
        </div>
      </div>

      {wall ? (
        <div className="mt-8">
          <UpgradeWall body="Starter includes three time projects. Pro tracks the whole roster." />
        </div>
      ) : null}

      <div className="mt-8 flex gap-3">
        <Button variant="outline" onClick={billSelected}>
          Draft invoice from hours
        </Button>
        <Button asChild variant="ghost">
          <Link to="/tools/invoices">Invoices</Link>
        </Button>
      </div>

      <ul className="mt-10 divide-y divide-border rounded-2xl bg-bg-elevated shadow-[var(--shadow-border)]">
        {entries.length === 0 ? (
          <li className="p-6 text-sm text-muted">No entries yet. Start the clock.</li>
        ) : (
          entries.map((e) => {
            const end = e.endedAt ?? now;
            const secs = Math.max(0, (end - e.startedAt) / 1000);
            const amount = (secs / 3600) * e.rate;
            return (
              <li key={e.id} className="flex items-center justify-between gap-4 px-5 py-4">
                <div>
                  <p className="font-medium">{e.project}</p>
                  <p className="text-sm text-muted">
                    {e.note || "—"} · {hoursMinutes(secs)}
                    {e.endedAt === null ? " · running" : ""}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm tabular-nums text-muted">
                    {moneyExact(amount, profile.currency)}
                  </span>
                  <button
                    type="button"
                    className="text-sm text-muted hover:text-danger"
                    onClick={() => removeEntry(e.id)}
                  >
                    Remove
                  </button>
                </div>
              </li>
            );
          })
        )}
      </ul>
    </div>
  );
}
