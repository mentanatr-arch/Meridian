import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { UpgradeWall } from "@/components/upgrade-dialog";
import { blankProposal, PROPOSAL_LIMIT, useStudio } from "@/lib/store";
import { totalOf } from "@/lib/totals";
import { formatDate, moneyExact } from "@/lib/utils";
import { useHydrated } from "@/lib/use-hydrated";

export const Route = createFileRoute("/tools/proposals/")({
  component: Proposals,
  head: () => ({ meta: [{ title: "Proposals — Meridian" }] }),
});

function Proposals() {
  const hydrated = useHydrated();
  const navigate = useNavigate();
  const proposals = useStudio((s) => s.proposals);
  const profile = useStudio((s) => s.profile);
  const plan = useStudio((s) => s.plan);
  const addProposal = useStudio((s) => s.addProposal);
  const nextProposalNumber = useStudio((s) => s.nextProposalNumber);
  const [wall, setWall] = useState(false);

  if (!hydrated) return <div className="mx-auto max-w-6xl px-4 py-16">Loading…</div>;

  function create() {
    const proposal = blankProposal(profile, nextProposalNumber());
    const result = addProposal(proposal);
    if (!result.ok) {
      setWall(true);
      toast("Starter includes one proposal.");
      return;
    }
    navigate({
      to: "/tools/proposals/$proposalId",
      params: { proposalId: proposal.id },
    });
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-serif text-4xl tracking-tight">Proposals</h1>
          <p className="mt-2 text-muted">
            {proposals.length}
            {Number.isFinite(PROPOSAL_LIMIT[plan]) ? ` / ${PROPOSAL_LIMIT[plan]}` : ""} — a yes should become an invoice.
          </p>
        </div>
        <Button onClick={create}>New proposal</Button>
      </div>
      {wall ? (
        <div className="mt-8">
          <UpgradeWall body="Starter includes one proposal. Pro is unlimited paper, and a yes becomes an invoice without retyping." />
        </div>
      ) : null}
      <div className="mt-10 divide-y divide-border overflow-hidden rounded-2xl bg-bg-elevated shadow-[var(--shadow-border)]">
        {proposals.length === 0 ? (
          <div className="p-10 text-center">
            <p className="font-serif text-2xl">No proposals yet</p>
            <p className="mt-2 text-sm text-muted">
              Write the fence first. The number second.
            </p>
          </div>
        ) : (
          proposals.map((p) => (
            <Link
              key={p.id}
              to="/tools/proposals/$proposalId"
              params={{ proposalId: p.id }}
              className="flex flex-col gap-2 px-6 py-4 hover:bg-bg-subtle/60 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <p className="font-medium">
                  {p.number} · {p.title}
                </p>
                <p className="text-sm text-muted">
                  {p.client.name || "No client"} · {formatDate(p.issuedOn)}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant={p.status === "accepted" ? "paid" : "draft"}>
                  {p.status}
                </Badge>
                <span className="tabular-nums">
                  {moneyExact(totalOf(p.items, p.taxRate), p.currency)}
                </span>
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
