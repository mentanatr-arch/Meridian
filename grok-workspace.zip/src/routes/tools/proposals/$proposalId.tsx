import { useMemo } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Printer, Trash2, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ProposalPaper } from "@/components/paper";
import { blankInvoice, useStudio } from "@/lib/store";
import type { LineItem, Proposal, ProposalStatus } from "@/lib/types";
import { uid } from "@/lib/utils";
import { useHydrated } from "@/lib/use-hydrated";

export const Route = createFileRoute("/tools/proposals/$proposalId")({
  component: ProposalEditor,
  head: () => ({ meta: [{ title: "Proposal — Meridian" }] }),
});

const STATUSES: ProposalStatus[] = ["draft", "sent", "accepted", "declined"];

function ProposalEditor() {
  const { proposalId } = Route.useParams();
  const hydrated = useHydrated();
  const navigate = useNavigate();
  const proposals = useStudio((s) => s.proposals);
  const updateProposal = useStudio((s) => s.updateProposal);
  const removeProposal = useStudio((s) => s.removeProposal);
  const addInvoice = useStudio((s) => s.addInvoice);
  const nextInvoiceNumber = useStudio((s) => s.nextInvoiceNumber);
  const profile = useStudio((s) => s.profile);
  const proposal = useMemo(
    () => proposals.find((p) => p.id === proposalId),
    [proposals, proposalId],
  );

  if (!hydrated) return <div className="mx-auto max-w-6xl px-4 py-16">Loading…</div>;

  if (!proposal) {
    return (
      <div className="mx-auto max-w-xl px-6 py-24 text-center">
        <h1 className="font-serif text-3xl">Proposal not found</h1>
        <Button asChild className="mt-6">
          <Link to="/tools/proposals">Back</Link>
        </Button>
      </div>
    );
  }

  function patch(p: Partial<Proposal>) {
    updateProposal(proposalId, p);
  }

  function billTheYes() {
    const invoice = blankInvoice(profile, nextInvoiceNumber());
    invoice.client = proposal!.client;
    invoice.from = proposal!.from;
    invoice.items = proposal!.items.map((i) => ({ ...i, id: uid() }));
    invoice.taxRate = proposal!.taxRate;
    invoice.currency = proposal!.currency;
    invoice.notes = `Against ${proposal!.number} — ${proposal!.title}`;
    const result = addInvoice(invoice);
    if (!result.ok) {
      toast("Upgrade to bill from a proposal — invoice ceiling reached.");
      navigate({ to: "/pricing" });
      return;
    }
    patch({ status: "accepted" });
    navigate({ to: "/tools/invoices/$invoiceId", params: { invoiceId: invoice.id } });
  }

  function patchItem(id: string, key: keyof LineItem, value: string | number) {
    patch({
      items: proposal!.items.map((item) =>
        item.id === id ? { ...item, [key]: value } : item,
      ),
    });
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-2">
      <div className="no-print space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Link to="/tools/proposals" className="text-sm text-muted hover:text-fg">
            All proposals
          </Link>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => window.print()}>
              <Printer /> Print
            </Button>
            <Button onClick={billTheYes}>Bill the yes</Button>
            <Button
              variant="ghost"
              onClick={() => {
                removeProposal(proposalId);
                navigate({ to: "/tools/proposals" });
              }}
            >
              <Trash2 />
            </Button>
          </div>
        </div>
        <div>
          <Label className="mb-2 block">Title</Label>
          <Input value={proposal.title} onChange={(e) => patch({ title: e.target.value })} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <Label className="mb-2 block">Number</Label>
            <Input value={proposal.number} onChange={(e) => patch({ number: e.target.value })} />
          </div>
          <div>
            <Label className="mb-2 block">Status</Label>
            <select
              value={proposal.status}
              onChange={(e) => patch({ status: e.target.value as ProposalStatus })}
              className="flex h-11 w-full rounded-md border border-border bg-bg-elevated px-3 text-sm"
            >
              {STATUSES.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>
        <div>
          <Label className="mb-2 block">Summary</Label>
          <Textarea
            value={proposal.summary}
            onChange={(e) => patch({ summary: e.target.value })}
          />
        </div>
        <div>
          <Label className="mb-2 block">Client</Label>
          <Input
            placeholder="Name"
            value={proposal.client.name}
            onChange={(e) =>
              patch({ client: { ...proposal.client, name: e.target.value } })
            }
          />
        </div>
        <div>
          <Label className="mb-2 block">Scope (in, then out)</Label>
          <Textarea
            className="min-h-40"
            value={proposal.scope}
            onChange={(e) => patch({ scope: e.target.value })}
          />
        </div>
        <div>
          <Label className="mb-2 block">Timeline</Label>
          <Textarea
            value={proposal.timeline}
            onChange={(e) => patch({ timeline: e.target.value })}
          />
        </div>
        <div>
          <Label className="mb-2 block">Investment</Label>
          <div className="mt-2 space-y-2">
            {proposal.items.map((item) => (
              <div key={item.id} className="grid grid-cols-[1fr_7rem] gap-2">
                <Input
                  value={item.description}
                  onChange={(e) => patchItem(item.id, "description", e.target.value)}
                />
                <Input
                  inputMode="decimal"
                  value={item.rate}
                  onChange={(e) => patchItem(item.id, "rate", Number(e.target.value))}
                />
              </div>
            ))}
          </div>
          <Button
            type="button"
            variant="outline"
            className="mt-3"
            onClick={() =>
              patch({
                items: [
                  ...proposal.items,
                  { id: uid(), description: "", quantity: 1, rate: 0 },
                ],
              })
            }
          >
            <Plus /> Line
          </Button>
        </div>
        <div>
          <Label className="mb-2 block">Notes</Label>
          <Textarea
            value={proposal.notes}
            onChange={(e) => patch({ notes: e.target.value })}
          />
        </div>
      </div>
      <ProposalPaper proposal={proposal} />
    </div>
  );
}
