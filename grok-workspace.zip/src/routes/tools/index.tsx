import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, FileText, Gauge, PenLine } from "lucide-react";

export const Route = createFileRoute("/tools/")({
  component: Tools,
  head: () => ({ meta: [{ title: "Tools — Meridian" }] }),
});

const ITEMS = [
  {
    to: "/tools/invoices",
    icon: FileText,
    title: "Invoices",
    text: "Draft, send, mark paid, print. The paper clients pay fastest.",
  },
  {
    to: "/tools/rates",
    icon: Gauge,
    title: "Rate calculator",
    text: "Turn a life into an hourly, day, and sprint number you can defend.",
  },
  {
    to: "/tools/proposals",
    icon: PenLine,
    title: "Proposals",
    text: "Scope, fence, timeline, investment — then bill the yes.",
  },
  {
    to: "/tools/time",
    icon: Clock,
    title: "Time tracker",
    text: "A quiet clock. Hours become line items instead of folklore.",
  },
];

function Tools() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
      <h1 className="font-serif text-5xl tracking-tight">Tools</h1>
      <p className="mt-4 max-w-xl text-lg text-muted">
        Four instruments. Use them in order the first time: rate, proposal,
        time, invoice.
      </p>
      <div className="mt-12 grid gap-4 sm:grid-cols-2">
        {ITEMS.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className="rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
          >
            <item.icon className="size-5 text-primary" />
            <h2 className="mt-4 font-serif text-2xl tracking-tight">{item.title}</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">{item.text}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
