import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { UpgradeWall } from "@/components/upgrade-dialog";
import { blankInvoice, INVOICE_LIMIT, useStudio } from "@/lib/store";
import { totalOf } from "@/lib/totals";
import { formatDate, moneyExact } from "@/lib/utils";
import { useHydrated } from "@/lib/use-hydrated";

export const Route = createFileRoute("/tools/invoices/")({
  component: Invoices,
  head: () => ({ meta: [{ title: "Invoices — Meridian" }] }),
});

function Invoices() {
  const hydrated = useHydrated();
  const navigate = useNavigate();
  const seedIfNeeded = useStudio((s) => s.seedIfNeeded);
  const invoices = useStudio((s) => s.invoices);
  const profile = useStudio((s) => s.profile);
  const plan = useStudio((s) => s.plan);
  const addInvoice = useStudio((s) => s.addInvoice);
  const nextInvoiceNumber = useStudio((s) => s.nextInvoiceNumber);
  const [wall, setWall] = useState(false);

  useEffect(() => {
    seedIfNeeded();
  }, [seedIfNeeded]);

  if (!hydrated) {
    return <div className="mx-auto max-w-6xl px-4 py-16">Loading…</div>;
  }

  function create() {
    const invoice = blankInvoice(profile, nextInvoiceNumber());
    const result = addInvoice(invoice);
    if (!result.ok) {
      setWall(true);
      toast("Starter includes three invoices.");
      return;
    }
    navigate({
      to: "/tools/invoices/$invoiceId",
      params: { invoiceId: invoice.id },
    });
  }

  const limit = INVOICE_LIMIT[plan];

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-serif text-4xl tracking-tight">Invoices</h1>
          <p className="mt-2 text-muted">
            {invoices.length}
            {Number.isFinite(limit) ? ` / ${limit}` : ""} on this desk
          </p>
        </div>
        <Button onClick={create}>New invoice</Button>
      </div>

      {wall ? (
        <div className="mt-8">
          <UpgradeWall />
        </div>
      ) : null}

      <div className="mt-10 divide-y divide-border overflow-hidden rounded-2xl bg-bg-elevated shadow-[var(--shadow-border)]">
        {invoices.length === 0 ? (
          <div className="p-10 text-center">
            <p className="font-serif text-2xl">No paper yet</p>
            <p className="mt-2 text-sm text-muted">
              Create the first invoice. Starter includes three.
            </p>
          </div>
        ) : (
          invoices.map((inv) => (
            <Link
              key={inv.id}
              to="/tools/invoices/$invoiceId"
              params={{ invoiceId: inv.id }}
              className="flex flex-col gap-2 px-6 py-4 hover:bg-bg-subtle/60 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <p className="font-medium">
                  {inv.number} · {inv.client.name || "Untitled client"}
                </p>
                <p className="text-sm text-muted">
                  {formatDate(inv.issuedOn)} · due {formatDate(inv.dueOn)}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant={inv.status}>{inv.status}</Badge>
                <span className="tabular-nums">
                  {moneyExact(totalOf(inv.items, inv.taxRate), inv.currency)}
                </span>
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
