import { useMemo, type ReactNode } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Printer, Trash2, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { InvoicePaper } from "@/components/paper";
import { useStudio } from "@/lib/store";
import type { Invoice, InvoiceStatus, LineItem } from "@/lib/types";
import { uid } from "@/lib/utils";
import { useHydrated } from "@/lib/use-hydrated";

export const Route = createFileRoute("/tools/invoices/$invoiceId")({
  component: InvoiceEditor,
  head: () => ({ meta: [{ title: "Invoice — Meridian" }] }),
});

const STATUSES: InvoiceStatus[] = ["draft", "sent", "paid", "overdue"];

function InvoiceEditor() {
  const { invoiceId } = Route.useParams();
  const hydrated = useHydrated();
  const navigate = useNavigate();
  const invoices = useStudio((s) => s.invoices);
  const updateInvoice = useStudio((s) => s.updateInvoice);
  const removeInvoice = useStudio((s) => s.removeInvoice);
  const invoice = useMemo(
    () => invoices.find((i) => i.id === invoiceId),
    [invoices, invoiceId],
  );

  if (!hydrated) {
    return <div className="mx-auto max-w-6xl px-4 py-16">Loading…</div>;
  }

  if (!invoice) {
    return (
      <div className="mx-auto max-w-xl px-6 py-24 text-center">
        <h1 className="font-serif text-3xl">That invoice is not on this desk</h1>
        <Button asChild className="mt-6">
          <Link to="/tools/invoices">Back to invoices</Link>
        </Button>
      </div>
    );
  }

  const current = invoice;

  function patch(p: Partial<Invoice>) {
    updateInvoice(invoiceId, p);
  }

  function patchParty(
    side: "from" | "client",
    key: "name" | "email" | "address",
    value: string,
  ) {
    patch({ [side]: { ...current[side], [key]: value } });
  }

  function patchItem(id: string, key: keyof LineItem, value: string | number) {
    patch({
      items: current.items.map((item) =>
        item.id === id ? { ...item, [key]: value } : item,
      ),
    });
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      <div className="no-print">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Link to="/tools/invoices" className="text-sm text-muted hover:text-fg">
            All invoices
          </Link>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => window.print()}>
              <Printer />
              Print / PDF
            </Button>
            <Button
              variant="ghost"
              onClick={() => {
                removeInvoice(invoiceId);
                toast("Invoice removed");
                navigate({ to: "/tools/invoices" });
              }}
            >
              <Trash2 />
            </Button>
          </div>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <Field label="Number">
            <Input value={current.number} onChange={(e) => patch({ number: e.target.value })} />
          </Field>
          <Field label="Status">
            <select
              value={current.status}
              onChange={(e) => patch({ status: e.target.value as InvoiceStatus })}
              className="flex h-11 w-full rounded-md border border-border bg-bg-elevated px-3 text-sm"
            >
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Issued">
            <Input
              type="date"
              value={current.issuedOn}
              onChange={(e) => patch({ issuedOn: e.target.value })}
            />
          </Field>
          <Field label="Due">
            <Input
              type="date"
              value={current.dueOn}
              onChange={(e) => patch({ dueOn: e.target.value })}
            />
          </Field>
        </div>

        <div className="mt-8 grid gap-6 sm:grid-cols-2">
          <fieldset className="space-y-3">
            <legend className="text-sm font-medium">From</legend>
            <Input
              placeholder="Studio"
              value={current.from.name}
              onChange={(e) => patchParty("from", "name", e.target.value)}
            />
            <Input
              placeholder="Email"
              value={current.from.email}
              onChange={(e) => patchParty("from", "email", e.target.value)}
            />
            <Textarea
              placeholder="Address"
              value={current.from.address}
              onChange={(e) => patchParty("from", "address", e.target.value)}
            />
          </fieldset>
          <fieldset className="space-y-3">
            <legend className="text-sm font-medium">Client</legend>
            <Input
              placeholder="Client"
              value={current.client.name}
              onChange={(e) => patchParty("client", "name", e.target.value)}
            />
            <Input
              placeholder="Email"
              value={current.client.email}
              onChange={(e) => patchParty("client", "email", e.target.value)}
            />
            <Textarea
              placeholder="Address"
              value={current.client.address}
              onChange={(e) => patchParty("client", "address", e.target.value)}
            />
          </fieldset>
        </div>

        <div className="mt-8">
          <p className="text-sm font-medium">Line items</p>
          <div className="mt-3 space-y-3">
            {current.items.map((item) => (
              <div key={item.id} className="grid grid-cols-1 gap-2 sm:grid-cols-4">
                <Input
                  placeholder="Description"
                  value={item.description}
                  onChange={(e) => patchItem(item.id, "description", e.target.value)}
                />
                <Input
                  inputMode="decimal"
                  value={item.quantity}
                  onChange={(e) => patchItem(item.id, "quantity", Number(e.target.value))}
                  aria-label="Quantity"
                />
                <Input
                  inputMode="decimal"
                  value={item.rate}
                  onChange={(e) => patchItem(item.id, "rate", Number(e.target.value))}
                  aria-label="Rate"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="size-11"
                  onClick={() =>
                    patch({ items: current.items.filter((i) => i.id !== item.id) })
                  }
                  aria-label="Remove line"
                >
                  <Trash2 />
                </Button>
              </div>
            ))}
          </div>
          <Button
            type="button"
            variant="outline"
            className="mt-3"
            onClick={() =>
              patch({
                items: [
                  ...current.items,
                  { id: uid(), description: "", quantity: 1, rate: 0 },
                ],
              })
            }
          >
            <Plus />
            Add line
          </Button>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          <Field label="Tax %">
            <Input
              inputMode="decimal"
              value={current.taxRate}
              onChange={(e) => patch({ taxRate: Number(e.target.value) })}
            />
          </Field>
          <Field label="Currency">
            <Input
              value={current.currency}
              onChange={(e) => patch({ currency: e.target.value.toUpperCase() })}
            />
          </Field>
        </div>
        <Field label="Notes" className="mt-4">
          <Textarea
            value={current.notes}
            onChange={(e) => patch({ notes: e.target.value })}
          />
        </Field>
      </div>

      <div>
        <InvoicePaper invoice={current} />
      </div>
    </div>
  );
}

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <Label className="mb-2 block">{label}</Label>
      {children}
    </div>
  );
}
