import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Newsletter } from "@/components/layout/newsletter";
import { useStudio } from "@/lib/store";
import { computeRate } from "@/lib/totals";
import { money } from "@/lib/utils";
import { useHydrated } from "@/lib/use-hydrated";

export const Route = createFileRoute("/tools/rates")({
  component: Rates,
  head: () => ({
    meta: [
      { title: "Rate calculator — Meridian" },
      {
        name: "description",
        content:
          "Price the year first. Meridian turns income, hours, overhead, tax, and profit into an hourly you can defend.",
      },
    ],
  }),
});

function Field({
  label,
  suffix,
  value,
  onChange,
}: {
  label: string;
  suffix?: string;
  value: number;
  onChange: (n: number) => void;
}) {
  return (
    <div>
      <Label className="mb-2 block">{label}</Label>
      <div className="relative">
        <Input
          inputMode="decimal"
          value={Number.isFinite(value) ? value : 0}
          onChange={(e) => onChange(Number(e.target.value))}
        />
        {suffix ? (
          <span className="pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-sm text-subtle">
            {suffix}
          </span>
        ) : null}
      </div>
    </div>
  );
}

function Rates() {
  const hydrated = useHydrated();
  const rate = useStudio((s) => s.rate);
  const setRate = useStudio((s) => s.setRate);
  const model = computeRate(rate);

  const chart = [
    { name: "Life", value: rate.desired },
    { name: "Overhead", value: model.withOverhead - rate.desired },
    { name: "Profit", value: model.withProfit - model.withOverhead },
    { name: "Tax reserve", value: model.gross - model.withProfit },
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
        Price from the year
      </p>
      <h1 className="mt-3 font-serif text-5xl tracking-tight">Price the year</h1>
      <p className="mt-4 max-w-2xl text-lg text-muted">
        Independents go broke on hourly vibes. This calculator funds a life,
        then divides by the hours you can actually sell.
      </p>

      <div className="mt-10 grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
        <div className="space-y-4 rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]">
          <Field
            label="Desired yearly income"
            value={rate.desired}
            onChange={(n) => setRate({ desired: n })}
          />
          <div className="grid grid-cols-2 gap-4">
            <Field
              label="Weeks you will work"
              value={rate.weeks}
              onChange={(n) => setRate({ weeks: n })}
            />
            <Field
              label="Hours on the clock / week"
              value={rate.hoursPerWeek}
              onChange={(n) => setRate({ hoursPerWeek: n })}
            />
          </div>
          <Field
            label="Utilization — hours you can sell"
            suffix="%"
            value={rate.utilization}
            onChange={(n) => setRate({ utilization: n })}
          />
          <Field
            label="Overhead"
            suffix="%"
            value={rate.overhead}
            onChange={(n) => setRate({ overhead: n })}
          />
          <Field
            label="Tax reserve"
            suffix="%"
            value={rate.tax}
            onChange={(n) => setRate({ tax: n })}
          />
          <Field
            label="Profit buffer"
            suffix="%"
            value={rate.profit}
            onChange={(n) => setRate({ profit: n })}
          />
          <p className="text-xs text-subtle">
            Saved on this device. {hydrated ? "Your numbers persist." : ""}
          </p>
        </div>

        <div>
          <div className="rounded-2xl bg-ink p-8 text-cream">
            <p className="text-sm text-cream/60">Your defendable hourly</p>
            <p className="mt-2 font-serif text-6xl tracking-tight tabular-nums">
              {money(model.hourly, rate.currency)}
            </p>
            <dl className="mt-8 grid grid-cols-2 gap-4 text-sm">
              <div>
                <dt className="text-cream/50">Day (8h)</dt>
                <dd className="mt-1 font-serif text-2xl tabular-nums">
                  {money(model.dayRate8, rate.currency)}
                </dd>
              </div>
              <div>
                <dt className="text-cream/50">Week</dt>
                <dd className="mt-1 font-serif text-2xl tabular-nums">
                  {money(model.weekly, rate.currency)}
                </dd>
              </div>
              <div>
                <dt className="text-cream/50">Billable hours / year</dt>
                <dd className="mt-1 font-serif text-2xl tabular-nums">
                  {Math.round(model.billableHours)}
                </dd>
              </div>
              <div>
                <dt className="text-cream/50">Gross to collect</dt>
                <dd className="mt-1 font-serif text-2xl tabular-nums">
                  {money(model.gross, rate.currency)}
                </dd>
              </div>
            </dl>
          </div>

          <div className="mt-6 h-56 rounded-2xl bg-bg-elevated p-4 shadow-[var(--shadow-border)]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart}>
                <XAxis dataKey="name" tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
                <YAxis
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  tickFormatter={(v) => `${Math.round(Number(v) / 1000)}k`}
                />
                <Tooltip
                  formatter={(v) => money(Number(v), rate.currency)}
                  contentStyle={{
                    background: "var(--color-bg-elevated)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 12,
                  }}
                />
                <Bar dataKey="value" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <Button asChild>
              <Link to="/tools/invoices">Put it on an invoice</Link>
            </Button>
            <Button asChild variant="outline">
              <Link to="/journal/$slug" params={{ slug: "rate-that-holds" }}>
                Read the arithmetic
              </Link>
            </Button>
          </div>
          <div className="mt-8">
            <Newsletter />
          </div>
        </div>
      </div>
    </div>
  );
}
