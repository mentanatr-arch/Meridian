import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStudio } from "@/lib/store";

export const Route = createFileRoute("/onboarding")({
  component: Onboarding,
  head: () => ({ meta: [{ title: "Open your studio — Meridian" }] }),
});

function Onboarding() {
  const navigate = useNavigate();
  const profile = useStudio((s) => s.profile);
  const setProfile = useStudio((s) => s.setProfile);
  const setRate = useStudio((s) => s.setRate);
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    name: profile.name === "Your studio" ? "" : profile.name,
    owner: profile.owner,
    email: profile.email,
    address: profile.address,
    currency: profile.currency,
    desired: "140000",
    defaultRate: String(profile.defaultRate),
  });

  function patch<K extends keyof typeof form>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function finish() {
    setProfile({
      name: form.name || "Your studio",
      owner: form.owner,
      email: form.email,
      address: form.address,
      currency: form.currency,
      defaultRate: Number(form.defaultRate) || 150,
      onboarded: true,
    });
    setRate({
      desired: Number(form.desired) || 140000,
      currency: form.currency,
    });
    navigate({ to: "/studio" });
  }

  return (
    <div className="mx-auto max-w-xl px-4 py-16 sm:px-6">
      <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
        Step {step + 1} of 3
      </p>
      <h1 className="mt-3 font-serif text-4xl tracking-tight">
        {step === 0 && "Name the practice"}
        {step === 1 && "Where should money land"}
        {step === 2 && "What should the year fund"}
      </h1>
      <p className="mt-3 text-muted">
        This writes your letterhead. You can change it later in Studio.
      </p>

      {step === 0 ? (
        <div className="mt-8 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="studio">Studio name</Label>
            <Input
              id="studio"
              value={form.name}
              onChange={(e) => patch("name", e.target.value)}
              placeholder="North Studio"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="owner">Your name</Label>
            <Input
              id="owner"
              value={form.owner}
              onChange={(e) => patch("owner", e.target.value)}
              placeholder="Ada North"
            />
          </div>
        </div>
      ) : null}

      {step === 1 ? (
        <div className="mt-8 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Invoice email</Label>
            <Input
              id="email"
              type="email"
              value={form.email}
              onChange={(e) => patch("email", e.target.value)}
              placeholder="studio@north.example"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="address">Address on the paper</Label>
            <Textarea
              id="address"
              value={form.address}
              onChange={(e) => patch("address", e.target.value)}
              placeholder={"14 Mercer\nFloor 3"}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="currency">Currency</Label>
            <select
              id="currency"
              value={form.currency}
              onChange={(e) => patch("currency", e.target.value)}
              className="flex h-11 w-full rounded-md border border-border bg-bg-elevated px-3 text-sm"
            >
              {["USD", "EUR", "GBP", "CAD", "AUD"].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>
      ) : null}

      {step === 2 ? (
        <div className="mt-8 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="desired">Desired yearly income</Label>
            <Input
              id="desired"
              inputMode="numeric"
              value={form.desired}
              onChange={(e) => patch("desired", e.target.value)}
            />
            <p className="text-xs text-muted">
              The life, not the hustle number. The calculator will do the rest.
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="rate">Starting hourly (you can ignore this)</Label>
            <Input
              id="rate"
              inputMode="numeric"
              value={form.defaultRate}
              onChange={(e) => patch("defaultRate", e.target.value)}
            />
          </div>
        </div>
      ) : null}

      <div className="mt-10 flex gap-3">
        {step > 0 ? (
          <Button type="button" variant="outline" onClick={() => setStep((s) => s - 1)}>
            Back
          </Button>
        ) : null}
        {step < 2 ? (
          <Button type="button" onClick={() => setStep((s) => s + 1)}>
            Continue
          </Button>
        ) : (
          <Button type="button" onClick={finish}>
            Open the studio
          </Button>
        )}
      </div>
    </div>
  );
}
