import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { PRODUCTS } from "@/lib/catalog";
import { useStudio } from "@/lib/store";
import { moneyExact } from "@/lib/utils";
import { useHydrated } from "@/lib/use-hydrated";

type Search = { order?: string };

export const Route = createFileRoute("/checkout/success")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    order: typeof s.order === "string" ? s.order : undefined,
  }),
  component: Success,
  head: () => ({ meta: [{ title: "Receipt — Meridian" }] }),
});

function Success() {
  const { order: orderId } = Route.useSearch();
  const hydrated = useHydrated();
  const orders = useStudio((s) => s.orders);
  const order = orders.find((o) => o.id === orderId) ?? orders[0];
  const attach = PRODUCTS[0];

  if (!hydrated) return <div className="mx-auto max-w-xl px-4 py-16">Loading…</div>;

  return (
    <div className="mx-auto max-w-xl px-4 py-20 text-center sm:px-6">
      <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
        Paid · preview
      </p>
      <h1 className="mt-3 font-serif text-5xl tracking-tight">You are on the desk</h1>
      {order ? (
        <p className="mt-4 text-muted">
          Order {order.id} · {moneyExact(order.total, order.currency)} · {order.email}
        </p>
      ) : (
        <p className="mt-4 text-muted">Receipt is on this device.</p>
      )}
      {order?.plan ? (
        <p className="mt-2 text-sm text-muted">
          Plan: {order.plan.id} ({order.plan.billing})
        </p>
      ) : null}
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Button asChild>
          <Link to="/studio">Open studio</Link>
        </Button>
        <Button asChild variant="outline">
          <Link to="/playbook">Read the playbook</Link>
        </Button>
      </div>
      {attach ? (
        <div className="mt-14 rounded-2xl bg-bg-elevated p-6 text-left shadow-[var(--shadow-border)]">
          <p className="text-sm text-muted">Most independents add this next</p>
          <p className="mt-1 font-serif text-2xl">{attach.title}</p>
          <p className="mt-2 text-sm text-muted">{attach.blurb}</p>
          <Button asChild className="mt-4" variant="outline">
            <Link to="/shop/$slug" params={{ slug: attach.slug }}>
              View kit
            </Link>
          </Button>
        </div>
      ) : null}
    </div>
  );
}
