import { useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PLANS, PRODUCTS, getProduct, planPrice } from "@/lib/catalog";
import { useStudio } from "@/lib/store";
import type { Billing, PlanId } from "@/lib/types";
import { money, moneyExact } from "@/lib/utils";
import { useHydrated } from "@/lib/use-hydrated";

type Search = { plan?: string; billing?: string };

export const Route = createFileRoute("/checkout/")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    plan: typeof s.plan === "string" ? s.plan : undefined,
    billing: typeof s.billing === "string" ? s.billing : undefined,
  }),
  component: Checkout,
  head: () => ({ meta: [{ title: "Checkout — Meridian" }] }),
});

function Checkout() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const hydrated = useHydrated();
  const cart = useStudio((s) => s.cart);
  const setCartQty = useStudio((s) => s.setCartQty);
  const removeFromCart = useStudio((s) => s.removeFromCart);
  const placeOrder = useStudio((s) => s.placeOrder);
  const profile = useStudio((s) => s.profile);

  const planId = (["pro", "studio"].includes(search.plan || "") ? search.plan : undefined) as
    | PlanId
    | undefined;
  const billing: Billing = search.billing === "monthly" ? "monthly" : "annual";
  const plan = PLANS.find((p) => p.id === planId);

  const [name, setName] = useState(profile.owner);
  const [email, setEmail] = useState(profile.email);
  const [busy, setBusy] = useState(false);

  const lines = useMemo(
    () =>
      cart
        .map((c) => {
          const p = getProduct(c.slug);
          if (!p) return null;
          return { ...c, product: p };
        })
        .filter(Boolean) as { slug: string; quantity: number; product: (typeof PRODUCTS)[number] }[],
    [cart],
  );

  const goods = lines.reduce((s, l) => s + l.product.price * l.quantity, 0);
  const planTotal = plan ? planPrice(plan.id, billing) : 0;
  const total = goods + planTotal;

  if (!hydrated) return <div className="mx-auto max-w-4xl px-4 py-16">Loading…</div>;

  const empty = lines.length === 0 && !plan;

  return (
    <div className="mx-auto grid max-w-5xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
      <div>
        <h1 className="font-serif text-4xl tracking-tight">Checkout</h1>
        <p className="mt-2 text-sm text-muted">
          Preview mode — no card is charged. The same screens take real money
          when a processor is connected.
        </p>
        {empty ? (
          <div className="mt-10 rounded-2xl bg-bg-elevated p-8 shadow-[var(--shadow-border)]">
            <p className="font-serif text-2xl">Nothing on the desk yet</p>
            <div className="mt-4 flex gap-3">
              <Button asChild>
                <Link to="/shop">Shop kits</Link>
              </Button>
              <Button asChild variant="outline">
                <Link to="/pricing">See plans</Link>
              </Button>
            </div>
          </div>
        ) : (
          <form
            className="mt-8 space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              setBusy(true);
              const order = placeOrder({
                name,
                email,
                withPlan: plan ? { id: plan.id, billing } : undefined,
              });
              navigate({ to: "/checkout/success", search: { order: order.id } });
            }}
          >
            <div>
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                required
                className="mt-2"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="email">Email for the receipt</Label>
              <Input
                id="email"
                type="email"
                required
                className="mt-2"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="card">Card</Label>
              <Input
                id="card"
                className="mt-2"
                placeholder="4242 4242 4242 4242"
                defaultValue="4242 4242 4242 4242"
              />
              <div className="mt-2 grid grid-cols-2 gap-2">
                <Input placeholder="MM/YY" defaultValue="12/28" aria-label="Expiry" />
                <Input placeholder="CVC" defaultValue="123" aria-label="CVC" />
              </div>
            </div>
            <Button type="submit" size="lg" className="w-full" disabled={busy}>
              {busy ? "Placing…" : `Pay ${moneyExact(total)}`}
            </Button>
          </form>
        )}
      </div>
      <aside className="rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]">
        <p className="text-sm font-medium">Order</p>
        <ul className="mt-4 space-y-4">
          {plan ? (
            <li className="flex justify-between gap-3 text-sm">
              <span>
                {plan.name} · {billing}
              </span>
              <span className="tabular-nums">{money(planTotal)}</span>
            </li>
          ) : null}
          {lines.map((l) => (
            <li key={l.slug} className="text-sm">
              <div className="flex justify-between gap-3">
                <span>{l.product.title}</span>
                <span className="tabular-nums">
                  {money(l.product.price * l.quantity)}
                </span>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <button
                  type="button"
                  className="size-8 rounded-md border border-border"
                  onClick={() => setCartQty(l.slug, l.quantity - 1)}
                >
                  −
                </button>
                <span className="tabular-nums">{l.quantity}</span>
                <button
                  type="button"
                  className="size-8 rounded-md border border-border"
                  onClick={() => setCartQty(l.slug, l.quantity + 1)}
                >
                  +
                </button>
                <button
                  type="button"
                  className="ml-auto text-xs text-muted hover:text-danger"
                  onClick={() => removeFromCart(l.slug)}
                >
                  Remove
                </button>
              </div>
            </li>
          ))}
        </ul>
        <div className="mt-6 flex justify-between border-t border-border pt-4 font-medium">
          <span>Total</span>
          <span className="font-serif text-2xl tabular-nums">{moneyExact(total)}</span>
        </div>
      </aside>
    </div>
  );
}
