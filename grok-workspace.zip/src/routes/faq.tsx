import { createFileRoute } from "@tanstack/react-router";
import { FAQS } from "@/lib/catalog";

export const Route = createFileRoute("/faq")({
  component: Faq,
  head: () => ({ meta: [{ title: "FAQ — Meridian" }] }),
});

function Faq() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
      <h1 className="font-serif text-5xl tracking-tight">FAQ</h1>
      <dl className="mt-10 divide-y divide-border border-y border-border">
        {FAQS.map((f) => (
          <div key={f.q} className="py-6">
            <dt className="font-serif text-2xl tracking-tight">{f.q}</dt>
            <dd className="mt-2 text-sm leading-relaxed text-muted">{f.a}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}
