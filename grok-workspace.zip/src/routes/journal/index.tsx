import { createFileRoute, Link } from "@tanstack/react-router";
import { ARTICLES } from "@/lib/catalog";
import { formatDate } from "@/lib/utils";

export const Route = createFileRoute("/journal/")({
  component: Journal,
  head: () => ({
    meta: [
      { title: "Journal — Meridian" },
      {
        name: "description",
        content:
          "Essays on rates, invoices, scope, and time for independent professionals.",
      },
    ],
  }),
});

function Journal() {
  const [hero, ...rest] = ARTICLES;
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
      <h1 className="font-serif text-5xl tracking-tight">Journal</h1>
      <p className="mt-4 max-w-xl text-lg text-muted">
        Written for the 11pm searcher who cannot sleep on a rate. One job per
        essay.
      </p>
      {hero ? (
        <Link
          to="/journal/$slug"
          params={{ slug: hero.slug }}
          className="mt-12 grid gap-8 lg:grid-cols-2"
        >
          <img
            src={hero.cover}
            alt=""
            className="h-80 w-full rounded-2xl object-cover"
          />
          <div className="flex flex-col justify-center">
            <p className="text-xs tracking-[0.14em] text-subtle uppercase">
              {hero.tags[0]} · {hero.minutes} min · {formatDate(hero.date)}
            </p>
            <h2 className="mt-3 font-serif text-4xl tracking-tight">{hero.title}</h2>
            <p className="mt-4 text-muted">{hero.dek}</p>
          </div>
        </Link>
      ) : null}
      <div className="mt-16 grid gap-10 sm:grid-cols-2">
        {rest.map((a) => (
          <Link key={a.slug} to="/journal/$slug" params={{ slug: a.slug }}>
            <img src={a.cover} alt="" className="h-52 w-full rounded-xl object-cover" />
            <p className="mt-3 text-xs tracking-[0.14em] text-subtle uppercase">
              {a.tags[0]} · {a.minutes} min
            </p>
            <h2 className="mt-2 font-serif text-2xl tracking-tight">{a.title}</h2>
            <p className="mt-2 text-sm text-muted">{a.dek}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
