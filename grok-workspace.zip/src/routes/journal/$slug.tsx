import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Newsletter } from "@/components/layout/newsletter";
import { ARTICLES, getArticle } from "@/lib/catalog";
import { formatDate } from "@/lib/utils";

export const Route = createFileRoute("/journal/$slug")({
  component: ArticlePage,
});

function ArticlePage() {
  const { slug } = Route.useParams();
  const article = getArticle(slug);

  if (!article) {
    return (
      <div className="mx-auto max-w-xl px-6 py-24 text-center">
        <h1 className="font-serif text-3xl">Essay not found</h1>
        <Button asChild className="mt-6">
          <Link to="/journal">Journal</Link>
        </Button>
      </div>
    );
  }

  const related = ARTICLES.filter((a) => a.slug !== article.slug).slice(0, 2);
  const cta =
    article.slug.includes("rate") || article.slug.includes("eighty")
      ? { to: "/tools/rates" as const, label: "Open the rate calculator" }
      : article.slug.includes("invoice")
        ? { to: "/tools/invoices" as const, label: "Open invoices" }
        : article.slug.includes("scope")
          ? { to: "/tools/proposals" as const, label: "Open proposals" }
          : { to: "/tools/time" as const, label: "Open the timer" };

  return (
    <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
      <p className="text-xs tracking-[0.14em] text-subtle uppercase">
        {article.tags.join(" · ")} · {formatDate(article.date)} · {article.minutes} min
      </p>
      <h1 className="mt-4 font-serif text-4xl tracking-tight sm:text-5xl">
        {article.title}
      </h1>
      <p className="mt-4 text-lg text-muted">{article.dek}</p>
      <img
        src={article.cover}
        alt=""
        className="mt-10 h-72 w-full rounded-2xl object-cover"
      />
      <div className="mt-10 space-y-5">
        {article.body.map((p) => (
          <p key={p.slice(0, 40)} className="text-base leading-relaxed text-fg">
            {p}
          </p>
        ))}
      </div>
      <div className="mt-12 rounded-2xl bg-ink p-8 text-cream">
        <p className="font-serif text-2xl">Do the work, not the reread.</p>
        <Button asChild className="mt-4 bg-cream text-ink hover:bg-cream/90">
          <Link to={cta.to}>{cta.label}</Link>
        </Button>
      </div>
      <div className="mt-12">
        <Newsletter />
      </div>
      <div className="mt-16 grid gap-8 sm:grid-cols-2">
        {related.map((a) => (
          <Link key={a.slug} to="/journal/$slug" params={{ slug: a.slug }}>
            <p className="text-xs tracking-[0.14em] text-subtle uppercase">{a.tags[0]}</p>
            <h2 className="mt-2 font-serif text-2xl tracking-tight">{a.title}</h2>
          </Link>
        ))}
      </div>
    </article>
  );
}
