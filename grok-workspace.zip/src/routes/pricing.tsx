import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FAQS, PLANS, planPrice } from "@/lib/catalog";
import type { Billing } from "@/lib/types";
import { money } from "@/lib/utils";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/pricing")({
  component: Pricing,
  head: () => ({
    meta: [
      { title: "Pricing — Meridian" },
      {
        name: "description",
        content:
          "Starter is free. Pro is $19 a month. Studio is $49. Annual is ten months for twelve.",
      },
    ],
  }),
});

function Pricing() {
  const [billing, setBilling] = useState<Billing>("annual");

  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
      <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
        Pricing
      </p>
      <h1 className="mt-3 font-serif text-5xl tracking-tight">
        Free until the paper is real
      </h1>
      <p className="mt-4 max-w-2xl text-lg text-muted">
        Starter is a working desk, not a demo. Pro is for the independent who
        outgrew three invoices. Studio is for a practice with a roster.
      </p>

      <div className="mt-8 inline-flex rounded-full bg-bg-subtle p-1">
        {(["monthly", "annual"] as Billing[]).map((b) => (
          <button
            key={b}
            type="button"
            onClick={() => setBilling(b)}
            className={cn(
              "h-10 rounded-full px-4 text-sm font-medium capitalize",
              billing === b ? "bg-bg-elevated text-fg shadow-[var(--shadow-border)]" : "text-muted",
            )}
          >
            {b === "annual" ? "Annual · two months free" : "Monthly"}
          </button>
        ))}
      </div>

      <div className="mt-10 grid gap-4 lg:grid-cols-3">
        {PLANS.map((plan) => {
          const price = planPrice(plan.id, billing);
          return (
            <div
              key={plan.id}
              className={cn(
                "flex flex-col rounded-2xl p-6 shadow-[var(--shadow-border)]",
                plan.highlight ? "bg-ink text-cream" : "bg-bg-elevated text-fg",
              )}
            >
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">{plan.name}</p>
                {plan.highlight ? (
                  <Badge className="bg-cream text-ink">Most independents</Badge>
                ) : null}
              </div>
              <p className="mt-5 font-serif text-5xl tracking-tight tabular-nums">
                {price === 0 ? "Free" : money(price)}
              </p>
              <p
                className={cn(
                  "mt-1 text-sm",
                  plan.highlight ? "text-cream/60" : "text-muted",
                )}
              >
                {price === 0
                  ? "Forever, with a ceiling"
                  : billing === "annual"
                    ? "per year"
                    : "per month"}
              </p>
              <p
                className={cn(
                  "mt-3 text-sm",
                  plan.highlight ? "text-cream/70" : "text-muted",
                )}
              >
                {plan.blurb}
              </p>
              <ul className="mt-6 flex-1 space-y-2">
                {plan.features.map((f) => (
                  <li key={f} className="flex gap-2 text-sm">
                    <Check className="mt-0.5 size-4 shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <Button
                asChild
                className={cn(
                  "mt-8",
                  plan.highlight && "bg-cream text-ink hover:bg-cream/90",
                )}
                variant={plan.highlight ? "secondary" : plan.id === "starter" ? "outline" : "default"}
              >
                {plan.id === "starter" ? (
                  <Link to="/onboarding">{plan.cta}</Link>
                ) : (
                  <Link to="/checkout" search={{ plan: plan.id, billing }}>
                    {plan.cta}
                  </Link>
                )}
              </Button>
            </div>
          );
        })}
      </div>

      <section className="mt-20">
        <h2 className="font-serif text-3xl tracking-tight">Questions, priced honestly</h2>
        <dl className="mt-8 divide-y divide-border border-y border-border">
          {FAQS.map((f) => (
            <div key={f.q} className="grid gap-2 py-5 md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.2fr)]">
              <dt className="font-medium">{f.q}</dt>
              <dd className="text-sm leading-relaxed text-muted">{f.a}</dd>
            </div>
          ))}
        </dl>
      </section>
    </div>
  );
}
