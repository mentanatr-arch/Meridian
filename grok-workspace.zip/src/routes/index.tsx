import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Clock, FileText, Gauge, PenLine } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { InvoicePaper } from "@/components/paper";
import {
  ARTICLES,
  LOGOS,
  PLANS,
  PRODUCTS,
  SITE,
  TESTIMONIALS,
} from "@/lib/catalog";
import { money } from "@/lib/utils";
import type { Invoice } from "@/lib/types";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [
      { title: "Meridian — Get paid like a studio" },
      { name: "description", content: SITE.description },
    ],
  }),
});

const DEMO_INVOICE: Invoice = {
  id: "demo",
  number: "INV-1042",
  status: "sent",
  issuedOn: "2026-09-22",
  dueOn: "2026-10-06",
  from: {
    name: "North Studio",
    email: "studio@north.example",
    address: "14 Mercer, Floor 3",
  },
  client: {
    name: "Harbor & Co.",
    email: "accounts@harbor.co",
    address: "88 Atlantic, Brooklyn",
  },
  items: [
    {
      id: "1",
      description: "Identity system — wordmark, type, paper",
      quantity: 1,
      rate: 8400,
    },
    {
      id: "2",
      description: "Launch collateral — three applications",
      quantity: 1,
      rate: 2600,
    },
  ],
  taxRate: 0,
  notes: "Due within 14 days. Transfer details on file.",
  currency: "USD",
};

const TOOLS = [
  {
    to: "/tools/rates",
    icon: Gauge,
    title: "Rate calculator",
    text: "Price the year, then the hour. Overhead, tax, and profit in one sitting.",
  },
  {
    to: "/tools/invoices",
    icon: FileText,
    title: "Invoice studio",
    text: "Paper that looks like a practice. Print or save as PDF the same day the work lands.",
  },
  {
    to: "/tools/proposals",
    icon: PenLine,
    title: "Proposals",
    text: "Scope, fence, timeline, investment. A yes that becomes an invoice without retyping.",
  },
  {
    to: "/tools/time",
    icon: Clock,
    title: "Time",
    text: "A quiet timer. Hours roll into the bill so you stop reconstructing the week.",
  },
];

function Home() {
  return (
    <div>
      <div className="border-b border-border bg-bg-subtle">
        <p className="mx-auto max-w-6xl px-4 py-2.5 text-center text-sm text-fg sm:px-6">
          Studio annual — two months on us through October.{" "}
          <Link to="/pricing" className="font-medium underline-offset-4 hover:underline">
            See pricing
          </Link>
        </p>
      </div>

      <section className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:py-24">
        <div>
          <p className="rise-in text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
            For independent professionals
          </p>
          <h1 className="rise-in mt-4 font-serif text-5xl leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
            Get paid like a studio.
          </h1>
          <p className="rise-in mt-6 max-w-lg text-lg leading-relaxed text-muted">
            Invoices, rates, proposals, and time — one desk for people who bill
            for thinking. Free to start. Beautiful enough to send.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <Link to="/onboarding">
                Start free
                <ArrowRight />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/tools/rates">Price your year</Link>
            </Button>
          </div>
          <p className="mt-5 text-sm text-subtle">
            No card. Three invoices. A rate you can defend.
          </p>
        </div>
        <div className="relative">
          <div className="pointer-events-none absolute -inset-4 -z-10 rounded-[2rem] bg-bg-subtle" />
          <div className="origin-top scale-[0.92] sm:scale-100">
            <InvoicePaper invoice={DEMO_INVOICE} />
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-bg-elevated">
        <div className="mx-auto grid max-w-6xl grid-cols-2 gap-8 px-4 py-10 sm:grid-cols-4 sm:px-6">
          {[
            ["$48.2M", "Invoiced on paper like this"],
            ["14,800", "Independents on the desk"],
            ["7 days", "Median time to paid"],
            ["4.9", "From 2,140 studio reviews"],
          ].map(([n, l]) => (
            <div key={l}>
              <p className="font-serif text-3xl tracking-tight tabular-nums">{n}</p>
              <p className="mt-1 text-sm text-muted">{l}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <p className="text-center text-xs tracking-[0.16em] text-subtle uppercase">
          Quiet rooms, serious practices
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-x-10 gap-y-3">
          {LOGOS.map((name) => (
            <span key={name} className="font-serif text-lg text-muted">
              {name}
            </span>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-8 sm:px-6">
        <div className="grid gap-6 sm:grid-cols-2">
          {TOOLS.map((tool) => (
            <Link
              key={tool.to}
              to={tool.to}
              className="group rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 hover:shadow-[var(--shadow-border-hover)]"
            >
              <tool.icon className="size-5 text-primary" />
              <h2 className="mt-4 font-serif text-2xl tracking-tight">{tool.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">{tool.text}</p>
              <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
                Open
                <ArrowRight className="size-4 transition-transform duration-150 group-hover:translate-x-0.5" />
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2">
        <div>
          <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
            How it works
          </p>
          <h2 className="mt-3 font-serif text-4xl tracking-tight">
            Price the year. Send the paper. Get paid.
          </h2>
          <ol className="mt-8 space-y-6">
            {[
              ["Run the rate", "A life, a calendar, overhead, tax, profit. The hour falls out of the year — not the other way around."],
              ["Put it on paper", "Invoices and proposals share line items. The fence is on page two, not buried in paragraph nineteen."],
              ["Keep the clock honest", "Time becomes the invoice. Starter is free until the work is real; Pro is $19 when you outgrow three bills."],
            ].map(([t, d], i) => (
              <li key={t} className="flex gap-4">
                <span className="font-serif text-2xl text-primary tabular-nums">
                  0{i + 1}
                </span>
                <div>
                  <p className="font-medium">{t}</p>
                  <p className="mt-1 text-sm leading-relaxed text-muted">{d}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
        <img
          src="/images/desk.jpg"
          alt="A quiet desk with cream paper, a fountain pen, and morning light"
          className="h-[420px] w-full rounded-2xl object-cover"
        />
      </section>

      <section className="bg-ink text-cream">
        <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
          <h2 className="font-serif text-4xl tracking-tight">In their words</h2>
          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {TESTIMONIALS.map((t) => (
              <figure
                key={t.name}
                className="rounded-2xl border border-cream/10 bg-ink p-6"
              >
                <blockquote className="text-base leading-relaxed text-cream/90">
                  {t.quote}
                </blockquote>
                <figcaption className="mt-6 text-sm text-cream/55">
                  <span className="text-cream">{t.name}</span>
                  <span className="mt-0.5 block">{t.role}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="font-serif text-4xl tracking-tight">Simple plans</h2>
            <p className="mt-2 text-muted">Start free. Grow when the paper does.</p>
          </div>
          <Link
            to="/pricing"
            className="hidden text-sm font-medium text-primary sm:inline-flex"
          >
            Full comparison
          </Link>
        </div>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {PLANS.map((plan) => (
            <div
              key={plan.id}
              className="flex flex-col rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]"
            >
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">{plan.name}</p>
                {plan.highlight ? <Badge>Most independents</Badge> : null}
              </div>
              <p className="mt-4 font-serif text-4xl tracking-tight tabular-nums">
                {plan.monthly === 0 ? "Free" : money(plan.monthly)}
                {plan.monthly > 0 ? (
                  <span className="text-base text-muted"> / mo</span>
                ) : null}
              </p>
              <p className="mt-2 text-sm text-muted">{plan.blurb}</p>
              <Button asChild className="mt-6" variant={plan.highlight ? "default" : "outline"}>
                <Link to="/pricing">{plan.cta}</Link>
              </Button>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <div className="flex items-end justify-between gap-4">
          <h2 className="font-serif text-4xl tracking-tight">The desk shop</h2>
          <Link to="/shop" className="text-sm font-medium text-primary">
            All kits
          </Link>
        </div>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {PRODUCTS.slice(0, 3).map((p) => (
            <Link key={p.slug} to="/shop/$slug" params={{ slug: p.slug }} className="group">
              <img
                src={p.cover}
                alt=""
                className="aspect-3/4 w-full rounded-xl object-cover transition-transform duration-250 group-hover:scale-[1.01]"
              />
              <div className="mt-3 flex items-baseline justify-between gap-3">
                <p className="font-medium">{p.title}</p>
                <p className="text-sm tabular-nums text-muted">{money(p.price)}</p>
              </div>
              <p className="mt-1 text-sm text-muted">{p.blurb}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="border-t border-border bg-bg-elevated">
        <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
          <h2 className="font-serif text-4xl tracking-tight">From the journal</h2>
          <div className="mt-10 grid gap-8 lg:grid-cols-3">
            {ARTICLES.slice(0, 3).map((a) => (
              <Link key={a.slug} to="/journal/$slug" params={{ slug: a.slug }} className="group">
                <img
                  src={a.cover}
                  alt=""
                  className="h-48 w-full rounded-xl object-cover"
                />
                <p className="mt-4 text-xs tracking-[0.14em] text-subtle uppercase">
                  {a.tags[0]} · {a.minutes} min
                </p>
                <h3 className="mt-2 font-serif text-2xl tracking-tight group-hover:text-primary">
                  {a.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{a.dek}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-4 py-24 text-center sm:px-6">
        <h2 className="font-serif text-4xl tracking-tight sm:text-5xl">
          Open the desk. Send the first invoice today.
        </h2>
        <p className="mt-4 text-muted">
          Starter is free. The paper is yours. Upgrade when three invoices are
          no longer enough.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button asChild size="lg">
            <Link to="/onboarding">Start free</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link to="/playbook">Read the playbook</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
