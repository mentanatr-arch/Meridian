import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStudio } from "@/lib/store";

export const Route = createFileRoute("/partners")({
  component: Partners,
  head: () => ({
    meta: [
      { title: "Partners — Meridian" },
      {
        name: "description",
        content:
          "Earn 30% on Meridian software and 15% on kits for 12 months. Terms in writing.",
      },
    ],
  }),
});

function Partners() {
  const subscribe = useStudio((s) => s.subscribe);
  const [done, setDone] = useState(false);

  return (
    <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
      <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
        Affiliates
      </p>
      <h1 className="mt-3 font-serif text-5xl tracking-tight">
        30% of software. 15% of kits. Twelve months.
      </h1>
      <p className="mt-4 text-lg text-muted">
        For operators who already advise independents — newsletters, accountants,
        communities. Cookie of 90 days. Paid monthly. No coupon blogs.
      </p>
      <dl className="mt-10 grid gap-6 sm:grid-cols-3">
        {[
          ["30%", "Recurring on Pro and Studio"],
          ["15%", "On desk shop kits"],
          ["90 days", "Attribution window"],
        ].map(([n, l]) => (
          <div key={l} className="rounded-2xl bg-bg-elevated p-5 shadow-[var(--shadow-border)]">
            <p className="font-serif text-3xl">{n}</p>
            <p className="mt-1 text-sm text-muted">{l}</p>
          </div>
        ))}
      </dl>
      <form
        className="mt-12 space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          const data = new FormData(e.currentTarget);
          const email = String(data.get("email") || "");
          if (email) subscribe(email);
          setDone(true);
        }}
      >
        <div>
          <Label htmlFor="name">Name</Label>
          <Input id="name" name="name" required className="mt-2" />
        </div>
        <div>
          <Label htmlFor="email">Email</Label>
          <Input id="email" name="email" type="email" required className="mt-2" />
        </div>
        <div>
          <Label htmlFor="where">Where you already speak</Label>
          <Textarea id="where" name="where" className="mt-2" placeholder="List, community, firm…" />
        </div>
        {done ? (
          <p className="text-sm font-medium text-primary">
            Received. We reply in two working days with a partner desk.
          </p>
        ) : (
          <Button type="submit">Apply</Button>
        )}
      </form>
    </div>
  );
}
