import { useEffect } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useStudio } from "@/lib/store";
import { totalOf } from "@/lib/totals";
import { computeRate } from "@/lib/totals";
import { formatDate, money, moneyExact } from "@/lib/utils";
import { useHydrated } from "@/lib/use-hydrated";

export const Route = createFileRoute("/studio")({
  component: Studio,
  head: () => ({ meta: [{ title: "Studio — Meridian" }] }),
});

function Studio() {
  const hydrated = useHydrated();
  const seedIfNeeded = useStudio((s) => s.seedIfNeeded);
  const profile = useStudio((s) => s.profile);
  const plan = useStudio((s) => s.plan);
  const invoices = useStudio((s) => s.invoices);
  const proposals = useStudio((s) => s.proposals);
  const entries = useStudio((s) => s.entries);
  const rate = useStudio((s) => s.rate);

  useEffect(() => {
    seedIfNeeded();
  }, [seedIfNeeded]);

  if (!hydrated) {
    return <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">Loading studio…</div>;
  }

  const outstanding = invoices
    .filter((i) => i.status === "sent" || i.status === "overdue")
    .reduce((s, i) => s + totalOf(i.items, i.taxRate), 0);
  const paid = invoices
    .filter((i) => i.status === "paid")
    .reduce((s, i) => s + totalOf(i.items, i.taxRate), 0);
  const weekAgo = Date.now() - 7 * 24 * 3600 * 1000;
  const weekSeconds = entries.reduce((s, e) => {
    const end = e.endedAt ?? Date.now();
    if (end < weekAgo) return s;
    return s + Math.max(0, (end - Math.max(e.startedAt, weekAgo)) / 1000);
  }, 0);
  const hours = weekSeconds / 3600;
  const model = computeRate(rate);

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
            {profile.name}
          </p>
          <h1 className="mt-2 font-serif text-4xl tracking-tight">Studio</h1>
          <p className="mt-2 text-muted">
            {profile.owner ? `Welcome back, ${profile.owner}.` : "Your desk."} Plan:{" "}
            <span className="capitalize">{plan}</span>
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {!profile.onboarded ? (
            <Button asChild variant="outline">
              <Link to="/onboarding">Set letterhead</Link>
            </Button>
          ) : null}
          <Button asChild>
            <Link to="/tools/invoices">New invoice</Link>
          </Button>
        </div>
      </div>

      <div className="mt-10 grid gap-4 sm:grid-cols-3">
        <Stat label="Outstanding" value={moneyExact(outstanding, profile.currency)} />
        <Stat label="Collected (on paper)" value={moneyExact(paid, profile.currency)} />
        <Stat
          label="Hours this week"
          value={`${hours.toFixed(1)}h`}
        />
      </div>

      <div className="mt-6 rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-sm text-muted">Saved rate model</p>
            <p className="mt-1 font-serif text-4xl tabular-nums">
              {money(model.hourly, rate.currency)}
              <span className="text-lg text-muted"> / hr</span>
            </p>
            <p className="mt-1 text-sm text-muted">
              {money(model.dayRate8, rate.currency)} day · {Math.round(model.billableHours)}{" "}
              billable hours / year
            </p>
          </div>
          <Button asChild variant="outline">
            <Link to="/tools/rates">Adjust the year</Link>
          </Button>
        </div>
      </div>

      {plan === "starter" ? (
        <div className="mt-6 flex flex-col gap-3 rounded-2xl border border-border bg-bg-subtle px-6 py-5 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm">
            Starter: {invoices.length}/3 invoices · {proposals.length}/1 proposal. Pro
            is unlimited paper.
          </p>
          <Button asChild size="sm">
            <Link to="/pricing">Upgrade</Link>
          </Button>
        </div>
      ) : null}

      <section className="mt-12">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-2xl tracking-tight">Recent invoices</h2>
          <Link to="/tools/invoices" className="text-sm font-medium text-primary">
            All invoices
          </Link>
        </div>
        <div className="mt-4 divide-y divide-border rounded-2xl bg-bg-elevated shadow-[var(--shadow-border)]">
          {invoices.length === 0 ? (
            <p className="p-6 text-sm text-muted">No invoices yet.</p>
          ) : (
            invoices.slice(0, 5).map((inv) => (
              <Link
                key={inv.id}
                to="/tools/invoices/$invoiceId"
                params={{ invoiceId: inv.id }}
                className="flex items-center justify-between gap-4 px-6 py-4 hover:bg-bg-subtle/50"
              >
                <div>
                  <p className="font-medium">
                    {inv.number} · {inv.client.name || "No client"}
                  </p>
                  <p className="text-sm text-muted">{formatDate(inv.issuedOn)}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={inv.status}>{inv.status}</Badge>
                  <p className="tabular-nums">
                    {moneyExact(totalOf(inv.items, inv.taxRate), inv.currency)}
                  </p>
                </div>
              </Link>
            ))
          )}
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-bg-elevated p-6 shadow-[var(--shadow-border)]">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-2 font-serif text-3xl tracking-tight tabular-nums">{value}</p>
    </div>
  );
}
