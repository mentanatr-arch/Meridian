import { createFileRoute, Link } from "@tanstack/react-router";
import { PRODUCTS } from "@/lib/catalog";
import { money } from "@/lib/utils";

export const Route = createFileRoute("/shop/")({
  component: Shop,
  head: () => ({
    meta: [
      { title: "Shop — Meridian" },
      {
        name: "description",
        content:
          "Contracts, rate cards, proposals, and a studio brand kit — digital paper for independents.",
      },
    ],
  }),
});

function Shop() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
      <h1 className="font-serif text-5xl tracking-tight">The desk shop</h1>
      <p className="mt-4 max-w-xl text-lg text-muted">
        Kits you can paste into the tools you already use. Margin for us.
        Faster yeses for you.
      </p>
      <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {PRODUCTS.map((p) => (
          <Link
            key={p.slug}
            to="/shop/$slug"
            params={{ slug: p.slug }}
            className="group"
          >
            <img
              src={p.cover}
              alt=""
              className="aspect-3/4 w-full rounded-xl object-cover transition-transform duration-250 ease-out group-hover:scale-[1.01]"
            />
            <p className="mt-3 text-xs tracking-[0.14em] text-subtle uppercase">
              {p.category}
            </p>
            <div className="mt-1 flex items-baseline justify-between gap-3">
              <h2 className="font-medium">{p.title}</h2>
              <span className="text-sm tabular-nums text-muted">{money(p.price)}</span>
            </div>
            <p className="mt-1 text-sm text-muted">{p.blurb}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
