import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getProduct, PRODUCTS } from "@/lib/catalog";
import { useStudio } from "@/lib/store";
import { money } from "@/lib/utils";

export const Route = createFileRoute("/shop/$slug")({
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const product = getProduct(slug);
  const addToCart = useStudio((s) => s.addToCart);

  if (!product) {
    return (
      <div className="mx-auto max-w-xl px-6 py-24 text-center">
        <h1 className="font-serif text-3xl">Kit not found</h1>
        <Button asChild className="mt-6">
          <Link to="/shop">Shop</Link>
        </Button>
      </div>
    );
  }

  const others = PRODUCTS.filter((p) => p.slug !== product.slug).slice(0, 3);

  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
      <div className="grid gap-12 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
        <img
          src={product.cover}
          alt=""
          className="w-full rounded-2xl object-cover"
        />
        <div>
          <p className="text-[11px] font-medium tracking-[0.18em] text-primary uppercase">
            {product.category}
          </p>
          <h1 className="mt-3 font-serif text-5xl tracking-tight">{product.title}</h1>
          <p className="mt-4 font-serif text-3xl tabular-nums">{money(product.price)}</p>
          <p className="mt-4 text-lg leading-relaxed text-muted">{product.body}</p>
          <ul className="mt-8 space-y-2">
            {product.includes.map((item) => (
              <li key={item} className="flex gap-2 text-sm">
                <Check className="mt-0.5 size-4 text-primary" />
                {item}
              </li>
            ))}
          </ul>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button
              size="lg"
              onClick={() => {
                addToCart(product.slug);
                toast(`Added ${product.title}`);
              }}
            >
              Add to desk
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/checkout">Checkout</Link>
            </Button>
          </div>
          <p className="mt-4 text-xs text-subtle">
            Instant download after checkout. 7-day refund if files were not taken
            in bulk. This preview does not charge a card.
          </p>
        </div>
      </div>
      <section className="mt-20">
        <h2 className="font-serif text-2xl tracking-tight">Also on the desk</h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-3">
          {others.map((p) => (
            <Link key={p.slug} to="/shop/$slug" params={{ slug: p.slug }}>
              <img src={p.cover} alt="" className="aspect-3/4 w-full rounded-xl object-cover" />
              <p className="mt-2 font-medium">{p.title}</p>
              <p className="text-sm tabular-nums text-muted">{money(p.price)}</p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
